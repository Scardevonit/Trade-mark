#!/usr/bin/env bash
#
# Packages the tidemark source into public/tidemark-source.zip so it can be
# downloaded straight from the running app and unzipped locally / pushed to GitHub.
#
#   bash scripts/make-bundle.sh
#
# Secrets are never included: .env, .env.*, and node_modules are excluded.

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/public/tidemark-source.zip"
STAMP="$(date -u +%Y-%m-%d)"

mkdir -p "$ROOT/public"
rm -f "$OUT"

cd "$ROOT"
zip -r -q "$OUT" \
  src \
  scripts \
  .github \
  github-pages \
  .gitignore \
  .env.example \
  .dockerignore \
  Dockerfile \
  README.md \
  DEPLOY.md \
  LICENSE \
  package.json \
  package-lock.json \
  next.config.ts \
  tsconfig.json \
  postcss.config.mjs \
  eslint.config.mjs \
  drizzle.config.json \
  -x '*.DS_Store' \
  -x '*__pycache__*'

# Write a manifest so the archive is self-documenting.
TMPDIR_BUNDLE="$(mktemp -d)"
MANIFEST="$TMPDIR_BUNDLE/MANIFEST.txt"
{
  echo "tidemark. — source bundle"
  echo "built: $STAMP"
  echo ""
  echo "QUICK START"
  echo "  1) unzip tidemark-source.zip -d tidemark"
  echo "  2) cd tidemark && cp .env.example .env   # then edit the values"
  echo "  3) npm install && npx drizzle-kit push --force && npm run dev"
  echo "  4) open http://localhost:3000 and create an account"
  echo ""
  echo "DEPLOYING"
  echo "  Read DEPLOY.md — it covers pushing to GitHub, CI, Vercel/Railway/Render/Fly"
  echo "  and the VPS/Docker path."
  echo ""
  echo "NOTE: .env is intentionally NOT in this archive. It holds DATABASE_URL."
  echo ""
  echo "CONTENTS"
  unzip -l "$OUT" | tail -n +4 | head -n -2 | sed 's/^/  /'
} >"$MANIFEST"
zip -q -j "$OUT" "$MANIFEST"
rm -rf "$TMPDIR_BUNDLE"

echo "bundle: $(du -h "$OUT" | cut -f1) -> public/tidemark-source.zip"
echo "download it at: /tidemark-source.zip"
