import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "tidemark. — live crypto brokerage",
  description:
    "Trade digital assets against live market prices with real order execution, locked balances, and a full cash ledger.",
  applicationName: "tidemark",
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#060b18",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
