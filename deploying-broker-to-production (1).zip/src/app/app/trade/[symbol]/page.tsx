import { TradeView } from "@/components/trade-view";
export const dynamic = "force-dynamic";

export default async function TradePage({ params }: { params: Promise<{ symbol: string }> }) {
  const { symbol } = await params;
  return <TradeView symbol={symbol.toUpperCase()} />;
}
