import { redirect } from "next/navigation";
import { AppShell } from "@/components/app-shell";
import { getCurrentUser } from "@/lib/auth";
import { getTickers } from "@/lib/market";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const board = await getTickers().catch(() => ({ tickers: [] as never[] }));
  return <AppShell tickers={board.tickers}>{children}</AppShell>;
}
