import { DashboardView } from "@/components/dashboard";

export default function AppHome() {
  return <DashboardView />;
}
