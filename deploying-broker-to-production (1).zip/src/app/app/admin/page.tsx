import { redirect } from "next/navigation";
import { AdminView } from "@/components/admin-view";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const user = await getCurrentUser();
  if (!user || user.role !== "admin") redirect("/app");
  return <AdminView />;
}
