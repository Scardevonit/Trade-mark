import { errorResponse, requireUser } from "@/lib/auth";
import { config, FEE } from "@/lib/config";
import { getAccountOverview, getLedger, settleOpenOrders } from "@/lib/trading";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await requireUser();
    await settleOpenOrders(user.id);
    const [overview, ledger] = await Promise.all([getAccountOverview(user.id), getLedger(user.id, 25)]);
    return Response.json(
      {
        user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role, tier: user.tier },
        ...overview,
        ledger,
        fees: { takerBps: config.takerFeeBps, makerBps: config.makerFeeBps, takerPct: FEE.taker * 100, makerPct: FEE.maker * 100 },
        mode: config.mode,
        serverTime: new Date().toISOString(),
      },
      { headers: { "cache-control": "no-store" } },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
