import { getCandles } from "@/lib/market";

export const dynamic = "force-dynamic";

const ALLOWED = new Set(["5m", "15m", "1h", "6h", "1d"]);

export async function GET(request: Request) {
  const url = new URL(request.url);
  const symbol = (url.searchParams.get("symbol") ?? "BTC").toUpperCase();
  const interval = url.searchParams.get("interval") ?? "1h";
  const limit = Math.min(Number(url.searchParams.get("limit") ?? 120) || 120, 300);
  if (!ALLOWED.has(interval)) return Response.json({ error: "Unsupported interval" }, { status: 400 });
  try {
    const data = await getCandles(symbol, interval, limit);
    return Response.json(data, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Chart unavailable", candles: [] }, { status: 502 });
  }
}
