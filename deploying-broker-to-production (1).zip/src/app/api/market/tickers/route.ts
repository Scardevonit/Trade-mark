import { getTickers } from "@/lib/market";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const board = await getTickers();
    return Response.json(board, {
      headers: { "cache-control": "no-store" },
    });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Market unavailable", tickers: [] }, { status: 502 });
  }
}
