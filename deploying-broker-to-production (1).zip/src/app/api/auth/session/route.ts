import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return Response.json({ user: null }, { status: 200 });
  return Response.json({
    user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role, tier: user.tier },
  });
}
