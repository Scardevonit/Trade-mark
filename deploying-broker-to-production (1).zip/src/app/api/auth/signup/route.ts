import { createSession, errorResponse, openAccount, signup, HttpError } from "@/lib/auth";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

const attempts = new Map<string, { count: number; reset: number }>();

function limited(key: string, max = 8, windowMs = 60_000) {
  const now = Date.now();
  const entry = attempts.get(key);
  if (!entry || entry.reset < now) {
    attempts.set(key, { count: 1, reset: now + windowMs });
    return false;
  }
  entry.count += 1;
  return entry.count > max;
}

export async function POST(request: Request) {
  try {
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
    if (limited(`signup:${ip}`)) throw new HttpError(429, "Too many attempts. Try again in a minute.");

    const body = (await request.json()) as { email?: string; password?: string; fullName?: string; country?: string };
    const email = (body.email ?? "").trim();
    const password = body.password ?? "";
    const fullName = (body.fullName ?? "").trim();

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw new HttpError(400, "Enter a valid email address");
    if (password.length < 8) throw new HttpError(400, "Password must be at least 8 characters");
    if (fullName.length < 2) throw new HttpError(400, "Enter your full name");

    const user = await signup({ email, password, fullName, country: body.country });
    await createSession(user.id, request.headers.get("user-agent"));
    return Response.json({
      user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role },
    });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function GET() {
  const rows = await db.select({ id: users.id }).from(users).where(eq(users.role, "admin")).limit(1);
  return Response.json({ hasAdmin: rows.length > 0 });
}
