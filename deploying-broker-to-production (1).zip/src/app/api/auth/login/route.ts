import { HttpError, createSession, errorResponse, login } from "@/lib/auth";

const attempts = new Map<string, { count: number; reset: number }>();

export async function POST(request: Request) {
  try {
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
    const now = Date.now();
    const entry = attempts.get(ip);
    if (entry && entry.reset > now && entry.count >= 12) {
      throw new HttpError(429, "Too many sign-in attempts. Try again shortly.");
    }
    if (!entry || entry.reset < now) attempts.set(ip, { count: 1, reset: now + 60_000 });
    else entry.count += 1;

    const body = (await request.json()) as { email?: string; password?: string };
    if (!body.email || !body.password) throw new HttpError(400, "Email and password are required");
    const user = await login({
      email: body.email,
      password: body.password,
      userAgent: request.headers.get("user-agent"),
    });
    return Response.json({ user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role } });
  } catch (error) {
    return errorResponse(error);
  }
}
