import { HttpError, errorResponse, requireUser } from "@/lib/auth";
import { completeTransfer, getPendingTransfers, rejectTransfer, userByTransfer } from "@/lib/trading";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await requireUser();
    if (user.role !== "admin") throw new HttpError(403, "Operations access required");
    const pending = await getPendingTransfers();
    const withUsers = await Promise.all(
      pending.map(async (transfer) => {
        const account = await userByTransfer(transfer.userId);
        return { ...transfer, userEmail: account?.email ?? "unknown", userName: account?.fullName ?? "unknown" };
      }),
    );
    return Response.json({ transfers: withUsers });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    if (user.role !== "admin") throw new HttpError(403, "Operations access required");
    const body = (await request.json()) as { id?: string; action?: string };
    if (!body.id) throw new HttpError(400, "Missing transfer id");
    const transfer =
      body.action === "reject" ? await rejectTransfer(body.id) : await completeTransfer(body.id, { note: `Approved by ${user.email}` });
    const pending = await getPendingTransfers();
    return Response.json({ ok: true, transfer, pending });
  } catch (error) {
    return errorResponse(error);
  }
}
