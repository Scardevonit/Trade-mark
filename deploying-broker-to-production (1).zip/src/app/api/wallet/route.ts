import { errorResponse, requireUser } from "@/lib/auth";
import { config } from "@/lib/config";
import { fundingAddresses, getLedger, getPortfolio, getTransfers } from "@/lib/trading";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await requireUser();
    const [portfolio, transfers, ledger] = await Promise.all([
      getPortfolio(user.id),
      getTransfers(user.id, 25),
      getLedger(user.id, 40),
    ]);
    return Response.json(
      {
        portfolio,
        transfers,
        ledger,
        addresses: fundingAddresses(),
        settings: {
          autoApproveDeposits: config.autoApproveDeposits,
          autoApproveWithdrawals: config.autoApproveWithdrawals,
          withdrawalFeeUsd: config.withdrawalFeeUsd,
          hasCardRail: Boolean(config.stripeSecretKey),
        },
      },
      { headers: { "cache-control": "no-store" } },
    );
  } catch (error) {
    return errorResponse(error);
  }
}
