import { errorResponse, requireUser } from "@/lib/auth";
import { config } from "@/lib/config";
import { createDeposit, fundingAddresses, getTransfers } from "@/lib/trading";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    const body = (await request.json()) as {
      asset?: string;
      amount?: number;
      method?: string;
      network?: string;
      txRef?: string;
    };
    const transfer = await createDeposit({
      userId: user.id,
      asset: String(body.asset ?? "USD"),
      amount: Number(body.amount ?? 0),
      method: body.method === "card" || body.method === "ach" || body.method === "wire" ? body.method : "crypto",
      network: body.network ?? null,
      txRef: body.txRef ?? null,
    });
    const transfers = await getTransfers(user.id, 25);
    return Response.json({
      ok: true,
      transfer,
      transfers,
      pendingReview: transfer.status === "pending",
      autoApprove: config.autoApproveDeposits,
      addresses: fundingAddresses(),
    });
  } catch (error) {
    return errorResponse(error);
  }
}
