import { errorResponse, requireUser } from "@/lib/auth";
import { createWithdrawal, getPortfolio, getTransfers } from "@/lib/trading";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    const body = (await request.json()) as { asset?: string; amount?: number; destination?: string; network?: string };
    const transfer = await createWithdrawal({
      userId: user.id,
      asset: String(body.asset ?? "USD"),
      amount: Number(body.amount ?? 0),
      destination: String(body.destination ?? ""),
      network: body.network ?? null,
    });
    const [transfers, portfolio] = await Promise.all([getTransfers(user.id, 25), getPortfolio(user.id)]);
    return Response.json({ ok: true, transfer, transfers, portfolio });
  } catch (error) {
    return errorResponse(error);
  }
}
