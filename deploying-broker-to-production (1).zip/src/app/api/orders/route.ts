import { errorResponse, requireUser } from "@/lib/auth";
import { getOrders, placeOrder, settleOpenOrders } from "@/lib/trading";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const user = await requireUser();
    await settleOpenOrders(user.id);
    const url = new URL(request.url);
    const status = url.searchParams.get("status") ?? "all";
    const orders = await getOrders(user.id, { status, limit: 100 });
    return Response.json({ orders }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    const body = (await request.json()) as {
      symbol?: string;
      side?: string;
      type?: string;
      amount?: number;
      amountType?: string;
      limitPrice?: number | string;
      clientId?: string;
    };

    const result = await placeOrder({
      userId: user.id,
      symbol: String(body.symbol ?? ""),
      side: body.side === "sell" ? "sell" : "buy",
      type: body.type === "limit" ? "limit" : "market",
      amountType: body.amountType === "unit" ? "unit" : "usd",
      amount: Number(body.amount ?? 0),
      limitPrice: body.limitPrice != null ? Number(body.limitPrice) : null,
      clientId: body.clientId ?? null,
    });

    const orders = await getOrders(user.id, { limit: 20 });
    return Response.json({
      ok: true,
      order: result.order,
      trade: result.trade ?? null,
      orders,
    });
  } catch (error) {
    return errorResponse(error);
  }
}
