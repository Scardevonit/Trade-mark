import { errorResponse, requireUser } from "@/lib/auth";
import { cancelOrder, getOrders } from "@/lib/trading";

export const dynamic = "force-dynamic";

export async function POST(_request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await context.params;
    const order = await cancelOrder(user.id, id);
    const orders = await getOrders(user.id, { limit: 50 });
    return Response.json({ ok: true, order, orders });
  } catch (error) {
    return errorResponse(error);
  }
}
