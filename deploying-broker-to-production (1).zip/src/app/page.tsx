import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { getTickers } from "@/lib/market";
import { fmtUsd } from "@/lib/money";
import { config } from "@/lib/config";
import { LandingMarket } from "@/components/landing-market";

export const dynamic = "force-dynamic";

const STEPS = [
  {
    title: "Open your account",
    body: "Email and password create a real ledger account with its own USD cash balance and coin wallets.",
  },
  {
    title: "Fund it",
    body: "Send crypto to your deposit address or connect a card/ACH rail. Every credit is journaled in the ledger.",
  },
  {
    title: "Trade the live book",
    body: "Market orders fill at the live bid/ask. Limit orders rest and fill automatically when the market crosses.",
  },
];

export default async function Home() {
  const [user, board] = await Promise.all([getCurrentUser(), getTickers().catch(() => ({ tickers: [] as Awaited<ReturnType<typeof getTickers>>["tickers"], source: "none", stale: true }))]);
  const btc = board.tickers.find((t) => t.symbol === "BTC");
  const eth = board.tickers.find((t) => t.symbol === "ETH");

  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5 sm:px-6">
        <span className="text-xl font-black tracking-tight sm:text-2xl">
          tidemark<span className="text-[#6d8dff]">.</span>
        </span>
        <Link href={user ? "/app" : "/login"} className="tm-btn tm-btn-primary text-sm sm:text-base">
          {user ? "Open app ↗" : "Launch app ↗"}
        </Link>
      </header>

      <section className="mx-auto max-w-6xl px-4 sm:px-6">
        <p className="text-xs font-black uppercase tracking-[0.28em] text-[#2fd6a5] sm:text-sm">Crypto, made clearer</p>
        <h1 className="mt-3 text-4xl font-black leading-[1.05] tracking-tight sm:text-6xl">
          Your next move.
          <br />
          <span className="text-[#8ea6ff]">Made with confidence.</span>
        </h1>
        <p className="mt-5 max-w-xl text-base leading-relaxed text-[#a9b6d9] sm:text-lg">
          Live market prices, honest order previews and real execution. Understand every fill, fee and locked balance before
          you place it.
        </p>

        <div className="mt-7 flex flex-wrap gap-3">
          <Link href={user ? "/app" : "/signup"} className="tm-btn tm-btn-primary">
            {user ? "Go to your dashboard" : "Open a live account"}
          </Link>
          <Link href="/signup" className="tm-btn tm-btn-ghost">
            How it works
          </Link>
        </div>

        <div className="mt-5 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-[#6f7fa8]">
          <span className="flex items-center gap-2">
            <span className="h-2 w-2 animate-pulse rounded-full bg-[#2fd6a5]" />
            <span className="font-bold uppercase tracking-[0.16em] text-[#2fd6a5]">Live market</span>
          </span>
          <span>{board.stale ? "reconnecting…" : `streaming from ${board.source}`}</span>
          <span>
            BTC {btc ? fmtUsd(btc.price) : "—"} · ETH {eth ? fmtUsd(eth.price) : "—"}
          </span>
          <span>
            taker {(config.takerFeeBps / 100).toFixed(2)}% · maker {(config.makerFeeBps / 100).toFixed(2)}%
          </span>
        </div>
      </section>

      <section className="mx-auto mt-10 max-w-6xl px-4 sm:px-6">
        <LandingMarket tickers={board.tickers} />
      </section>

      <section id="how" className="mx-auto mt-14 max-w-6xl px-4 sm:px-6">
        <h2 className="text-2xl font-black tracking-tight sm:text-3xl">How it works</h2>
        <div className="mt-5 grid gap-4 sm:grid-cols-3">
          {STEPS.map((step, index) => (
            <div key={step.title} className="tm-panel p-5">
              <span className="text-xs font-black uppercase tracking-[0.2em] text-[#6d8dff]">Step {index + 1}</span>
              <h3 className="mt-2 text-lg font-bold">{step.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-[#a9b6d9]">{step.body}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="mx-auto mt-14 max-w-6xl border-t border-[#131f3c] px-4 py-8 text-xs leading-relaxed text-[#6f7fa8] sm:px-6">
        <p className="font-bold uppercase tracking-[0.16em] text-[#8b9ac4]">Risk disclosure</p>
        <p className="mt-2 max-w-3xl">
          Digital assets are volatile and can lose value quickly. {config.mode === "live" ? "tidemark executes against live third-party market data" : "tidemark is running in simulation mode"} and
          holds client funds in an internal ledger. Funding rails, custody and licensing requirements differ by jurisdiction —
          connect your own payment processor, custody provider and regulatory approvals before serving external customers.
        </p>
        <p className="mt-3">
          Source: <a href="https://github.com/" className="text-[#8ea6ff]">GitHub</a> ·{" "}
          <a href="/tidemark-source.zip" className="text-[#8ea6ff]" download>
            download this project as a zip
          </a>{" "}
          · setup and deploy steps in <span className="text-[#c9d4f5]">DEPLOY.md</span>
        </p>
        <p className="mt-3">© {new Date().getFullYear()} tidemark.</p>
      </footer>
    </div>
  );
}
