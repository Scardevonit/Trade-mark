"use client";

import { useAppData } from "@/components/app-provider";
import { MarketList } from "@/components/market-list";
import { PriceChart } from "@/components/price-chart";
import { TradeTicket } from "@/components/trade-ticket";
import { Delta, EmptyState, Pill } from "@/components/ui";
import { fmtCrypto, fmtDateTime, fmtUsd } from "@/lib/money";

export function TradeView({ symbol }: { symbol: string }) {
  const { tickers, account } = useAppData();
  const ticker = tickers.find((t) => t.symbol === symbol);
  const spread = ticker && ticker.ask && ticker.bid ? ticker.ask - ticker.bid : null;
  const holding = account?.portfolio.holdings.find((h) => h.asset === symbol);
  const fills = (account?.recentTrades ?? []).filter((t) => t.symbol === symbol);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="tm-label">Trade</p>
          <h1 className="text-2xl font-black tracking-tight sm:text-3xl">
            {ticker?.name ?? symbol} <span className="text-[#8b9ac4]">· {symbol}/USD</span>
          </h1>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Pill tone="blue">bid {ticker ? fmtUsd(ticker.bid ?? ticker.price) : "—"}</Pill>
          <Pill tone="blue">ask {ticker ? fmtUsd(ticker.ask ?? ticker.price) : "—"}</Pill>
          {spread != null ? <Pill>spread {fmtUsd(spread)}</Pill> : null}
        </div>
      </div>

      <PriceChart symbol={symbol} ticker={ticker} />

      <div className="grid gap-4 lg:grid-cols-[1fr_1fr_1fr]">
        <MarketList selectable selected={symbol} title="Switch market" limit={10} />
        <TradeTicket symbol={symbol} />
        <div className="space-y-4">
          <section className="tm-panel p-4 sm:p-5">
            <h2 className="text-base font-bold sm:text-lg">Your {symbol}</h2>
            {holding ? (
              <dl className="mt-3 space-y-2 text-sm">
                <div className="flex justify-between">
                  <dt className="text-[#8b9ac4]">Quantity</dt>
                  <dd className="font-semibold tabular-nums">{fmtCrypto(holding.quantity, symbol)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-[#8b9ac4]">Available</dt>
                  <dd className="font-semibold tabular-nums">{fmtCrypto(holding.available, symbol)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-[#8b9ac4]">Locked in orders</dt>
                  <dd className="font-semibold tabular-nums">{fmtCrypto(holding.locked, symbol)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-[#8b9ac4]">Avg cost</dt>
                  <dd className="font-semibold tabular-nums">{fmtUsd(holding.avgCost)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-[#8b9ac4]">Value</dt>
                  <dd className="font-bold tabular-nums">{fmtUsd(holding.valueUsd)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-[#8b9ac4]">Unrealised P/L</dt>
                  <dd className="font-bold tabular-nums">
                    <span className={holding.unrealizedPnlUsd >= 0 ? "tm-up" : "tm-down"}>
                      {holding.unrealizedPnlUsd >= 0 ? "+" : ""}
                      {fmtUsd(holding.unrealizedPnlUsd)}
                    </span>{" "}
                    <Delta value={holding.unrealizedPnlPct} />
                  </dd>
                </div>
              </dl>
            ) : (
              <p className="mt-3 text-sm text-[#8b9ac4]">You do not hold any {symbol} yet.</p>
            )}
          </section>

          <section className="tm-panel p-4 sm:p-5">
            <h2 className="text-base font-bold sm:text-lg">{symbol} fills</h2>
            {fills.length === 0 ? (
              <div className="mt-3">
                <EmptyState title="No fills in this market yet" />
              </div>
            ) : (
              <ul className="mt-2 divide-y divide-[#131f3c]">
                {fills.slice(0, 6).map((t) => (
                  <li key={t.id} className="flex items-center justify-between py-2.5 text-sm">
                    <span className={t.side === "buy" ? "tm-up font-semibold" : "tm-down font-semibold"}>{t.side}</span>
                    <span className="tabular-nums">{fmtCrypto(t.quantity, t.symbol)}</span>
                    <span className="tabular-nums text-[#8b9ac4]">{fmtUsd(t.price)}</span>
                    <span className="text-[11px] text-[#6f7fa8]">{fmtDateTime(t.createdAt)}</span>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
