"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useAppData } from "@/components/app-provider";
import { EmptyState, Pill } from "@/components/ui";
import { assetName } from "@/lib/instrument-meta";
import type { OrderRow } from "@/lib/types";
import { fmtCrypto, fmtDateTime, fmtUsd } from "@/lib/money";

const TABS = ["open", "filled", "canceled", "all"] as const;

export function OrdersView() {
  const { account, cancelOrder, setNotice } = useAppData();
  const [tab, setTab] = useState<(typeof TABS)[number]>("open");
  const [busyId, setBusyId] = useState<string | null>(null);

  const [orders, setOrders] = useState(account?.openOrders ?? []);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    fetch(`/api/orders?status=${tab}`, { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : { orders: [] }))
      .then((json: { orders?: OrderRow[] }) => {
        if (!cancelled) setOrders(json.orders ?? []);
      })
      .catch(() => undefined)
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [tab, account?.serverTime]);

  const fills = account?.recentTrades ?? [];

  async function onCancel(id: string) {
    setBusyId(id);
    const ok = await cancelOrder(id);
    setBusyId(null);
    setNotice(ok ? { tone: "ok", message: "Order cancelled and funds released" } : { tone: "error", message: "Could not cancel order" });
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="tm-label">Orders</p>
          <h1 className="text-2xl font-black tracking-tight sm:text-3xl">Order book & fills</h1>
        </div>
        <Link href="/app/trade/BTC" className="tm-btn tm-btn-primary text-sm">
          New order
        </Link>
      </div>

      <section className="tm-panel overflow-hidden">
        <header className="flex flex-wrap items-center gap-2 border-b border-[#131f3c] px-4 py-3 sm:px-5">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`rounded-full px-3 py-1.5 text-xs font-bold uppercase tracking-widest transition ${
                tab === t ? "bg-[#6d8dff] text-[#050a17]" : "border border-[#1c2a4d] text-[#8b9ac4]"
              }`}
            >
              {t === "open" ? `Open (${orders.length})` : t}
            </button>
          ))}
        </header>

        {orders.length === 0 ? (
          <div className="p-4 sm:p-5">
            <EmptyState
              title={tab === "open" ? "No open orders" : `No ${tab} orders`}
              hint="Limit orders rest here until the live market crosses your price."
            />
          </div>
        ) : (
          <div className="tm-scroll overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead>
                <tr className="border-b border-[#131f3c] text-left text-[11px] uppercase tracking-widest text-[#8b9ac4]">
                  <th className="px-4 py-2 font-semibold sm:px-5">Market</th>
                  <th className="px-4 py-2 font-semibold">Side</th>
                  <th className="px-4 py-2 font-semibold">Type</th>
                  <th className="px-4 py-2 font-semibold">Quantity</th>
                  <th className="px-4 py-2 font-semibold">Limit</th>
                  <th className="px-4 py-2 font-semibold">Filled</th>
                  <th className="px-4 py-2 font-semibold">Status</th>
                  <th className="px-4 py-2 font-semibold">Placed</th>
                  <th className="px-4 py-2" />
                </tr>
              </thead>
              <tbody className="divide-y divide-[#131f3c]">
                {orders.map((o) => (
                  <tr key={o.id}>
                    <td className="px-4 py-3 font-semibold sm:px-5">{assetName(o.symbol)}</td>
                    <td className={`px-4 py-3 font-semibold capitalize ${o.side === "buy" ? "tm-up" : "tm-down"}`}>{o.side}</td>
                    <td className="px-4 py-3 capitalize text-[#8b9ac4]">{o.type}</td>
                    <td className="px-4 py-3 tabular-nums">{fmtCrypto(o.quantity ?? 0, o.symbol)}</td>
                    <td className="px-4 py-3 tabular-nums">{o.limitPrice ? fmtUsd(o.limitPrice) : "—"}</td>
                    <td className="px-4 py-3 tabular-nums">
                      {fmtCrypto(o.filledQuantity, o.symbol)}
                      {o.avgFillPrice ? <p className="text-[11px] text-[#8b9ac4]">@ {fmtUsd(o.avgFillPrice)}</p> : null}
                    </td>
                    <td className="px-4 py-3">
                      <Pill tone={o.status === "open" ? "warn" : o.status === "filled" ? "up" : "neutral"}>{o.status}</Pill>
                    </td>
                    <td className="px-4 py-3 text-[#8b9ac4]">{fmtDateTime(o.createdAt)}</td>
                    <td className="px-4 py-3 text-right">
                      {o.status === "open" ? (
                        <button
                          onClick={() => onCancel(o.id)}
                          disabled={busyId === o.id}
                          className="rounded-xl border border-[#1c2a4d] px-3 py-1.5 text-[11px] font-bold uppercase tracking-widest text-[#8b9ac4] hover:text-white"
                        >
                          {busyId === o.id ? "…" : "Cancel"}
                        </button>
                      ) : null}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <section className="tm-panel overflow-hidden">
        <header className="px-4 py-4 sm:px-5">
          <h2 className="text-base font-bold sm:text-lg">Recent fills</h2>
        </header>
        {fills.length === 0 ? (
          <div className="px-4 pb-5 sm:px-5">
            <EmptyState title="No fills yet" />
          </div>
        ) : (
          <div className="tm-scroll overflow-x-auto">
            <table className="w-full min-w-[640px] text-sm">
              <thead>
                <tr className="border-b border-[#131f3c] text-left text-[11px] uppercase tracking-widest text-[#8b9ac4]">
                  <th className="px-4 py-2 font-semibold sm:px-5">Market</th>
                  <th className="px-4 py-2 font-semibold">Side</th>
                  <th className="px-4 py-2 font-semibold">Quantity</th>
                  <th className="px-4 py-2 font-semibold">Price</th>
                  <th className="px-4 py-2 font-semibold">Notional</th>
                  <th className="px-4 py-2 font-semibold">Fee</th>
                  <th className="px-4 py-2 font-semibold">Liquidity</th>
                  <th className="px-4 py-2 font-semibold">Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#131f3c]">
                {fills.map((t) => (
                  <tr key={t.id}>
                    <td className="px-4 py-3 font-semibold sm:px-5">{t.symbol}</td>
                    <td className={`px-4 py-3 font-semibold capitalize ${t.side === "buy" ? "tm-up" : "tm-down"}`}>{t.side}</td>
                    <td className="px-4 py-3 tabular-nums">{fmtCrypto(t.quantity, t.symbol)}</td>
                    <td className="px-4 py-3 tabular-nums">{fmtUsd(t.price)}</td>
                    <td className="px-4 py-3 tabular-nums">{fmtUsd(t.notional)}</td>
                    <td className="px-4 py-3 tabular-nums text-[#8b9ac4]">{fmtUsd(t.fee)}</td>
                    <td className="px-4 py-3 capitalize text-[#8b9ac4]">{t.liquidity}</td>
                    <td className="px-4 py-3 text-[#8b9ac4]">{fmtDateTime(t.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
