"use client";

import Link from "next/link";
import { useAppData } from "@/components/app-provider";
import { Delta, EmptyState, Stat } from "@/components/ui";
import { assetColor } from "@/lib/instrument-meta";
import { fmtCrypto, fmtUsd } from "@/lib/money";

export function PortfolioView() {
  const { account } = useAppData();
  const portfolio = account?.portfolio;
  const holdings = portfolio?.holdings ?? [];
  const equity = portfolio?.equityUsd ?? 0;

  return (
    <div className="space-y-4">
      <div>
        <p className="tm-label">Portfolio</p>
        <h1 className="text-2xl font-black tracking-tight sm:text-3xl">Positions & performance</h1>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Total equity" value={fmtUsd(equity)} />
        <Stat label="Cash" value={fmtUsd(portfolio?.cashUsd ?? 0)} sub={`${fmtUsd(portfolio?.cashLocked ?? 0)} reserved`} />
        <Stat label="Invested" value={fmtUsd(portfolio?.holdingsValueUsd ?? 0)} />
        <Stat
          label="Unrealised P/L"
          value={fmtUsd(portfolio?.unrealizedPnlUsd ?? 0)}
          tone={(portfolio?.unrealizedPnlUsd ?? 0) >= 0 ? "up" : "down"}
        />
      </div>

      <section className="tm-panel overflow-hidden">
        <header className="px-4 py-4 sm:px-5">
          <h2 className="text-base font-bold sm:text-lg">Holdings</h2>
          <p className="text-xs text-[#8b9ac4]">Marked to the live market every few seconds</p>
        </header>
        {holdings.length === 0 ? (
          <div className="px-4 pb-5 sm:px-5">
            <EmptyState title="No holdings yet" hint="Place your first order to start building a position." />
          </div>
        ) : (
          <div className="tm-scroll overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead>
                <tr className="border-y border-[#131f3c] text-left text-[11px] uppercase tracking-widest text-[#8b9ac4]">
                  <th className="px-4 py-2 font-semibold sm:px-5">Asset</th>
                  <th className="px-4 py-2 font-semibold">Quantity</th>
                  <th className="px-4 py-2 font-semibold">Price</th>
                  <th className="px-4 py-2 font-semibold">Avg cost</th>
                  <th className="px-4 py-2 font-semibold">Value</th>
                  <th className="px-4 py-2 font-semibold">P/L</th>
                  <th className="px-4 py-2 font-semibold">Weight</th>
                  <th className="px-4 py-2" />
                </tr>
              </thead>
              <tbody className="divide-y divide-[#131f3c]">
                {holdings.map((h) => {
                  const weight = equity > 0 ? (h.valueUsd / equity) * 100 : 0;
                  return (
                    <tr key={h.asset}>
                      <td className="px-4 py-3 sm:px-5">
                        <div className="flex items-center gap-2">
                          <span className="h-2.5 w-2.5 rounded-full" style={{ background: assetColor(h.asset) }} />
                          <div>
                            <p className="font-semibold">{h.asset}</p>
                            <p className="text-[11px] text-[#8b9ac4]">{h.name}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 tabular-nums">
                        {fmtCrypto(h.quantity, h.asset)}
                        {h.locked > 0 ? <p className="text-[11px] text-[#8b9ac4]">{fmtCrypto(h.locked)} locked</p> : null}
                      </td>
                      <td className="px-4 py-3 tabular-nums">{fmtUsd(h.price)}</td>
                      <td className="px-4 py-3 tabular-nums text-[#8b9ac4]">{fmtUsd(h.avgCost)}</td>
                      <td className="px-4 py-3 font-semibold tabular-nums">{fmtUsd(h.valueUsd)}</td>
                      <td className="px-4 py-3 tabular-nums">
                        <p className={h.unrealizedPnlUsd >= 0 ? "tm-up font-semibold" : "tm-down font-semibold"}>
                          {h.unrealizedPnlUsd >= 0 ? "+" : ""}
                          {fmtUsd(h.unrealizedPnlUsd)}
                        </p>
                        <Delta value={h.unrealizedPnlPct} className="text-[11px]" />
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 w-16 overflow-hidden rounded-full bg-white/10">
                            <div className="h-full rounded-full bg-[#6d8dff]" style={{ width: `${Math.min(100, weight)}%` }} />
                          </div>
                          <span className="text-[11px] tabular-nums text-[#8b9ac4]">{weight.toFixed(1)}%</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <Link href={`/app/trade/${h.asset}`} className="text-xs font-semibold text-[#8ea6ff]">
                          Trade →
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
