"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { AppProvider, useAppData } from "@/components/app-provider";
import { Toast } from "@/components/ui";
import { fmtUsd } from "@/lib/money";
import type { Ticker } from "@/lib/types";

const NAV = [
  { href: "/app", label: "Dashboard" },
  { href: "/app/portfolio", label: "Portfolio" },
  { href: "/app/orders", label: "Orders" },
  { href: "/app/wallet", label: "Wallet" },
];

function Shell({ children }: { children: React.ReactNode }) {
  const { account, tickers, notice, setNotice } = useAppData();
  const pathname = usePathname();
  const router = useRouter();
  const [signingOut, setSigningOut] = useState(false);
  const isTradePage = pathname.startsWith("/app/trade");
  const equity = account?.portfolio.equityUsd ?? 0;

  async function signOut() {
    setSigningOut(true);
    await fetch("/api/auth/logout", { method: "POST" });
    router.replace("/login");
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b border-[#131f3c] bg-[#060b18]/85 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:px-6">
          <Link href="/app" className="text-lg font-black tracking-tight">
            tidemark<span className="text-[#6d8dff]">.</span>
          </Link>
          <span className="hidden items-center gap-1.5 rounded-full border border-[#2fd6a5]/30 bg-[#2fd6a5]/10 px-2 py-1 text-[10px] font-bold uppercase tracking-[0.16em] text-[#2fd6a5] sm:flex">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#2fd6a5]" /> live
          </span>

          <nav className="tm-scroll ml-auto hidden items-center gap-1 overflow-x-auto md:flex">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`rounded-xl px-3 py-2 text-sm font-semibold transition ${
                  pathname === item.href ? "bg-[#6d8dff]/15 text-[#b9c7ff]" : "text-[#8b9ac4] hover:text-white"
                }`}
              >
                {item.label}
              </Link>
            ))}
            {account?.user.role === "admin" ? (
              <Link
                href="/app/admin"
                className={`rounded-xl px-3 py-2 text-sm font-semibold ${
                  pathname === "/app/admin" ? "bg-[#6d8dff]/15 text-[#b9c7ff]" : "text-[#8b9ac4] hover:text-white"
                }`}
              >
                Ops
              </Link>
            ) : null}
          </nav>

          <div className="ml-auto flex items-center gap-3 md:ml-0">
            <div className="text-right">
              <p className="text-[10px] uppercase tracking-[0.16em] text-[#8b9ac4]">Equity</p>
              <p className="text-sm font-bold tabular-nums">{fmtUsd(equity)}</p>
            </div>
            <button
              onClick={signOut}
              disabled={signingOut}
              className="rounded-xl border border-[#1c2a4d] px-3 py-2 text-xs font-bold uppercase tracking-widest text-[#8b9ac4] transition hover:text-white"
            >
              {signingOut ? "…" : "Exit"}
            </button>
          </div>
        </div>
        <nav className="tm-scroll flex items-center gap-1 overflow-x-auto border-t border-[#131f3c] px-4 py-2 md:hidden">
          {[...NAV, ...(account?.user.role === "admin" ? [{ href: "/app/admin", label: "Ops" }] : [])].map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`whitespace-nowrap rounded-xl px-3 py-1.5 text-xs font-semibold ${
                pathname === item.href ? "bg-[#6d8dff]/15 text-[#b9c7ff]" : "text-[#8b9ac4]"
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </header>

      <main className={`mx-auto max-w-6xl px-4 pb-28 pt-5 sm:px-6 ${isTradePage ? "" : ""}`}>{children}</main>

      <Toast notice={notice} onDone={() => setNotice(null)} />

      {isTradePage ? <MobileTickerBar tickers={tickers} /> : null}
    </div>
  );
}

function MobileTickerBar({ tickers }: { tickers: Ticker[] }) {
  const top = tickers.slice(0, 6);
  if (!top.length) return null;
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-30 border-t border-[#131f3c] bg-[#060b18]/95 px-3 py-2 backdrop-blur md:hidden">
      <div className="flex gap-4 overflow-x-auto text-[11px]">
        {top.map((t) => (
          <span key={t.symbol} className="whitespace-nowrap">
            <span className="font-bold">{t.symbol}</span>{" "}
            <span className="tabular-nums text-[#c9d4f5]">{fmtUsd(t.price)}</span>{" "}
            <span className={(t.change24h ?? 0) >= 0 ? "tm-up" : "tm-down"}>
              {(t.change24h ?? 0) >= 0 ? "+" : ""}
              {(t.change24h ?? 0).toFixed(2)}%
            </span>
          </span>
        ))}
      </div>
    </div>
  );
}

export function AppShell({ children, tickers }: { children: React.ReactNode; tickers?: Ticker[] }) {
  return (
    <AppProvider initialTickers={tickers} withAccount>
      <Shell>{children}</Shell>
    </AppProvider>
  );
}
