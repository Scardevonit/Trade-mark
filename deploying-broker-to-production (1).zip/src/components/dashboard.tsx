"use client";

import Link from "next/link";
import { useAppData } from "@/components/app-provider";
import { MarketList } from "@/components/market-list";
import { TradeTicket } from "@/components/trade-ticket";
import { Delta, EmptyState, Pill, Stat } from "@/components/ui";
import { assetName } from "@/lib/instrument-meta";
import { fmtCrypto, fmtDateTime, fmtUsd } from "@/lib/money";

export function DashboardView() {
  const { account, cancelOrder, setNotice } = useAppData();
  const portfolio = account?.portfolio;
  const openOrders = account?.openOrders ?? [];
  const fills = account?.recentTrades ?? [];
  const holdings = portfolio?.holdings ?? [];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="tm-label">Account overview</p>
          <h1 className="text-2xl font-black tracking-tight sm:text-3xl">
            {account ? `Hello, ${account.user.fullName.split(" ")[0]}` : "Loading your account…"}
          </h1>
        </div>
        <div className="flex gap-2">
          <Link href="/app/wallet" className="tm-btn tm-btn-ghost text-sm">
            Add funds
          </Link>
          <Link href="/app/trade/BTC" className="tm-btn tm-btn-primary text-sm">
            Trade BTC
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Total equity" value={fmtUsd(portfolio?.equityUsd ?? 0)} sub={`${holdings.length} position${holdings.length === 1 ? "" : "s"}`} />
        <Stat label="Available cash" value={fmtUsd(portfolio?.cashAvailable ?? 0)} sub={`${fmtUsd(portfolio?.cashLocked ?? 0)} locked in orders`} />
        <Stat label="Holdings value" value={fmtUsd(portfolio?.holdingsValueUsd ?? 0)} sub="at live market prices" />
        <Stat
          label="Unrealised P/L"
          value={fmtUsd(portfolio?.unrealizedPnlUsd ?? 0)}
          tone={(portfolio?.unrealizedPnlUsd ?? 0) >= 0 ? "up" : "down"}
          sub="vs. your cost basis"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_1fr]">
        <MarketList />
        <TradeTicket symbol="BTC" />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="tm-panel p-4 sm:p-5">
          <header className="flex items-center justify-between">
            <h2 className="text-base font-bold sm:text-lg">Your positions</h2>
            <Link href="/app/portfolio" className="text-xs font-semibold text-[#8ea6ff]">
              View all →
            </Link>
          </header>
          <div className="mt-3">
            {holdings.length === 0 ? (
              <EmptyState title="No positions yet" hint="Fund your wallet, then place your first market order." />
            ) : (
              <ul className="divide-y divide-[#131f3c]">
                {holdings.slice(0, 5).map((h) => (
                  <li key={h.asset} className="flex items-center gap-3 py-3">
                    <Link href={`/app/trade/${h.asset}`} className="flex min-w-0 flex-1 items-center gap-3">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold">
                          {h.name} <span className="text-[#8b9ac4]">· {h.asset}</span>
                        </p>
                        <p className="text-[11px] text-[#8b9ac4]">
                          {fmtCrypto(h.quantity, h.asset)} @ {fmtUsd(h.price)}
                        </p>
                      </div>
                    </Link>
                    <div className="text-right">
                      <p className="text-sm font-bold tabular-nums">{fmtUsd(h.valueUsd)}</p>
                      <p className="text-xs">
                        <span className={h.unrealizedPnlUsd >= 0 ? "tm-up" : "tm-down"}>
                          {h.unrealizedPnlUsd >= 0 ? "+" : ""}
                          {fmtUsd(h.unrealizedPnlUsd)}
                        </span>{" "}
                        <Delta value={h.unrealizedPnlPct} />
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>

        <section className="tm-panel p-4 sm:p-5">
          <header className="flex items-center justify-between">
            <h2 className="text-base font-bold sm:text-lg">Open orders</h2>
            <Link href="/app/orders" className="text-xs font-semibold text-[#8ea6ff]">
              Order history →
            </Link>
          </header>
          <div className="mt-3">
            {openOrders.length === 0 ? (
              <EmptyState title="Nothing resting on the book" hint="Limit orders you place will appear here until they fill." />
            ) : (
              <ul className="divide-y divide-[#131f3c]">
                {openOrders.map((o) => (
                  <li key={o.id} className="flex items-center gap-3 py-3">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold">
                        <span className={o.side === "buy" ? "tm-up" : "tm-down"}>{o.side === "buy" ? "Buy" : "Sell"}</span>{" "}
                        {fmtCrypto(o.quantity ?? 0, o.symbol)}
                      </p>
                      <p className="text-[11px] text-[#8b9ac4]">
                        limit {fmtUsd(o.limitPrice ?? 0)} · {fmtDateTime(o.createdAt)}
                      </p>
                    </div>
                    <button
                      onClick={async () => {
                        const ok = await cancelOrder(o.id);
                        setNotice(
                          ok
                            ? { tone: "ok", message: `Cancelled ${o.side} ${o.symbol} order` }
                            : { tone: "error", message: "Could not cancel that order" },
                        );
                      }}
                      className="rounded-xl border border-[#1c2a4d] px-3 py-1.5 text-[11px] font-bold uppercase tracking-widest text-[#8b9ac4] hover:text-white"
                    >
                      Cancel
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>
      </div>

      <section className="tm-panel overflow-hidden">
        <header className="flex items-center justify-between px-4 py-4 sm:px-5">
          <h2 className="text-base font-bold sm:text-lg">Recent fills</h2>
          <Pill tone="blue">{account?.fees.takerPct ?? 0}% taker</Pill>
        </header>
        {fills.length === 0 ? (
          <div className="px-4 pb-5 sm:px-5">
            <EmptyState title="No trades yet" hint="Your fills will show here with price, quantity and fee." />
          </div>
        ) : (
          <div className="tm-scroll overflow-x-auto">
            <table className="w-full min-w-[520px] text-sm">
              <thead>
                <tr className="border-y border-[#131f3c] text-left text-[11px] uppercase tracking-widest text-[#8b9ac4]">
                  <th className="px-4 py-2 font-semibold sm:px-5">Market</th>
                  <th className="px-4 py-2 font-semibold">Side</th>
                  <th className="px-4 py-2 font-semibold">Quantity</th>
                  <th className="px-4 py-2 font-semibold">Price</th>
                  <th className="px-4 py-2 font-semibold">Fee</th>
                  <th className="px-4 py-2 font-semibold">Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#131f3c]">
                {fills.map((t) => (
                  <tr key={t.id}>
                    <td className="px-4 py-3 font-semibold sm:px-5">{assetName(t.symbol)}</td>
                    <td className={`px-4 py-3 font-semibold capitalize ${t.side === "buy" ? "tm-up" : "tm-down"}`}>{t.side}</td>
                    <td className="px-4 py-3 tabular-nums">{fmtCrypto(t.quantity, t.symbol)}</td>
                    <td className="px-4 py-3 tabular-nums">{fmtUsd(t.price)}</td>
                    <td className="px-4 py-3 tabular-nums text-[#8b9ac4]">{fmtUsd(t.fee)}</td>
                    <td className="px-4 py-3 text-[#8b9ac4]">{fmtDateTime(t.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
