"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { INTERVALS, type IntervalKey } from "@/lib/instrument-meta";
import { fmtUsd, timeAgo } from "@/lib/money";
import type { Candle, Ticker } from "@/lib/types";

const WIDTH = 640;
const HEIGHT = 220;

export function PriceChart({ symbol, ticker }: { symbol: string; ticker?: Ticker }) {
  const [timeframe, setTimeframe] = useState<IntervalKey>("1h");
  const [candles, setCandles] = useState<Candle[]>([]);
  const [source, setSource] = useState("");
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const res = await fetch(`/api/market/candles?symbol=${symbol}&interval=${timeframe}&limit=120`, { cache: "no-store" });
      const json = (await res.json()) as { candles?: Candle[]; source?: string };
      setCandles(json.candles ?? []);
      setSource(json.source ?? "");
    } catch {
      /* keep the previous chart on transient errors */
    } finally {
      setLoading(false);
    }
  }, [symbol, timeframe]);

  useEffect(() => {
    setLoading(true);
    void load();
    const timer = window.setInterval(() => void load(), 30_000);
    return () => window.clearInterval(timer);
  }, [load]);

  const view = useMemo(() => {
    if (candles.length < 2) return null;
    const highs = candles.map((c) => c.high);
    const lows = candles.map((c) => c.low);
    const max = Math.max(...highs);
    const min = Math.min(...lows);
    const span = max - min || 1;
    const step = WIDTH / (candles.length - 1);
    const yFor = (v: number) => HEIGHT - ((v - min) / span) * (HEIGHT - 16) - 8;
    const points = candles.map((c, i) => `${(i * step).toFixed(1)},${yFor(c.close).toFixed(1)}`);
    const last = candles[candles.length - 1];
    const first = candles[0];
    return {
      max,
      min,
      line: points.join(" "),
      path: `M ${points.join(" L ")}`,
      area: `M 0,${HEIGHT} L ${points.join(" L ")} L ${WIDTH},${HEIGHT} Z`,
      up: last.close >= first.open,
      lastY: yFor(last.close),
      last,
      first,
    };
  }, [candles]);

  const stroke = view?.up ? "#2fd6a5" : "#ff5f6d";
  const rangeChange = view ? ((view.last.close - view.first.open) / view.first.open) * 100 : 0;

  return (
    <section className="tm-panel p-4 sm:p-5">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="tm-label">{symbol} · live chart</p>
          <div className="mt-1 flex items-end gap-3">
            <span className="text-2xl font-black tabular-nums sm:text-3xl">{ticker ? fmtUsd(ticker.price) : "—"}</span>
            {ticker?.change24h != null ? (
              <span className={`pb-1 text-sm font-bold ${ticker.change24h >= 0 ? "tm-up" : "tm-down"}`}>
                {ticker.change24h >= 0 ? "▲" : "▼"} {Math.abs(ticker.change24h).toFixed(2)}%
              </span>
            ) : null}
          </div>
          <p className="mt-1 text-[11px] text-[#6f7fa8]">
            {timeframe} range {rangeChange >= 0 ? "+" : ""}
            {rangeChange.toFixed(2)}% · source {source || "—"} · updated {timeAgo(ticker?.updatedAt)}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-1 rounded-full border border-[#1c2a4d] bg-[#060b18]/70 p-1">
          {INTERVALS.map((i) => (
            <button
              key={i}
              onClick={() => setTimeframe(i)}
              className={`rounded-full px-2.5 py-1 text-[11px] font-bold uppercase transition ${
                timeframe === i ? "bg-[#6d8dff] text-[#050a17]" : "text-[#8b9ac4] hover:text-white"
              }`}
            >
              {i}
            </button>
          ))}
        </div>
      </header>

      <div className="mt-4">
        {loading && !view ? (
          <div className="h-[220px] w-full animate-pulse rounded-xl bg-white/[0.04]" />
        ) : view ? (
          <svg viewBox={`0 0 ${WIDTH} ${HEIGHT}`} className="h-[220px] w-full" preserveAspectRatio="none">
            <defs>
              <linearGradient id={`chart-${symbol}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={stroke} stopOpacity="0.34" />
                <stop offset="100%" stopColor={stroke} stopOpacity="0" />
              </linearGradient>
            </defs>
            {[0.25, 0.5, 0.75].map((g) => (
              <line key={g} x1="0" x2={WIDTH} y1={HEIGHT * g} y2={HEIGHT * g} stroke="#16233f" strokeWidth="1" />
            ))}
            <path d={view.area} fill={`url(#chart-${symbol})`} />
            <path d={view.path} fill="none" stroke={stroke} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
            <line x1="0" x2={WIDTH} y1={view.lastY} y2={view.lastY} stroke={stroke} strokeWidth="0.75" strokeDasharray="4 5" opacity="0.5" />
            <circle cx={WIDTH - 2} cy={view.lastY} r="3.5" fill={stroke} />
          </svg>
        ) : (
          <div className="flex h-[220px] items-center justify-center rounded-xl border border-dashed border-[#22315a] text-sm text-[#8b9ac4]">
            Chart data unavailable for this market right now.
          </div>
        )}
      </div>
    </section>
  );
}
