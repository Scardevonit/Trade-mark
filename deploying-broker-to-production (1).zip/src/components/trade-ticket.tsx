"use client";

import { useMemo, useState } from "react";
import { useAppData } from "@/components/app-provider";
import { fmtCrypto, fmtUsd } from "@/lib/money";

export function TradeTicket({
  symbol,
  onFilled,
  guest = false,
}: {
  symbol: string;
  onFilled?: () => void;
  guest?: boolean;
}) {
  const { tickers, account, placeOrder, setNotice } = useAppData();
  const [side, setSide] = useState<"buy" | "sell">("buy");
  const [type, setType] = useState<"market" | "limit">("market");
  const [amountType, setAmountType] = useState<"usd" | "unit">("usd");
  const [amount, setAmount] = useState("100");
  const [limitPrice, setLimitPrice] = useState("");
  const [busy, setBusy] = useState(false);

  const ticker = tickers.find((t) => t.symbol === symbol);
  const price = ticker ? (side === "buy" ? ticker.ask ?? ticker.price : ticker.bid ?? ticker.price) : 0;
  const fees = account?.fees ?? { takerPct: 0.45, makerPct: 0.15, takerBps: 45, makerBps: 15 };
  const cashAvailable = account?.portfolio.cashAvailable ?? 0;
  const holding = account?.portfolio.holdings.find((h) => h.asset === symbol);
  const assetAvailable = holding?.available ?? 0;

  const quote = useMemo(() => {
    const amt = Number(amount) || 0;
    const effectivePrice = type === "limit" && Number(limitPrice) > 0 ? Number(limitPrice) : price;
    const notional = amountType === "usd" ? amt : amt * effectivePrice;
    const qty = effectivePrice > 0 ? notional / effectivePrice : 0;
    const feeRate = (type === "limit" ? fees.makerPct : fees.takerPct) / 100;
    const fee = notional * feeRate;
    return { notional, qty, fee, total: side === "buy" ? notional + fee : Math.max(0, notional - fee), effectivePrice };
  }, [amount, amountType, fees.makerPct, fees.takerPct, limitPrice, price, side, type]);

  const insufficient = side === "buy" ? quote.total > cashAvailable + 1e-9 : quote.qty > assetAvailable + 1e-9;
  const canSubmit = Number(amount) > 0 && quote.effectivePrice > 0 && !busy && (type === "market" || Number(limitPrice) > 0);

  async function submit() {
    setBusy(true);
    setNotice(null);
    const result = await placeOrder({
      symbol,
      side,
      type,
      amountType,
      amount: Number(amount) || 0,
      limitPrice: type === "limit" ? Number(limitPrice) : null,
    });
    setBusy(false);
    if (!result.ok) {
      setNotice({ tone: "error", message: result.error ?? "Order rejected" });
      return;
    }
    const o = result.order;
    setNotice({
      tone: "ok",
      message:
        o?.status === "filled"
          ? `${side === "buy" ? "Bought" : "Sold"} ${fmtCrypto(o.filledQuantity)} ${symbol} at ${fmtUsd(o.avgFillPrice ?? 0)}`
          : `Limit ${side} order resting at ${fmtUsd(o?.limitPrice ?? 0)}`,
    });
    setAmount("100");
    onFilled?.();
  }

  const activeTone = side === "buy" ? "tm-btn-mint" : "tm-btn-primary";

  return (
    <div className="tm-panel p-4 sm:p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="tm-label">{side === "buy" ? "Buy" : "Sell"} order</p>
          <h3 className="mt-1 text-lg font-bold">
            {ticker?.name ?? symbol} <span className="text-[#8b9ac4]">· {symbol}</span>
          </h3>
        </div>
        <div className="text-right">
          <p className="text-lg font-bold tabular-nums">{price > 0 ? fmtUsd(price) : "—"}</p>
          <p className="text-[11px] uppercase tracking-widest text-[#8b9ac4]">{side === "buy" ? "ask" : "bid"}</p>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-1 rounded-xl border border-[#1c2a4d] bg-[#060b18]/70 p-1">
        {(["buy", "sell"] as const).map((s) => (
          <button
            key={s}
            onClick={() => setSide(s)}
            className={`rounded-lg py-2.5 text-sm font-bold capitalize transition ${
              side === s
                ? s === "buy"
                  ? "bg-[#2fd6a5] text-[#04231b]"
                  : "bg-[#ff5f6d] text-[#2a0509]"
                : "text-[#8b9ac4] hover:text-white"
            }`}
          >
            {s === "buy" ? "Buy" : "Sell"}
          </button>
        ))}
      </div>

      <div className="mt-3 flex items-center gap-2 text-xs">
        {(["market", "limit"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setType(t)}
            className={`rounded-full border px-3 py-1.5 font-semibold capitalize transition ${
              type === t ? "border-[#6d8dff] bg-[#6d8dff]/15 text-[#b9c7ff]" : "border-[#1c2a4d] text-[#8b9ac4]"
            }`}
          >
            {t}
          </button>
        ))}
        <span className="ml-auto text-[11px] text-[#8b9ac4]">
          {type === "market" ? `taker ${fees.takerPct}%` : `maker ${fees.makerPct}%`}
        </span>
      </div>

      {type === "limit" ? (
        <div className="mt-4">
          <label className="tm-label" htmlFor="limit-price">
            Limit price (USD)
          </label>
          <input
            id="limit-price"
            inputMode="decimal"
            className="tm-input mt-1.5"
            placeholder={price ? price.toFixed(2) : "0.00"}
            value={limitPrice}
            onChange={(e) => setLimitPrice(e.target.value.replace(/[^0-9.]/g, ""))}
          />
        </div>
      ) : null}

      <div className="mt-4">
        <div className="flex items-center justify-between">
          <label className="tm-label" htmlFor="order-amount">
            {amountType === "usd" ? "Amount in USD" : `Amount in ${symbol}`}
          </label>
          <div className="flex items-center gap-1 rounded-full border border-[#1c2a4d] p-0.5 text-[10px] font-bold uppercase">
            {(["usd", "unit"] as const).map((u) => (
              <button
                key={u}
                onClick={() => setAmountType(u)}
                className={`rounded-full px-2 py-0.5 ${amountType === u ? "bg-[#6d8dff] text-[#050a17]" : "text-[#8b9ac4]"}`}
              >
                {u === "usd" ? "USD" : symbol}
              </button>
            ))}
          </div>
        </div>
        <div className="relative mt-1.5">
          <span className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-sm font-bold text-[#8b9ac4]">
            {amountType === "usd" ? "$" : symbol}
          </span>
          <input
            id="order-amount"
            inputMode="decimal"
            className="tm-input pl-11 text-base"
            value={amount}
            onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))}
          />
          <button
            onClick={() =>
              setAmount(
                amountType === "usd"
                  ? Math.max(0, cashAvailable).toFixed(2)
                  : Math.max(0, assetAvailable).toString(),
              )
            }
            className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg border border-[#253663] px-2 py-1 text-[10px] font-bold uppercase tracking-widest text-[#8ea6ff]"
          >
            Max
          </button>
        </div>
      </div>

      <dl className="mt-4 space-y-2 border-t border-[#16233f] pt-3 text-sm">
        <div className="flex justify-between">
          <dt className="text-[#8b9ac4]">Estimated quantity</dt>
          <dd className="font-semibold tabular-nums">{fmtCrypto(quote.qty, symbol)}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="text-[#8b9ac4]">{type === "limit" ? "Maker" : "Taker"} fee</dt>
          <dd className="font-semibold tabular-nums">{fmtUsd(quote.fee)}</dd>
        </div>
        <div className="flex justify-between text-base">
          <dt className="text-[#8b9ac4]">{side === "buy" ? "Estimated total" : "You receive"}</dt>
          <dd className="font-bold tabular-nums">{fmtUsd(quote.total)}</dd>
        </div>
      </dl>

      {guest ? (
        <a href="/signup" className={`tm-btn ${activeTone} mt-4 w-full`}>
          Open account to trade {symbol}
        </a>
      ) : (
        <button
          onClick={submit}
          disabled={!canSubmit || insufficient}
          className={`tm-btn ${activeTone} mt-4 w-full`}
        >
          {busy
            ? "Submitting…"
            : insufficient
              ? side === "buy"
                ? "Insufficient USD"
                : `Insufficient ${symbol}`
              : `${side === "buy" ? "Buy" : "Sell"} ${symbol}`}
        </button>
      )}

      <p className="mt-3 text-[11px] leading-relaxed text-[#6f7fa8]">
        Orders execute against the live {ticker?.source ? ticker.source : "exchange"} book. Limit orders rest on the book and
        fill automatically when the market crosses your price.
      </p>
    </div>
  );
}
