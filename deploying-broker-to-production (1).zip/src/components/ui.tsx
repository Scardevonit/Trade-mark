"use client";

import { fmtPct, fmtUsd } from "@/lib/money";

export function Sparkline({ points, stroke = "#2fd6a5", height = 40 }: { points: number[]; stroke?: string; height?: number }) {
  if (points.length < 2) return <div style={{ height }} className="w-full rounded bg-white/5" />;
  const min = Math.min(...points);
  const max = Math.max(...points);
  const span = max - min || 1;
  const width = 100;
  const step = width / (points.length - 1);
  const coords = points.map((p, i) => `${(i * step).toFixed(2)},${(height - ((p - min) / span) * (height - 4) - 2).toFixed(2)}`);
  const id = `spark-${stroke.replace("#", "")}`;
  return (
    <svg viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" className="w-full" style={{ height }}>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={stroke} stopOpacity="0.35" />
          <stop offset="100%" stopColor={stroke} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={`0,${height} ${coords.join(" ")} ${width},${height}`} fill={`url(#${id})`} />
      <polyline points={coords.join(" ")} fill="none" stroke={stroke} strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

export function Delta({ value, className = "" }: { value: number | null | undefined; className?: string }) {
  const v = value ?? 0;
  const up = v >= 0;
  return <span className={`${up ? "tm-up" : "tm-down"} font-semibold ${className}`}>{fmtPct(v)}</span>;
}

export function Money({ value, className = "" }: { value: number; className?: string }) {
  return <span className={className}>{fmtUsd(value)}</span>;
}

export function Stat({ label, value, sub, tone }: { label: string; value: string; sub?: React.ReactNode; tone?: "up" | "down" }) {
  return (
    <div className="rounded-2xl border border-[#1c2a4d] bg-[#0b142c]/80 p-4">
      <p className="tm-label">{label}</p>
      <p className={`mt-1 text-xl font-bold sm:text-2xl ${tone === "up" ? "tm-up" : tone === "down" ? "tm-down" : ""}`}>{value}</p>
      {sub ? <div className="mt-1 text-xs text-[#8b9ac4]">{sub}</div> : null}
    </div>
  );
}

export function Pill({ children, tone = "neutral" }: { children: React.ReactNode; tone?: "neutral" | "up" | "down" | "blue" | "warn" }) {
  const tones: Record<string, string> = {
    neutral: "bg-white/5 text-[#8b9ac4] border-white/10",
    up: "bg-[#2fd6a5]/12 text-[#2fd6a5] border-[#2fd6a5]/30",
    down: "bg-[#ff5f6d]/12 text-[#ff5f6d] border-[#ff5f6d]/30",
    blue: "bg-[#6d8dff]/12 text-[#8ea6ff] border-[#6d8dff]/30",
    warn: "bg-amber-400/10 text-amber-300 border-amber-400/30",
  };
  return (
    <span className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.14em] ${tones[tone]}`}>
      {children}
    </span>
  );
}

export function Toast({ notice, onDone }: { notice: { tone: "ok" | "error" | "info"; message: string } | null; onDone: () => void }) {
  if (!notice) return null;
  const tone =
    notice.tone === "ok"
      ? "border-[#2fd6a5]/40 bg-[#0c2a24] text-[#7ff0cd]"
      : notice.tone === "error"
        ? "border-[#ff5f6d]/40 bg-[#2a1219] text-[#ffb3ba]"
        : "border-[#6d8dff]/40 bg-[#101c3d] text-[#b9c7ff]";
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-24 z-50 flex justify-center px-4 sm:bottom-8">
      <div className={`pointer-events-auto flex items-center gap-3 rounded-2xl border px-4 py-3 text-sm font-semibold shadow-2xl ${tone}`}>
        <span className="max-w-[70vw]">{notice.message}</span>
        <button onClick={onDone} className="rounded-lg px-2 py-1 text-xs uppercase tracking-widest opacity-70 hover:opacity-100">
          Dismiss
        </button>
      </div>
    </div>
  );
}

export function AssetIcon({ symbol, color }: { symbol: string; color?: string }) {
  return (
    <span
      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[11px] font-black"
      style={{ background: `${color ?? "#6d8dff"}22`, color: color ?? "#8ea6ff", border: `1px solid ${color ?? "#6d8dff"}44` }}
    >
      {symbol.slice(0, 3)}
    </span>
  );
}

export function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-[#22315a] p-8 text-center">
      <p className="font-semibold text-[#c9d4f5]">{title}</p>
      {hint ? <p className="mt-1 text-sm text-[#8b9ac4]">{hint}</p> : null}
    </div>
  );
}
