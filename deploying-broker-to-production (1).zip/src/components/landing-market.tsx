"use client";

import { useState } from "react";
import { AppProvider, useAppData } from "@/components/app-provider";
import { MarketList } from "@/components/market-list";
import { TradeTicket } from "@/components/trade-ticket";
import type { Ticker } from "@/lib/types";

function LandingMarketInner() {
  const { tickers } = useAppData();
  const [symbol, setSymbol] = useState("BTC");
  const ticker = tickers.find((t) => t.symbol === symbol);

  return (
    <div className="grid gap-4 lg:grid-cols-[1.15fr_1fr]">
      <MarketList selectable selected={symbol} onSelect={setSymbol} limit={9} />
      <div className="space-y-4">
        <TradeTicket symbol={symbol} guest />
        <div className="tm-panel p-4 text-xs leading-relaxed text-[#8b9ac4] sm:p-5">
          <p className="tm-label">Execution</p>
          <p className="mt-2">
            Orders route to the live {ticker?.source ?? "exchange"} book at the current bid/ask. Cash and coin are settled into
            your account ledger immediately, with locked balances reserved for any resting limit orders.
          </p>
        </div>
      </div>
    </div>
  );
}

export function LandingMarket({ tickers }: { tickers: Ticker[] }) {
  return (
    <AppProvider initialTickers={tickers} withAccount={false}>
      <LandingMarketInner />
    </AppProvider>
  );
}
