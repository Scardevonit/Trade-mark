"use client";

import { useCallback, useEffect, useState } from "react";
import { useAppData } from "@/components/app-provider";
import { EmptyState, Pill, Stat } from "@/components/ui";
import { fmtCrypto, fmtDateTime, fmtUsd } from "@/lib/money";
import type { LedgerRow, TransferRow } from "@/lib/types";

type WalletPayload = {
  portfolio: { cashUsd: number; cashAvailable: number; cashLocked: number; equityUsd: number };
  transfers: TransferRow[];
  ledger: LedgerRow[];
  addresses: Record<string, string>;
  settings: { autoApproveDeposits: boolean; autoApproveWithdrawals: boolean; withdrawalFeeUsd: number; hasCardRail: boolean };
};

const DEPOSIT_ASSETS = ["USD", "BTC", "ETH", "USDC", "SOL"];

export function WalletView() {
  const { refreshAccount, setNotice } = useAppData();
  const [data, setData] = useState<WalletPayload | null>(null);
  const [tab, setTab] = useState<"deposit" | "withdraw">("deposit");
  const [asset, setAsset] = useState("USD");
  const [amount, setAmount] = useState("100");
  const [method, setMethod] = useState<"card" | "crypto">("card");
  const [txRef, setTxRef] = useState("");
  const [destination, setDestination] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const res = await fetch("/api/wallet", { cache: "no-store" });
    if (res.ok) setData((await res.json()) as WalletPayload);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function submitDeposit() {
    setBusy(true);
    const res = await fetch("/api/wallet/deposit", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ asset, amount: Number(amount), method: asset === "USD" ? method : "crypto", txRef }),
    });
    const json = (await res.json()) as { error?: string; pendingReview?: boolean };
    setBusy(false);
    if (!res.ok) {
      setNotice({ tone: "error", message: json.error ?? "Deposit failed" });
      return;
    }
    setNotice(
      json.pendingReview
        ? { tone: "info", message: "Deposit logged. It settles once the rail confirms your transaction." }
        : { tone: "ok", message: `Deposited ${fmtUsd(Number(amount))} to your ${asset} balance` },
    );
    setTxRef("");
    await Promise.all([load(), refreshAccount()]);
  }

  async function submitWithdrawal() {
    setBusy(true);
    const res = await fetch("/api/wallet/withdraw", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ asset, amount: Number(amount), destination }),
    });
    const json = (await res.json()) as { error?: string };
    setBusy(false);
    if (!res.ok) {
      setNotice({ tone: "error", message: json.error ?? "Withdrawal failed" });
      return;
    }
    setNotice({ tone: "ok", message: "Withdrawal requested — funds are locked until it settles" });
    setDestination("");
    await Promise.all([load(), refreshAccount()]);
  }

  const addresses = data?.addresses ?? {};
  const settings = data?.settings;

  return (
    <div className="space-y-4">
      <div>
        <p className="tm-label">Wallet</p>
        <h1 className="text-2xl font-black tracking-tight sm:text-3xl">Funding & balances</h1>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Cash" value={fmtUsd(data?.portfolio.cashUsd ?? 0)} />
        <Stat label="Available to trade" value={fmtUsd(data?.portfolio.cashAvailable ?? 0)} />
        <Stat label="Locked" value={fmtUsd(data?.portfolio.cashLocked ?? 0)} sub="open orders + withdrawals" />
        <Stat label="Total equity" value={fmtUsd(data?.portfolio.equityUsd ?? 0)} />
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_1fr]">
        <section className="tm-panel p-4 sm:p-5">
          <div className="flex gap-1 rounded-xl border border-[#1c2a4d] bg-[#060b18]/70 p-1">
            {(["deposit", "withdraw"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`flex-1 rounded-lg py-2 text-sm font-bold capitalize ${tab === t ? "bg-[#6d8dff] text-[#050a17]" : "text-[#8b9ac4]"}`}
              >
                {t}
              </button>
            ))}
          </div>

          <div className="mt-4 space-y-4">
            <div>
              <label className="tm-label" htmlFor="asset">
                Asset
              </label>
              <select
                id="asset"
                className="tm-input mt-1.5"
                value={asset}
                onChange={(e) => {
                  const next = e.target.value;
                  setAsset(next);
                  if (next !== "USD") setMethod("crypto");
                }}
              >
                {DEPOSIT_ASSETS.map((a) => (
                  <option key={a} value={a} className="bg-[#0a1226]">
                    {a}
                  </option>
                ))}
              </select>
            </div>

            {tab === "deposit" && asset === "USD" ? (
              <div>
                <label className="tm-label">Funding method</label>
                <div className="mt-1.5 flex gap-2">
                  {(["card", "crypto"] as const).map((m) => (
                    <button
                      key={m}
                      onClick={() => setMethod(m)}
                      className={`flex-1 rounded-xl border px-3 py-2 text-sm font-semibold capitalize ${
                        method === m ? "border-[#6d8dff] bg-[#6d8dff]/15 text-[#b9c7ff]" : "border-[#1c2a4d] text-[#8b9ac4]"
                      }`}
                    >
                      {m === "card" ? "Card / ACH" : "Stablecoin (USDC)"}
                    </button>
                  ))}
                </div>
                {!settings?.hasCardRail && method === "card" ? (
                  <p className="mt-2 rounded-xl border border-amber-400/30 bg-amber-400/10 px-3 py-2 text-[11px] text-amber-200">
                    No payment processor key configured. Requests are logged and settle once operations confirms the transfer.
                  </p>
                ) : null}
              </div>
            ) : null}

            <div>
              <label className="tm-label" htmlFor="amount">
                Amount ({asset})
              </label>
              <input
                id="amount"
                inputMode="decimal"
                className="tm-input mt-1.5"
                value={amount}
                onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))}
              />
            </div>

            {tab === "deposit" && method === "crypto" && asset === "USD" ? (
              <div>
                <label className="tm-label" htmlFor="txref">
                  Transaction reference
                </label>
                <input
                  id="txref"
                  className="tm-input mt-1.5 text-xs"
                  placeholder="USDC tx hash or bank reference"
                  value={txRef}
                  onChange={(e) => setTxRef(e.target.value)}
                />
              </div>
            ) : null}

            {tab === "deposit" && asset !== "USD" ? (
              <div className="rounded-xl border border-[#1c2a4d] bg-[#060b18]/70 p-3">
                <p className="tm-label">Deposit address · {asset}</p>
                <p className="mt-1.5 break-all font-mono text-xs text-[#b9c7ff]">
                  {addresses[asset] || "Not configured — set DEPOSIT_ADDRESS_" + asset + " in your environment"}
                </p>
                <p className="mt-2 text-[11px] text-[#6f7fa8]">
                  Send only {asset} to this address. {settings?.autoApproveDeposits ? "Credits settle automatically." : "Credits settle after confirmation."}
                </p>
              </div>
            ) : null}

            {tab === "withdraw" ? (
              <>
                <div>
                  <label className="tm-label" htmlFor="destination">
                    Destination {asset === "USD" ? "bank reference" : "address"}
                  </label>
                  <input
                    id="destination"
                    className="tm-input mt-1.5 font-mono text-xs"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    placeholder={asset === "USD" ? "Bank account ref" : "Wallet address"}
                  />
                </div>
                <p className="text-[11px] text-[#6f7fa8]">
                  Network fee {fmtUsd(settings?.withdrawalFeeUsd ?? 0)} · funds are locked immediately and released if the
                  withdrawal is rejected.
                </p>
              </>
            ) : null}

            <button
              onClick={tab === "deposit" ? submitDeposit : submitWithdrawal}
              disabled={busy || !(Number(amount) > 0) || (tab === "withdraw" && destination.length < 8)}
              className={`tm-btn ${tab === "deposit" ? "tm-btn-mint" : "tm-btn-primary"} w-full`}
            >
              {busy ? "Submitting…" : tab === "deposit" ? `Deposit ${asset}` : `Withdraw ${asset}`}
            </button>
          </div>
        </section>

        <section className="tm-panel overflow-hidden">
          <header className="border-b border-[#131f3c] px-4 py-4 sm:px-5">
            <h2 className="text-base font-bold sm:text-lg">Transfers</h2>
            <p className="text-xs text-[#8b9ac4]">Deposits and withdrawals on your account</p>
          </header>
          {!data?.transfers.length ? (
            <div className="p-4 sm:p-5">
              <EmptyState title="No transfers yet" hint="Deposit funds to start trading." />
            </div>
          ) : (
            <ul className="divide-y divide-[#131f3c]">
              {data.transfers.map((t) => (
                <li key={t.id} className="flex items-center gap-3 px-4 py-3 sm:px-5">
                  <span className={`text-lg ${t.kind === "deposit" ? "tm-up" : "tm-down"}`}>{t.kind === "deposit" ? "↓" : "↑"}</span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold">
                      {t.kind === "deposit" ? "Deposit" : "Withdrawal"} · {t.asset}{" "}
                      <span className="text-[#8b9ac4]">via {t.method}</span>
                    </p>
                    <p className="truncate text-[11px] text-[#8b9ac4]">
                      {fmtDateTime(t.createdAt)} {t.destination ? `→ ${t.destination.slice(0, 14)}…` : ""}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold tabular-nums">{fmtCrypto(t.amount, t.asset)}</p>
                    <Pill tone={t.status === "completed" ? "up" : t.status === "pending" ? "warn" : "down"}>{t.status}</Pill>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <section className="tm-panel overflow-hidden">
        <header className="border-b border-[#131f3c] px-4 py-4 sm:px-5">
          <h2 className="text-base font-bold sm:text-lg">Account ledger</h2>
          <p className="text-xs text-[#8b9ac4]">Every balance change, in order</p>
        </header>
        {!data?.ledger.length ? (
          <div className="p-4 sm:p-5">
            <EmptyState title="Ledger is empty" />
          </div>
        ) : (
          <div className="tm-scroll overflow-x-auto">
            <table className="w-full min-w-[600px] text-sm">
              <thead>
                <tr className="border-b border-[#131f3c] text-left text-[11px] uppercase tracking-widest text-[#8b9ac4]">
                  <th className="px-4 py-2 font-semibold sm:px-5">Kind</th>
                  <th className="px-4 py-2 font-semibold">Asset</th>
                  <th className="px-4 py-2 font-semibold">Amount</th>
                  <th className="px-4 py-2 font-semibold">Balance after</th>
                  <th className="px-4 py-2 font-semibold">Note</th>
                  <th className="px-4 py-2 font-semibold">When</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#131f3c]">
                {data.ledger.map((entry) => (
                  <tr key={entry.id}>
                    <td className="px-4 py-3 capitalize sm:px-5">{entry.kind}</td>
                    <td className="px-4 py-3 font-semibold">{entry.asset}</td>
                    <td className={`px-4 py-3 tabular-nums font-semibold ${entry.amount >= 0 ? "tm-up" : "tm-down"}`}>
                      {entry.amount >= 0 ? "+" : ""}
                      {fmtCrypto(entry.amount, entry.asset)}
                    </td>
                    <td className="px-4 py-3 tabular-nums text-[#8b9ac4]">{fmtCrypto(entry.balanceAfter, entry.asset)}</td>
                    <td className="max-w-[220px] truncate px-4 py-3 text-[#8b9ac4]">{entry.note}</td>
                    <td className="px-4 py-3 text-[#8b9ac4]">{fmtDateTime(entry.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
