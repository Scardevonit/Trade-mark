"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useAppData } from "@/components/app-provider";
import { AssetIcon, Delta } from "@/components/ui";
import { INSTRUMENT_COLORS } from "@/lib/instrument-meta";
import { fmtCrypto, fmtUsd } from "@/lib/money";

export function MarketList({
  limit,
  filterTo,
  selectable = false,
  selected,
  onSelect,
  title = "Market watch",
}: {
  limit?: number;
  filterTo?: string[];
  selectable?: boolean;
  selected?: string;
  onSelect?: (symbol: string) => void;
  title?: string;
}) {
  const { tickers, live } = useAppData();
  const [query, setQuery] = useState("");

  const rows = useMemo(() => {
    let list = tickers;
    if (filterTo?.length) list = list.filter((t) => filterTo.includes(t.symbol));
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter((t) => t.symbol.toLowerCase().includes(q) || t.name.toLowerCase().includes(q));
    }
    return limit ? list.slice(0, limit) : list;
  }, [filterTo, limit, query, tickers]);

  return (
    <section className="tm-panel overflow-hidden">
      <header className="flex items-center justify-between gap-3 border-b border-[#16233f] px-4 py-4 sm:px-5">
        <div>
          <h2 className="text-base font-bold sm:text-lg">{title}</h2>
          <p className="text-xs text-[#8b9ac4]">Live prices · USD</p>
        </div>
        <span className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.16em]">
          <span className={`h-2 w-2 rounded-full ${live ? "animate-pulse bg-[#2fd6a5]" : "bg-amber-400"}`} />
          <span className={live ? "text-[#2fd6a5]" : "text-amber-300"}>{live ? "Live market" : "Connecting"}</span>
        </span>
      </header>

      <div className="px-4 pt-3 sm:px-5">
        <input
          className="tm-input py-2 text-sm"
          placeholder="Search markets"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      <div className="tm-scroll mt-2 max-h-[26rem] overflow-y-auto px-2 pb-3 sm:px-3">
        {rows.length === 0 ? (
          <p className="px-3 py-8 text-center text-sm text-[#8b9ac4]">Loading live markets…</p>
        ) : (
          <ul className="divide-y divide-[#131f3c]">
            {rows.map((t) => {
              const isSel = selected === t.symbol;
              const content = (
                <>
                  <AssetIcon symbol={t.symbol} color={INSTRUMENT_COLORS[t.symbol]} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">
                      {t.name} <span className="text-[#8b9ac4]">· {t.symbol}</span>
                    </p>
                    <p className="text-[11px] text-[#8b9ac4]">
                      vol {fmtUsd(t.volume24hUsd ?? 0, { compact: true })} · 24h {fmtUsd(t.low24h ?? 0, { compact: true })}–
                      {fmtUsd(t.high24h ?? 0, { compact: true })}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold tabular-nums">{fmtUsd(t.price)}</p>
                    <p className="text-xs">
                      <Delta value={t.change24h} />
                    </p>
                  </div>
                </>
              );
              return (
                <li key={t.symbol}>
                  {selectable ? (
                    <button
                      onClick={() => onSelect?.(t.symbol)}
                      className={`flex w-full items-center gap-3 rounded-xl px-2 py-2.5 text-left transition hover:bg-white/[0.04] ${
                        isSel ? "bg-[#6d8dff]/10 ring-1 ring-[#6d8dff]/40" : ""
                      }`}
                    >
                      {content}
                    </button>
                  ) : (
                    <Link
                      href={`/app/trade/${t.symbol}`}
                      className="flex items-center gap-3 rounded-xl px-2 py-2.5 transition hover:bg-white/[0.04]"
                    >
                      {content}
                    </Link>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </div>
      {rows.length ? (
        <p className="border-t border-[#16233f] px-4 py-2.5 text-[11px] text-[#6f7fa8] sm:px-5">
          {fmtCrypto(rows.length)} markets · refreshed {new Date(tickers[0]?.updatedAt ?? Date.now()).toLocaleTimeString()}
        </p>
      ) : null}
    </section>
  );
}
