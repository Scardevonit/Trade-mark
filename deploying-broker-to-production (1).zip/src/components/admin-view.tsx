"use client";

import { useCallback, useEffect, useState } from "react";
import { useAppData } from "@/components/app-provider";
import { EmptyState, Pill } from "@/components/ui";
import { fmtCrypto, fmtDateTime, fmtUsd } from "@/lib/money";
import type { TransferRow } from "@/lib/types";

export function AdminView() {
  const { setNotice } = useAppData();
  const [transfers, setTransfers] = useState<TransferRow[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const res = await fetch("/api/admin/transfers", { cache: "no-store" });
    if (res.ok) {
      const json = (await res.json()) as { transfers?: TransferRow[] };
      setTransfers(json.transfers ?? []);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
    const timer = window.setInterval(() => void load(), 20_000);
    return () => window.clearInterval(timer);
  }, [load]);

  async function act(id: string, action: "approve" | "reject") {
    setBusy(id);
    const res = await fetch("/api/admin/transfers", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id, action }),
    });
    const json = (await res.json()) as { error?: string };
    setBusy(null);
    setNotice(
      res.ok ? { tone: "ok", message: `Transfer ${action === "approve" ? "settled" : "rejected"}` } : { tone: "error", message: json.error ?? "Action failed" },
    );
    await load();
  }

  return (
    <div className="space-y-4">
      <div>
        <p className="tm-label">Operations</p>
        <h1 className="text-2xl font-black tracking-tight sm:text-3xl">Pending transfers</h1>
        <p className="mt-1 text-sm text-[#8b9ac4]">
          Approve inbound funding to credit client balances, or reject to release locked withdrawal funds back to the client.
        </p>
      </div>

      <section className="tm-panel overflow-hidden">
        <header className="flex items-center justify-between border-b border-[#131f3c] px-4 py-4 sm:px-5">
          <h2 className="text-base font-bold sm:text-lg">Queue</h2>
          <Pill tone={transfers.length ? "warn" : "up"}>{transfers.length} pending</Pill>
        </header>
        {loading ? (
          <p className="px-4 py-8 text-center text-sm text-[#8b9ac4] sm:px-5">Loading queue…</p>
        ) : transfers.length === 0 ? (
          <div className="p-4 sm:p-5">
            <EmptyState title="Queue is clear" hint="New funding requests appear here in real time." />
          </div>
        ) : (
          <ul className="divide-y divide-[#131f3c]">
            {transfers.map((t) => (
              <li key={t.id} className="flex flex-wrap items-center gap-3 px-4 py-4 sm:px-5">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold">
                    {t.kind === "deposit" ? "Deposit" : "Withdrawal"} · {fmtCrypto(t.amount, t.asset)}{" "}
                    <span className="text-[#8b9ac4]">via {t.method}</span>
                  </p>
                  <p className="truncate text-[11px] text-[#8b9ac4]">
                    {t.userName} · {t.userEmail} · {fmtDateTime(t.createdAt)}
                    {t.destination ? ` → ${t.destination.slice(0, 18)}…` : ""}
                  </p>
                  {t.txRef ? <p className="truncate font-mono text-[11px] text-[#6f7fa8]">ref {t.txRef}</p> : null}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => act(t.id, "approve")}
                    disabled={busy === t.id}
                    className="tm-btn tm-btn-mint px-3 py-2 text-xs"
                  >
                    {busy === t.id ? "…" : "Approve"}
                  </button>
                  <button
                    onClick={() => act(t.id, "reject")}
                    disabled={busy === t.id}
                    className="tm-btn tm-btn-ghost px-3 py-2 text-xs"
                  >
                    Reject
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="tm-panel p-4 text-sm leading-relaxed text-[#a9b6d9] sm:p-5">
        <p className="tm-label">Go-live checklist</p>
        <ul className="mt-3 space-y-2 text-sm">
          <li>• Set <code className="text-[#8ea6ff]">ADMIN_EMAILS</code> so your address gets operations access.</li>
          <li>• Add deposit addresses (<code className="text-[#8ea6ff]">DEPOSIT_ADDRESS_BTC/ETH/USDC/SOL</code>) from your custody provider.</li>
          <li>• Add <code className="text-[#8ea6ff]">STRIPE_SECRET_KEY</code> to enable instant card/ACH funding.</li>
          <li>• Flip <code className="text-[#8ea6ff]">AUTO_APPROVE_DEPOSITS</code> / <code className="text-[#8ea6ff]">AUTO_APPROVE_WITHDRAWALS</code> once your rails can be trusted automatically.</li>
          <li>• Set <code className="text-[#8ea6ff]">WELCOME_CREDIT_USD=0</code> before opening to the public.</li>
        </ul>
      </section>
    </div>
  );
}
