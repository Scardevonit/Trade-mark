"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

export function AuthForm({ mode }: { mode: "login" | "signup" }) {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [country, setCountry] = useState("US");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/auth/${mode === "signup" ? "signup" : "login"}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(mode === "signup" ? { email, password, fullName, country } : { email, password }),
      });
      const json = (await res.json()) as { error?: string };
      if (!res.ok) {
        setError(json.error ?? "Something went wrong");
        setBusy(false);
        return;
      }
      router.replace("/app");
    } catch {
      setError("Network error — please try again");
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="tm-panel w-full max-w-md p-6">
      <Link href="/" className="text-xl font-black tracking-tight">
        tidemark<span className="text-[#6d8dff]">.</span>
      </Link>
      <h1 className="mt-5 text-2xl font-black">{mode === "signup" ? "Open your account" : "Welcome back"}</h1>
      <p className="mt-1 text-sm text-[#8b9ac4]">
        {mode === "signup"
          ? "Real market prices, real order execution, live cash ledger. Takes about 30 seconds."
          : "Sign in to trade the live book and manage your balances."}
      </p>

      <div className="mt-6 space-y-4">
        {mode === "signup" ? (
          <div>
            <label className="tm-label" htmlFor="fullName">
              Full name
            </label>
            <input
              id="fullName"
              className="tm-input mt-1.5"
              autoComplete="name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Alex Rivera"
              required
            />
          </div>
        ) : null}

        <div>
          <label className="tm-label" htmlFor="email">
            Email
          </label>
          <input
            id="email"
            type="email"
            className="tm-input mt-1.5"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            required
          />
        </div>

        <div>
          <label className="tm-label" htmlFor="password">
            Password
          </label>
          <input
            id="password"
            type="password"
            className="tm-input mt-1.5"
            autoComplete={mode === "signup" ? "new-password" : "current-password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="At least 8 characters"
            minLength={8}
            required
          />
        </div>

        {mode === "signup" ? (
          <div>
            <label className="tm-label" htmlFor="country">
              Country of residence
            </label>
            <select id="country" className="tm-input mt-1.5" value={country} onChange={(e) => setCountry(e.target.value)}>
              {["US", "GB", "CA", "DE", "FR", "NG", "KE", "ZA", "IN", "AU", "BR", "MX", "JP", "SG", "AE"].map((c) => (
                <option key={c} value={c} className="bg-[#0a1226]">
                  {c}
                </option>
              ))}
            </select>
          </div>
        ) : null}
      </div>

      {error ? (
        <p className="mt-4 rounded-xl border border-[#ff5f6d]/40 bg-[#2a1219] px-3 py-2 text-sm text-[#ffb3ba]">{error}</p>
      ) : null}

      <button type="submit" disabled={busy} className="tm-btn tm-btn-primary mt-6 w-full">
        {busy ? "Working…" : mode === "signup" ? "Create account" : "Sign in"}
      </button>

      <p className="mt-4 text-center text-sm text-[#8b9ac4]">
        {mode === "signup" ? (
          <>
            Already have an account?{" "}
            <Link href="/login" className="font-semibold text-[#8ea6ff]">
              Sign in
            </Link>
          </>
        ) : (
          <>
            New to tidemark?{" "}
            <Link href="/signup" className="font-semibold text-[#8ea6ff]">
              Open an account
            </Link>
          </>
        )}
      </p>
    </form>
  );
}
