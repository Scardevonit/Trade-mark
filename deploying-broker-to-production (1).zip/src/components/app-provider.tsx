"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import type { AccountSnapshot, Notice, OrderRow, Ticker } from "@/lib/types";

type AppData = {
  tickers: Ticker[];
  account: AccountSnapshot | null;
  live: boolean;
  loading: boolean;
  notice: Notice;
  setNotice: (notice: Notice) => void;
  refresh: () => Promise<void>;
  refreshAccount: () => Promise<void>;
  placeOrder: (input: {
    symbol: string;
    side: "buy" | "sell";
    type: "market" | "limit";
    amountType: "usd" | "unit";
    amount: number;
    limitPrice?: number | null;
  }) => Promise<{ ok: boolean; order?: OrderRow; error?: string }>;
  cancelOrder: (id: string) => Promise<boolean>;
};

const Ctx = createContext<AppData | null>(null);

export function useAppData(): AppData {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useAppData must be used inside <AppProvider>");
  return ctx;
}

export function AppProvider({
  children,
  initialTickers = [],
  withAccount = true,
}: {
  children: React.ReactNode;
  initialTickers?: Ticker[];
  withAccount?: boolean;
}) {
  const [tickers, setTickers] = useState<Ticker[]>(initialTickers);
  const [account, setAccount] = useState<AccountSnapshot | null>(null);
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState<Notice>(null);
  const tickersInFlight = useRef(false);

  const loadTickers = useCallback(async () => {
    if (tickersInFlight.current) return;
    tickersInFlight.current = true;
    try {
      const res = await fetch("/api/market/tickers", { cache: "no-store" });
      const json = (await res.json()) as { tickers?: Ticker[] };
      if (json.tickers?.length) setTickers(json.tickers);
    } catch {
      /* keep last known prices */
    } finally {
      tickersInFlight.current = false;
    }
  }, []);

  const refreshAccount = useCallback(async () => {
    if (!withAccount) return;
    try {
      const res = await fetch("/api/account", { cache: "no-store" });
      if (!res.ok) return;
      const json = (await res.json()) as AccountSnapshot;
      setAccount(json);
    } catch {
      /* ignore transient errors */
    }
  }, [withAccount]);

  const refresh = useCallback(async () => {
    setLoading(true);
    await Promise.all([loadTickers(), refreshAccount()]);
    setLoading(false);
  }, [loadTickers, refreshAccount]);

  useEffect(() => {
    void loadTickers();
    void refreshAccount();
    const timer = setInterval(() => {
      if (typeof document !== "undefined" && document.visibilityState === "hidden") return;
      void loadTickers();
    }, 6000);
    const accountTimer = setInterval(() => {
      if (typeof document !== "undefined" && document.visibilityState === "hidden") return;
      void refreshAccount();
    }, 9000);
    const onVisible = () => {
      if (document.visibilityState === "visible") void refresh();
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      clearInterval(timer);
      clearInterval(accountTimer);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [loadTickers, refreshAccount, refresh]);

  const placeOrder = useCallback<AppData["placeOrder"]>(
    async (input) => {
      try {
        const res = await fetch("/api/orders", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(input),
        });
        const json = (await res.json()) as { order?: OrderRow; error?: string };
        if (!res.ok) return { ok: false, error: json.error ?? "Order rejected" };
        await Promise.all([refreshAccount(), loadTickers()]);
        return { ok: true, order: json.order };
      } catch {
        return { ok: false, error: "Network error placing order" };
      }
    },
    [loadTickers, refreshAccount],
  );

  const cancelOrder = useCallback<AppData["cancelOrder"]>(
    async (id) => {
      try {
        const res = await fetch(`/api/orders/${id}/cancel`, { method: "POST" });
        if (!res.ok) return false;
        await refreshAccount();
        return true;
      } catch {
        return false;
      }
    },
    [refreshAccount],
  );

  const value = useMemo<AppData>(
    () => ({
      tickers,
      account,
      live: tickers.length > 0,
      loading,
      notice,
      setNotice,
      refresh,
      refreshAccount,
      placeOrder,
      cancelOrder,
    }),
    [tickers, account, loading, notice, refresh, refreshAccount, placeOrder, cancelOrder],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
