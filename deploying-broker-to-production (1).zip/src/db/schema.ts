import {
  boolean,
  doublePrecision,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

/**
 * tidemark. — live brokerage core schema
 *
 * Everything below is real money-movement state: accounts, locked funds,
 * resting orders, fills, and an immutable ledger of every balance change.
 */

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    email: text("email").notNull(),
    passwordHash: text("password_hash").notNull(),
    fullName: text("full_name").notNull(),
    country: text("country").notNull().default("US"),
    role: text("role").notNull().default("user"), // user | admin
    status: text("status").notNull().default("active"), // active | suspended
    tier: text("tier").notNull().default("standard"), // standard | pro
    onboardedAt: timestamp("onboarded_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("users_email_unique").on(table.email)],
);

export const sessions = pgTable(
  "sessions",
  {
    token: text("token").primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    userAgent: text("user_agent"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  },
  (table) => [index("sessions_user_idx").on(table.userId)],
);

/** One row per (account, asset). `locked` holds funds reserved by open orders. */
export const balances = pgTable(
  "balances",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    asset: text("asset").notNull(), // USD, BTC, ETH ...
    available: doublePrecision("available").notNull().default(0),
    locked: doublePrecision("locked").notNull().default(0),
    /** Average acquisition cost in USD per unit, used for realised/unrealised P/L. */
    avgCost: doublePrecision("avg_cost").notNull().default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("balances_user_asset_unique").on(table.userId, table.asset)],
);

export const orders = pgTable(
  "orders",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    clientId: text("client_id"),
    symbol: text("symbol").notNull(), // BTC, ETH ...
    side: text("side").notNull(), // buy | sell
    type: text("type").notNull(), // market | limit
    status: text("status").notNull(), // open | filled | canceled | rejected
    timeInForce: text("time_in_force").notNull().default("gtc"),
    limitPrice: doublePrecision("limit_price"),
    /** Market buys are funded by a USD notional, market sells by a base quantity. */
    quoteAmount: doublePrecision("quote_amount"),
    quantity: doublePrecision("quantity"),
    filledQuantity: doublePrecision("filled_quantity").notNull().default(0),
    avgFillPrice: doublePrecision("avg_fill_price"),
    feePaid: doublePrecision("fee_paid").notNull().default(0),
    notional: doublePrecision("notional").notNull().default(0),
    lockedAmount: doublePrecision("locked_amount").notNull().default(0),
    lockedAsset: text("locked_asset"),
    rejectReason: text("reject_reason"),
    filledAt: timestamp("filled_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("orders_user_idx").on(table.userId, table.createdAt),
    index("orders_status_idx").on(table.status),
  ],
);

export const trades = pgTable(
  "trades",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orderId: uuid("order_id")
      .notNull()
      .references(() => orders.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    symbol: text("symbol").notNull(),
    side: text("side").notNull(),
    price: doublePrecision("price").notNull(),
    quantity: doublePrecision("quantity").notNull(),
    notional: doublePrecision("notional").notNull(),
    fee: doublePrecision("fee").notNull(),
    liquidity: text("liquidity").notNull().default("taker"), // taker | maker
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("trades_user_idx").on(table.userId, table.createdAt)],
);

/** Append-only double-entry style log of every balance mutation. */
export const ledgerEntries = pgTable(
  "ledger_entries",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    asset: text("asset").notNull(),
    amount: doublePrecision("amount").notNull(), // signed
    balanceAfter: doublePrecision("balance_after").notNull(),
    kind: text("kind").notNull(), // deposit | withdrawal | trade | fee | promo | adjustment
    refType: text("ref_type"),
    refId: text("ref_id"),
    note: text("note"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("ledger_user_idx").on(table.userId, table.createdAt)],
);

/** Crypto + fiat funding requests (deposits in, withdrawals out). */
export const transfers = pgTable(
  "transfers",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    kind: text("kind").notNull(), // deposit | withdrawal
    method: text("method").notNull().default("crypto"), // crypto | ach | wire | card
    asset: text("asset").notNull(),
    network: text("network"),
    amount: doublePrecision("amount").notNull(),
    fee: doublePrecision("fee").notNull().default(0),
    destination: text("destination"), // withdrawal address or bank ref
    txRef: text("tx_ref"), // inbound tx hash / provider payment intent
    status: text("status").notNull().default("pending"), // pending | completed | failed | canceled
    provider: text("provider"),
    note: text("note"),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("transfers_user_idx").on(table.userId, table.createdAt)],
);

/** Server-side cache of live market payloads so the app survives provider outages. */
export const marketCache = pgTable("market_cache", {
  key: text("key").primaryKey(),
  payload: jsonb("payload").notNull(),
  source: text("source"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Device/session audit trail shown in settings. */
export const loginEvents = pgTable(
  "login_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    ip: text("ip"),
    userAgent: text("user_agent"),
    success: boolean("success").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("login_events_user_idx").on(table.userId)],
);

export const rateLimits = pgTable("rate_limits", {
  key: text("key").primaryKey(),
  hits: integer("hits").notNull().default(0),
  windowStart: timestamp("window_start", { withTimezone: true }).notNull().defaultNow(),
});

export type User = typeof users.$inferSelect;
export type Balance = typeof balances.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type Trade = typeof trades.$inferSelect;
export type Transfer = typeof transfers.$inferSelect;
export type LedgerEntry = typeof ledgerEntries.$inferSelect;
