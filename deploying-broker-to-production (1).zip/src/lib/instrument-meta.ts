/** Client-safe instrument metadata (no server imports). */

export const INSTRUMENT_COLORS: Record<string, string> = {
  BTC: "#f7931a",
  ETH: "#8a92b2",
  SOL: "#14f195",
  XRP: "#23a9e0",
  DOGE: "#c3a634",
  ADA: "#3468d1",
  LINK: "#2a5ada",
  AVAX: "#e84142",
  LTC: "#a6a9aa",
  BCH: "#8dc351",
  DOT: "#e6007a",
  UNI: "#ff007a",
  ATOM: "#6f7390",
  XLM: "#7dbee9",
  SUI: "#4da2ff",
  APT: "#6fd8e5",
  ARB: "#28a0f0",
  OP: "#ff0420",
  SHIB: "#f00500",
  USDC: "#2775ca",
  USD: "#2fd6a5",
};

export const INSTRUMENT_NAMES: Record<string, string> = {
  BTC: "Bitcoin",
  ETH: "Ethereum",
  SOL: "Solana",
  XRP: "XRP",
  DOGE: "Dogecoin",
  ADA: "Cardano",
  LINK: "Chainlink",
  AVAX: "Avalanche",
  LTC: "Litecoin",
  BCH: "Bitcoin Cash",
  DOT: "Polkadot",
  UNI: "Uniswap",
  ATOM: "Cosmos",
  XLM: "Stellar",
  SUI: "Sui",
  APT: "Aptos",
  ARB: "Arbitrum",
  OP: "Optimism",
  SHIB: "Shiba Inu",
  USDC: "USD Coin",
  USD: "US Dollar",
};

export const INTERVALS = ["5m", "15m", "1h", "6h", "1d"] as const;
export type IntervalKey = (typeof INTERVALS)[number];

export function assetColor(symbol: string): string {
  return INSTRUMENT_COLORS[symbol] ?? "#6d8dff";
}

export function assetName(symbol: string): string {
  return INSTRUMENT_NAMES[symbol] ?? symbol;
}
