import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  balances,
  ledgerEntries,
  orders,
  trades,
  transfers,
  users,
  type Balance,
  type Order,
  type Transfer,
} from "@/db/schema";
import { config, FEE } from "@/lib/config";
import { getQuote, getTickers, getTicker, isTradable, instrument, SYMBOLS } from "@/lib/market";
import { round, toAsset, toUsd } from "@/lib/money";
import { HttpError } from "@/lib/auth";

type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];
type DbLike = typeof db | Tx;

/* ------------------------------- balances -------------------------------- */

async function adjustBalance(
  tx: DbLike,
  userId: string,
  asset: string,
  delta: { available?: number; locked?: number },
  entry?: { kind: string; amount: number; refType?: string; refId?: string; note?: string },
): Promise<Balance> {
  const existing = await tx
    .select()
    .from(balances)
    .where(and(eq(balances.userId, userId), eq(balances.asset, asset)))
    .limit(1)
    .for("update");

  let row = existing[0];
  if (!row) {
    const created = await tx.insert(balances).values({ userId, asset, available: 0, locked: 0 }).returning();
    row = created[0];
  }

  const nextAvailable = round(row.available + (delta.available ?? 0), 8);
  const nextLocked = round(row.locked + (delta.locked ?? 0), 8);
  if (nextAvailable < -1e-9 || nextLocked < -1e-9) {
    throw new HttpError(400, `Insufficient ${asset} balance`);
  }

  const updated = await tx
    .update(balances)
    .set({ available: Math.max(0, nextAvailable), locked: Math.max(0, nextLocked), updatedAt: new Date() })
    .where(eq(balances.id, row.id))
    .returning();

  const balanceAfter = round(updated[0].available + updated[0].locked, 8);
  if (entry && entry.amount !== 0) {
    await tx.insert(ledgerEntries).values({
      userId,
      asset,
      amount: round(entry.amount, 8),
      balanceAfter,
      kind: entry.kind,
      refType: entry.refType,
      refId: entry.refId,
      note: entry.note,
    });
  }
  return updated[0];
}

function applyCostBasis(row: Balance, assetDelta: number, price: number): { avgCost: number } {
  if (assetDelta > 0) {
    const newQty = round(row.available + row.locked, 8);
    const prevQty = round(newQty - assetDelta, 8);
    const totalCost = prevQty * row.avgCost + assetDelta * price;
    const avgCost = newQty > 0 ? totalCost / newQty : price;
    return { avgCost: round(avgCost, 6) };
  }
  return { avgCost: row.avgCost };
}

/* -------------------------------- orders --------------------------------- */

export type PlaceOrderInput = {
  userId: string;
  symbol: string;
  side: "buy" | "sell";
  type: "market" | "limit";
  amountType: "usd" | "unit";
  amount: number;
  limitPrice?: number | null;
  clientId?: string | null;
};

export type PlaceOrderResult = { order: Order; trade?: { price: number; quantity: number; notional: number; fee: number } };

export async function placeOrder(input: PlaceOrderInput): Promise<PlaceOrderResult> {
  const symbol = input.symbol.toUpperCase();
  if (!isTradable(symbol)) throw new HttpError(400, "That market is not available");
  if (!(input.amount > 0)) throw new HttpError(400, "Enter an amount greater than zero");
  if (input.type === "limit" && !(Number(input.limitPrice) > 0)) throw new HttpError(400, "Limit orders need a limit price");

  const side = input.side;
  const quote = await getQuote(symbol, side);
  const limitPrice = input.type === "limit" ? toUsd(Number(input.limitPrice)) : null;

  let notional: number;
  let quantity: number;
  if (input.amountType === "usd") {
    notional = toUsd(input.amount);
    quantity = toAsset(notional / (limitPrice ?? quote.price));
  } else {
    quantity = toAsset(input.amount);
    notional = toUsd(quantity * (limitPrice ?? quote.price));
  }

  if (notional < config.minOrderUsd) throw new HttpError(400, `Minimum order size is $${config.minOrderUsd}`);
  if (notional > config.maxOrderUsd) throw new HttpError(400, "Order exceeds the current account limit");
  if (quantity <= 0) throw new HttpError(400, "Order quantity rounds to zero");

  /* ---- immediate execution path (market orders + crossing limit orders) ---- */
  const crosses =
    input.type === "market" ||
    (side === "buy" ? quote.price <= (limitPrice as number) : quote.price >= (limitPrice as number));

  if (crosses) {
    const fillPrice = input.type === "market" ? quote.price : side === "buy" ? Math.min(quote.price, limitPrice!) : Math.max(quote.price, limitPrice!);
    const feeRate = FEE.taker;
    const fillQty = quantity;
    const fillNotional = toUsd(fillQty * fillPrice);

    if (side === "buy") {
      const spend = toUsd(fillQty * fillPrice);
      const fee = toUsd(Math.max(spend * feeRate, 0));
      const total = toUsd(spend + fee);
      if (total < config.minOrderUsd && total > 0) throw new HttpError(400, `Minimum order size is $${config.minOrderUsd}`);

      return db.transaction(async (tx) => {
        const cash = await tx
          .select()
          .from(balances)
          .where(and(eq(balances.userId, input.userId), eq(balances.asset, "USD")))
          .limit(1)
          .for("update");
        if (!cash[0] || cash[0].available < total) throw new HttpError(400, "Not enough available USD for this order");

        const cashRow = await adjustBalance(tx, input.userId, "USD", { available: -total }, {
          kind: "trade",
          amount: -spend,
          refType: "order",
          note: `Bought ${fillQty} ${symbol}`,
        });
        await adjustBalance(tx, input.userId, "USD", { available: 0 }, {
          kind: "fee",
          amount: -fee,
          refType: "order",
          note: `Taker fee ${symbol}`,
        });
        const assetRow = await adjustBalance(tx, input.userId, symbol, { available: fillQty }, {
          kind: "trade",
          amount: fillQty,
          refType: "order",
          note: `Bought ${fillQty} ${symbol} @ $${fillPrice}`,
        });
        const avg = applyCostBasis(assetRow, fillQty, fillPrice);
        await tx.update(balances).set(avg).where(eq(balances.id, assetRow.id));
        void cashRow;

        const inserted = await tx
          .insert(orders)
          .values({
            userId: input.userId,
            clientId: input.clientId ?? null,
            symbol,
            side,
            type: input.type,
            status: "filled",
            limitPrice,
            quoteAmount: input.amountType === "usd" ? notional : null,
            quantity: fillQty,
            filledQuantity: fillQty,
            avgFillPrice: fillPrice,
            feePaid: fee,
            notional: spend,
            filledAt: new Date(),
          })
          .returning();
        const order = inserted[0];
        await tx.insert(trades).values({
          orderId: order.id,
          userId: input.userId,
          symbol,
          side,
          price: fillPrice,
          quantity: fillQty,
          notional: spend,
          fee,
          liquidity: "taker",
        });
        await tx.update(orders).set({ updatedAt: new Date() }).where(eq(orders.id, order.id));
        return { order, trade: { price: fillPrice, quantity: fillQty, notional: spend, fee } } satisfies PlaceOrderResult;
      });
    }

    // sell
    const proceeds = toUsd(fillQty * fillPrice);
    const fee = toUsd(Math.max(proceeds * feeRate, 0));
    const net = toUsd(proceeds - fee);

    return db.transaction(async (tx) => {
      const assetRowBefore = await tx
        .select()
        .from(balances)
        .where(and(eq(balances.userId, input.userId), eq(balances.asset, symbol)))
        .limit(1)
        .for("update");
      const held = assetRowBefore[0];
      if (!held || held.available < fillQty) throw new HttpError(400, `Not enough available ${symbol} for this order`);
      const costBasis = held.avgCost;

      await adjustBalance(tx, input.userId, symbol, { available: -fillQty }, {
        kind: "trade",
        amount: -fillQty,
        refType: "order",
        note: `Sold ${fillQty} ${symbol} @ $${fillPrice}`,
      });
      await adjustBalance(tx, input.userId, "USD", { available: net }, {
        kind: "trade",
        amount: proceeds,
        refType: "order",
        note: `Sold ${fillQty} ${symbol}`,
      });
      await adjustBalance(tx, input.userId, "USD", { available: 0 }, {
        kind: "fee",
        amount: -fee,
        refType: "order",
        note: `Taker fee ${symbol}`,
      });

      const realised = toUsd((fillPrice - costBasis) * fillQty);
      const inserted = await tx
        .insert(orders)
        .values({
          userId: input.userId,
          clientId: input.clientId ?? null,
          symbol,
          side,
          type: input.type,
          status: "filled",
          limitPrice,
          quantity: fillQty,
          filledQuantity: fillQty,
          avgFillPrice: fillPrice,
          feePaid: fee,
          notional: proceeds,
          filledAt: new Date(),
        })
        .returning();
      const order = inserted[0];
      await tx.insert(trades).values({
        orderId: order.id,
        userId: input.userId,
        symbol,
        side,
        price: fillPrice,
        quantity: fillQty,
        notional: proceeds,
        fee,
        liquidity: "taker",
      });
      return { order, trade: { price: fillPrice, quantity: fillQty, notional: proceeds, fee } } satisfies PlaceOrderResult;
    });
  }

  /* ------------------------------- resting limit ------------------------------- */
  const feeRate = FEE.maker;
  return db.transaction(async (tx) => {
    if (side === "buy") {
      const lock = toUsd(quantity * limitPrice! * (1 + feeRate));
      const cash = await tx
        .select()
        .from(balances)
        .where(and(eq(balances.userId, input.userId), eq(balances.asset, "USD")))
        .limit(1)
        .for("update");
      if (!cash[0] || cash[0].available < lock) throw new HttpError(400, "Not enough available USD for this order");
      await adjustBalance(tx, input.userId, "USD", { available: -lock, locked: lock }, {
        kind: "trade",
        amount: 0,
        refType: "order",
        note: `Reserved for limit buy ${quantity} ${symbol}`,
      });
      const inserted = await tx
        .insert(orders)
        .values({
          userId: input.userId,
          clientId: input.clientId ?? null,
          symbol,
          side,
          type: "limit",
          status: "open",
          limitPrice,
          quoteAmount: input.amountType === "usd" ? notional : null,
          quantity,
          lockedAmount: lock,
          lockedAsset: "USD",
        })
        .returning();
      return { order: inserted[0] } satisfies PlaceOrderResult;
    }

    const assetRow = await tx
      .select()
      .from(balances)
      .where(and(eq(balances.userId, input.userId), eq(balances.asset, symbol)))
      .limit(1)
      .for("update");
    if (!assetRow[0] || assetRow[0].available < quantity) throw new HttpError(400, `Not enough available ${symbol}`);
    await adjustBalance(tx, input.userId, symbol, { available: -quantity, locked: quantity }, {
      kind: "trade",
      amount: 0,
      refType: "order",
      note: `Reserved for limit sell ${quantity} ${symbol}`,
    });
    const inserted = await tx
      .insert(orders)
      .values({
        userId: input.userId,
        clientId: input.clientId ?? null,
        symbol,
        side,
        type: "limit",
        status: "open",
        limitPrice,
        quantity,
        lockedAmount: quantity,
        lockedAsset: symbol,
      })
      .returning();
    return { order: inserted[0] } satisfies PlaceOrderResult;
  });
}

/** Fills a resting limit order at `price` and settles locked funds. */
async function fillRestingOrder(tx: Tx, order: Order, price: number, liquidity: "maker" = "maker") {
  const qty = order.quantity ?? 0;
  const fee = toUsd(qty * price * feeRateFor(order.type));
  if (order.side === "buy") {
    const spend = toUsd(qty * price);
    const locked = order.lockedAmount;
    const refund = toUsd(Math.max(0, locked - (spend + fee)));
    await tx
      .update(balances)
      .set({ locked: sql`greatest(0, ${balances.locked} - ${locked})`, available: sql`${balances.available} + ${refund}`, updatedAt: new Date() })
      .where(and(eq(balances.userId, order.userId), eq(balances.asset, "USD")));
    const assetRow = await adjustBalance(tx, order.userId, order.symbol, { available: qty }, {
      kind: "trade",
      amount: qty,
      refType: "order",
      refId: order.id,
      note: `Limit buy filled ${qty} ${order.symbol} @ $${price}`,
    });
    const avg = applyCostBasis(assetRow, qty, price);
    await tx.update(balances).set(avg).where(eq(balances.id, assetRow.id));
  } else {
    await tx
      .update(balances)
      .set({ locked: sql`greatest(0, ${balances.locked} - ${order.lockedAmount})`, updatedAt: new Date() })
      .where(and(eq(balances.userId, order.userId), eq(balances.asset, order.symbol)));
    const net = toUsd(qty * price - fee);
    await adjustBalance(tx, order.userId, "USD", { available: net }, {
      kind: "trade",
      amount: toUsd(qty * price),
      refType: "order",
      refId: order.id,
      note: `Limit sell filled ${qty} ${order.symbol} @ $${price}`,
    });
    await adjustBalance(tx, order.userId, "USD", { available: 0 }, {
      kind: "fee",
      amount: -fee,
      refType: "order",
      refId: order.id,
      note: "Maker fee",
    });
  }

  await tx.insert(trades).values({
    orderId: order.id,
    userId: order.userId,
    symbol: order.symbol,
    side: order.side,
    price,
    quantity: qty,
    notional: toUsd(qty * price),
    fee,
    liquidity,
  });

  const updated = await tx
    .update(orders)
    .set({
      status: "filled",
      filledQuantity: qty,
      avgFillPrice: price,
      feePaid: fee,
      notional: toUsd(qty * price),
      filledAt: new Date(),
      updatedAt: new Date(),
    })
    .where(eq(orders.id, order.id))
    .returning();
  return updated[0];
}

function feeRateFor(type: string): number {
  return type === "limit" ? FEE.maker : FEE.taker;
}

export async function cancelOrder(userId: string, orderId: string): Promise<Order> {
  return db.transaction(async (tx) => {
    const rows = await tx
      .select()
      .from(orders)
      .where(and(eq(orders.id, orderId), eq(orders.userId, userId)))
      .limit(1)
      .for("update");
    const order = rows[0];
    if (!order) throw new HttpError(404, "Order not found");
    if (order.status !== "open") throw new HttpError(400, "Order is no longer open");

    if (order.lockedAsset && order.lockedAmount > 0) {
      await tx
        .update(balances)
        .set({
          locked: sql`greatest(0, ${balances.locked} - ${order.lockedAmount})`,
          available: sql`${balances.available} + ${order.lockedAmount}`,
          updatedAt: new Date(),
        })
        .where(and(eq(balances.userId, userId), eq(balances.asset, order.lockedAsset)));
    }

    const updated = await tx
      .update(orders)
      .set({ status: "canceled", updatedAt: new Date() })
      .where(eq(orders.id, order.id))
      .returning();
    return updated[0];
  });
}

/* --------------------------- resting order matching --------------------------- */

let lastSettleAt = 0;

/**
 * Matches resting limit orders against the live book. Called opportunistically
 * from client polls — the same job a scheduler/cron would run in production.
 */
export async function settleOpenOrders(userId?: string): Promise<{ checked: number; filled: number }> {
  if (Date.now() - lastSettleAt < 2500) return { checked: 0, filled: 0 };
  lastSettleAt = Date.now();

  const open = await db
    .select()
    .from(orders)
    .where(userId ? and(eq(orders.status, "open"), eq(orders.userId, userId)) : eq(orders.status, "open"))
    .limit(200);
  if (!open.length) return { checked: 0, filled: 0 };

  const symbols = [...new Set(open.map((o) => o.symbol))];
  const quotes = new Map<string, { price: number; bid: number; ask: number }>();
  await Promise.all(
    symbols.map(async (s) => {
      try {
        const t = await getTicker(s);
        quotes.set(s, { price: t.price, bid: t.bid ?? t.price, ask: t.ask ?? t.price });
      } catch {
        /* provider hiccup — retry on the next poll */
      }
    }),
  );

  let filled = 0;
  for (const order of open) {
    const q = quotes.get(order.symbol);
    const limit = order.limitPrice ?? 0;
    if (!q || !limit) continue;
    if (order.side === "buy" && q.ask > limit) continue;
    if (order.side === "sell" && q.bid < limit) continue;
    const price = order.side === "buy" ? Math.min(q.ask, limit) : Math.max(q.bid, limit);
    try {
      await db.transaction(async (tx) => {
        const fresh = await tx.select().from(orders).where(eq(orders.id, order.id)).limit(1).for("update");
        if (!fresh[0] || fresh[0].status !== "open") return;
        await fillRestingOrder(tx, fresh[0], round(price, 2));
      });
      filled += 1;
    } catch {
      /* keep matching the rest */
    }
  }
  return { checked: open.length, filled };
}

/* -------------------------------- portfolio -------------------------------- */

export type Holding = {
  asset: string;
  name: string;
  quantity: number;
  available: number;
  locked: number;
  price: number;
  valueUsd: number;
  avgCost: number;
  costBasisUsd: number;
  unrealizedPnlUsd: number;
  unrealizedPnlPct: number;
  change24h: number | null;
};

export type Portfolio = {
  cashUsd: number;
  cashAvailable: number;
  cashLocked: number;
  holdingsValueUsd: number;
  equityUsd: number;
  unrealizedPnlUsd: number;
  holdings: Holding[];
  updatedAt: string;
};

export async function getPortfolio(userId: string): Promise<Portfolio> {
  const rows = await db.select().from(balances).where(eq(balances.userId, userId));
  const board = await getTickers();
  const priceBySymbol = new Map(board.tickers.map((t) => [t.symbol, t]));

  const cashRow = rows.find((r) => r.asset === "USD");
  const cashAvailable = toUsd(cashRow?.available ?? 0);
  const cashLocked = toUsd(cashRow?.locked ?? 0);

  const holdings: Holding[] = [];
  for (const row of rows) {
    if (row.asset === "USD") continue;
    const qty = round(row.available + row.locked, 8);
    if (qty <= 0) continue;
    const inst = instrument(row.asset);
    const ticker = priceBySymbol.get(row.asset);
    const isStable = row.asset === "USDC";
    const price = isStable ? 1 : ticker?.price ?? row.avgCost;
    const valueUsd = toUsd(qty * price);
    const costBasisUsd = toUsd(qty * row.avgCost);
    holdings.push({
      asset: row.asset,
      name: inst?.name ?? row.asset,
      quantity: qty,
      available: round(row.available, 8),
      locked: round(row.locked, 8),
      price,
      valueUsd,
      avgCost: row.avgCost,
      costBasisUsd,
      unrealizedPnlUsd: toUsd(valueUsd - costBasisUsd),
      unrealizedPnlPct: costBasisUsd > 0 ? ((valueUsd - costBasisUsd) / costBasisUsd) * 100 : 0,
      change24h: isStable ? 0 : ticker?.change24h ?? null,
    });
  }
  holdings.sort((a, b) => b.valueUsd - a.valueUsd);

  const holdingsValueUsd = toUsd(holdings.reduce((sum, h) => sum + h.valueUsd, 0));
  const unrealizedPnlUsd = toUsd(holdings.reduce((sum, h) => sum + h.unrealizedPnlUsd, 0));

  return {
    cashUsd: toUsd(cashAvailable + cashLocked),
    cashAvailable,
    cashLocked,
    holdingsValueUsd,
    equityUsd: toUsd(cashAvailable + cashLocked + holdingsValueUsd),
    unrealizedPnlUsd,
    holdings,
    updatedAt: new Date().toISOString(),
  };
}

export async function getOrders(userId: string, opts?: { status?: string; limit?: number }) {
  const limit = Math.min(opts?.limit ?? 50, 200);
  const where =
    opts?.status && opts.status !== "all"
      ? and(eq(orders.userId, userId), eq(orders.status, opts.status))
      : eq(orders.userId, userId);
  return db.select().from(orders).where(where).orderBy(desc(orders.createdAt)).limit(limit);
}

export async function getTrades(userId: string, limit = 50) {
  return db.select().from(trades).where(eq(trades.userId, userId)).orderBy(desc(trades.createdAt)).limit(limit);
}

export async function getLedger(userId: string, limit = 50) {
  return db.select().from(ledgerEntries).where(eq(ledgerEntries.userId, userId)).orderBy(desc(ledgerEntries.createdAt)).limit(limit);
}

export async function getTransfers(userId: string, limit = 50) {
  return db.select().from(transfers).where(eq(transfers.userId, userId)).orderBy(desc(transfers.createdAt)).limit(limit);
}

/* -------------------------------- funding -------------------------------- */

export function fundingAddresses() {
  return config.deposits;
}

export async function createDeposit(input: {
  userId: string;
  asset: string;
  amount: number;
  method?: string;
  network?: string | null;
  txRef?: string | null;
}): Promise<Transfer> {
  const asset = input.asset.toUpperCase();
  const amount = toUsd(input.amount);
  if (!(amount > 0)) throw new HttpError(400, "Enter a deposit amount");
  const method = input.method ?? "crypto";

  const inserted = await db
    .insert(transfers)
    .values({
      userId: input.userId,
      kind: "deposit",
      method,
      asset,
      network: input.network ?? null,
      amount,
      txRef: input.txRef ?? null,
      status: "pending",
      provider: method === "card" || method === "ach" ? (config.stripeSecretKey ? "stripe" : "manual") : "onchain",
    })
    .returning();

  // Card/ACH rails confirm synchronously when a processor key is configured.
  if ((method === "card" || method === "ach") && config.stripeSecretKey) {
    return completeTransfer(inserted[0].id, { note: "Auto-confirmed by funding provider" });
  }
  if (config.autoApproveDeposits) {
    return completeTransfer(inserted[0].id, { note: "Auto-confirmed deposit" });
  }
  return inserted[0];
}

export async function createWithdrawal(input: {
  userId: string;
  asset: string;
  amount: number;
  destination: string;
  network?: string | null;
}): Promise<Transfer> {
  const asset = input.asset.toUpperCase();
  const amount = toAsset(input.amount);
  if (!(amount > 0)) throw new HttpError(400, "Enter a withdrawal amount");
  if (!input.destination || input.destination.trim().length < 8) throw new HttpError(400, "Enter a valid destination address");

  const fee = asset === "USD" ? config.withdrawalFeeUsd : toUsd(config.withdrawalFeeUsd);
  const total = round(amount + fee, 8);

  return db.transaction(async (tx) => {
    const row = await tx
      .select()
      .from(balances)
      .where(and(eq(balances.userId, input.userId), eq(balances.asset, asset)))
      .limit(1)
      .for("update");
    if (!row[0] || row[0].available < total) throw new HttpError(400, `Insufficient ${asset} available (includes network fee)`);

    await tx
      .update(balances)
      .set({ available: round(row[0].available - total, 8), locked: round(row[0].locked + total, 8), updatedAt: new Date() })
      .where(eq(balances.id, row[0].id));

    const inserted = await tx
      .insert(transfers)
      .values({
        userId: input.userId,
        kind: "withdrawal",
        method: asset === "USD" ? "ach" : "crypto",
        asset,
        network: input.network ?? null,
        amount,
        fee,
        destination: input.destination.trim(),
        status: "pending",
      })
      .returning();

    if (config.autoApproveWithdrawals) {
      return settleTransferInTx(tx, inserted[0], "completed", "Auto-approved withdrawal");
    }
    return inserted[0];
  });
}

async function settleTransferInTx(tx: Tx, transfer: Transfer, status: "completed" | "failed", note: string): Promise<Transfer> {
  if (transfer.kind === "deposit" && status === "completed") {
    await adjustBalance(tx, transfer.userId, transfer.asset, { available: transfer.amount }, {
      kind: "deposit",
      amount: transfer.amount,
      refType: "transfer",
      refId: transfer.id,
      note: `Deposit ${transfer.asset} via ${transfer.method}`,
    });
  }
  if (transfer.kind === "withdrawal") {
    const total = round(transfer.amount + transfer.fee, 8);
    if (status === "completed") {
      await tx
        .update(balances)
        .set({ locked: sql`greatest(0, ${balances.locked} - ${total})`, updatedAt: new Date() })
        .where(and(eq(balances.userId, transfer.userId), eq(balances.asset, transfer.asset)));
      await adjustBalance(tx, transfer.userId, transfer.asset, { available: 0 }, {
        kind: "withdrawal",
        amount: -transfer.amount,
        refType: "transfer",
        refId: transfer.id,
        note: `Withdrawal ${transfer.asset} to ${transfer.destination?.slice(0, 10)}…`,
      });
      if (transfer.fee > 0) {
        await adjustBalance(tx, transfer.userId, transfer.asset, { available: 0 }, {
          kind: "fee",
          amount: -transfer.fee,
          refType: "transfer",
          refId: transfer.id,
          note: "Withdrawal network fee",
        });
      }
    } else {
      await tx
        .update(balances)
        .set({
          locked: sql`greatest(0, ${balances.locked} - ${total})`,
          available: sql`${balances.available} + ${total}`,
          updatedAt: new Date(),
        })
        .where(and(eq(balances.userId, transfer.userId), eq(balances.asset, transfer.asset)));
    }
  }

  const updated = await tx
    .update(transfers)
    .set({ status, note, completedAt: status === "completed" ? new Date() : null })
    .where(eq(transfers.id, transfer.id))
    .returning();
  return updated[0];
}

export async function completeTransfer(transferId: string, opts?: { note?: string }) {
  return db.transaction(async (tx) => {
    const rows = await tx.select().from(transfers).where(eq(transfers.id, transferId)).limit(1).for("update");
    const transfer = rows[0];
    if (!transfer) throw new HttpError(404, "Transfer not found");
    if (transfer.status === "completed") return transfer;
    return settleTransferInTx(tx, transfer, "completed", opts?.note ?? "Confirmed");
  });
}

export async function rejectTransfer(transferId: string) {
  return db.transaction(async (tx) => {
    const rows = await tx.select().from(transfers).where(eq(transfers.id, transferId)).limit(1).for("update");
    const transfer = rows[0];
    if (!transfer) throw new HttpError(404, "Transfer not found");
    if (transfer.status === "completed") throw new HttpError(400, "Transfer already settled");
    return settleTransferInTx(tx, transfer, "failed", "Rejected by operations");
  });
}

export async function getPendingTransfers() {
  return db.select().from(transfers).where(eq(transfers.status, "pending")).orderBy(desc(transfers.createdAt)).limit(100);
}

/* ------------------------------ account tools ------------------------------ */

export async function getAccountOverview(userId: string) {
  const [portfolio, openOrders, recentTrades, recentTransfers] = await Promise.all([
    getPortfolio(userId),
    getOrders(userId, { status: "open", limit: 20 }),
    getTrades(userId, 10),
    getTransfers(userId, 5),
  ]);
  return { portfolio, openOrders, recentTrades, recentTransfers };
}

export async function getMarketsForSymbols(symbols: string[]) {
  const list = symbols.length ? symbols : SYMBOLS;
  const board = await getTickers();
  const wanted = new Set(list.map((s) => s.toUpperCase()));
  return board.tickers.filter((t) => wanted.has(t.symbol));
}

export async function getQuoteForOrder(symbol: string, side: "buy" | "sell") {
  return getQuote(symbol, side);
}

export async function userByTransfer(userId: string) {
  const rows = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return rows[0] ?? null;
}

export async function countOpenOrders(userId: string) {
  const rows = await db
    .select({ id: orders.id })
    .from(orders)
    .where(and(eq(orders.userId, userId), inArray(orders.status, ["open"])));
  return rows.length;
}

export { toUsd, toAsset, round };
