/** Shared, serialisable types for client components. */

export type Ticker = {
  symbol: string;
  name: string;
  price: number;
  bid: number | null;
  ask: number | null;
  change24h: number | null;
  high24h: number | null;
  low24h: number | null;
  volume24hUsd: number | null;
  updatedAt: string;
  source: string;
};

export type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };

export type Holding = {
  asset: string;
  name: string;
  quantity: number;
  available: number;
  locked: number;
  price: number;
  valueUsd: number;
  avgCost: number;
  costBasisUsd: number;
  unrealizedPnlUsd: number;
  unrealizedPnlPct: number;
  change24h: number | null;
};

export type Portfolio = {
  cashUsd: number;
  cashAvailable: number;
  cashLocked: number;
  holdingsValueUsd: number;
  equityUsd: number;
  unrealizedPnlUsd: number;
  holdings: Holding[];
  updatedAt: string;
};

export type OrderRow = {
  id: string;
  symbol: string;
  side: "buy" | "sell";
  type: "market" | "limit";
  status: "open" | "filled" | "canceled" | "rejected";
  limitPrice: number | null;
  quantity: number | null;
  quoteAmount: number | null;
  filledQuantity: number;
  avgFillPrice: number | null;
  feePaid: number;
  notional: number;
  rejectReason: string | null;
  createdAt: string;
  filledAt: string | null;
};

export type TradeRow = {
  id: string;
  symbol: string;
  side: "buy" | "sell";
  price: number;
  quantity: number;
  notional: number;
  fee: number;
  liquidity: string;
  createdAt: string;
};

export type TransferRow = {
  id: string;
  kind: "deposit" | "withdrawal";
  method: string;
  asset: string;
  network: string | null;
  amount: number;
  fee: number;
  destination: string | null;
  txRef: string | null;
  status: string;
  note: string | null;
  createdAt: string;
  completedAt: string | null;
  userEmail?: string;
  userName?: string;
};

export type LedgerRow = {
  id: string;
  asset: string;
  amount: number;
  balanceAfter: number;
  kind: string;
  note: string | null;
  createdAt: string;
};

export type AccountSnapshot = {
  user: { id: string; email: string; fullName: string; role: string; tier: string };
  portfolio: Portfolio;
  openOrders: OrderRow[];
  recentTrades: TradeRow[];
  recentTransfers: TransferRow[];
  ledger: LedgerRow[];
  fees: { takerBps: number; makerBps: number; takerPct: number; makerPct: number };
  mode: string;
  serverTime: string;
};

export type Notice = { tone: "ok" | "error" | "info"; message: string } | null;
