import { db } from "@/db";
import { marketCache } from "@/db/schema";
import { sql } from "drizzle-orm";

/**
 * LIVE MARKET DATA
 *
 * Providers are tried in order until one answers:
 *   1. Coinbase Exchange (public REST, no key) — best bid/ask, our execution venue
 *   2. Kraken public REST
 *   3. CoinGecko (aggregate, also supplies 24h stats in one call)
 *
 * Results are cached in memory for a few seconds and mirrored into Postgres so
 * the app keeps showing the last known good price if every provider is down.
 */

export type Ticker = {
  symbol: string;
  name: string;
  price: number;
  bid: number | null;
  ask: number | null;
  change24h: number | null;
  high24h: number | null;
  low24h: number | null;
  volume24hUsd: number | null;
  updatedAt: string;
  source: string;
};

export type Candle = {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
};

export type MarketInstrument = {
  symbol: string;
  name: string;
  coingeckoId: string;
  coinbaseId: string;
  krakenId?: string;
  color: string;
};

export const INSTRUMENTS: MarketInstrument[] = [
  { symbol: "BTC", name: "Bitcoin", coingeckoId: "bitcoin", coinbaseId: "BTC-USD", krakenId: "XBTUSD", color: "#f7931a" },
  { symbol: "ETH", name: "Ethereum", coingeckoId: "ethereum", coinbaseId: "ETH-USD", krakenId: "XETHZUSD", color: "#8a92b2" },
  { symbol: "SOL", name: "Solana", coingeckoId: "solana", coinbaseId: "SOL-USD", krakenId: "SOLUSD", color: "#14f195" },
  { symbol: "XRP", name: "XRP", coingeckoId: "ripple", coinbaseId: "XRP-USD", krakenId: "XXRPZUSD", color: "#23a9e0" },
  { symbol: "DOGE", name: "Dogecoin", coingeckoId: "dogecoin", coinbaseId: "DOGE-USD", krakenId: "XDGUSD", color: "#c3a634" },
  { symbol: "ADA", name: "Cardano", coingeckoId: "cardano", coinbaseId: "ADA-USD", krakenId: "ADAUSD", color: "#3468d1" },
  { symbol: "LINK", name: "Chainlink", coingeckoId: "chainlink", coinbaseId: "LINK-USD", krakenId: "LINKUSD", color: "#2a5ada" },
  { symbol: "AVAX", name: "Avalanche", coingeckoId: "avalanche-2", coinbaseId: "AVAX-USD", color: "#e84142" },
  { symbol: "LTC", name: "Litecoin", coingeckoId: "litecoin", coinbaseId: "LTC-USD", krakenId: "XLTCZUSD", color: "#a6a9aa" },
  { symbol: "BCH", name: "Bitcoin Cash", coingeckoId: "bitcoin-cash", coinbaseId: "BCH-USD", krakenId: "BCHUSD", color: "#8dc351" },
  { symbol: "DOT", name: "Polkadot", coingeckoId: "polkadot", coinbaseId: "DOT-USD", krakenId: "DOTUSD", color: "#e6007a" },
  { symbol: "UNI", name: "Uniswap", coingeckoId: "uniswap", coinbaseId: "UNI-USD", krakenId: "UNIUSD", color: "#ff007a" },
  { symbol: "ATOM", name: "Cosmos", coingeckoId: "cosmos", coinbaseId: "ATOM-USD", krakenId: "ATOMUSD", color: "#6f7390" },
  { symbol: "XLM", name: "Stellar", coingeckoId: "stellar", coinbaseId: "XLM-USD", krakenId: "XXLMZUSD", color: "#7dbee9" },
  { symbol: "SUI", name: "Sui", coingeckoId: "sui", coinbaseId: "SUI-USD", color: "#4da2ff" },
  { symbol: "APT", name: "Aptos", coingeckoId: "aptos", coinbaseId: "APT-USD", color: "#6fd8e5" },
  { symbol: "ARB", name: "Arbitrum", coingeckoId: "arbitrum", coinbaseId: "ARB-USD", color: "#28a0f0" },
  { symbol: "OP", name: "Optimism", coingeckoId: "optimism", coinbaseId: "OP-USD", color: "#ff0420" },
  { symbol: "SHIB", name: "Shiba Inu", coingeckoId: "shiba-inu", coinbaseId: "SHIB-USD", color: "#f00500" },
  { symbol: "USDC", name: "USD Coin", coingeckoId: "usd-coin", coinbaseId: "USDC-USD", color: "#2775ca" },
];

export const SYMBOLS = INSTRUMENTS.map((i) => i.symbol);
const BY_SYMBOL = new Map(INSTRUMENTS.map((i) => [i.symbol, i]));
export const STABLE_ASSETS = new Set(["USD", "USDC"]);

export function instrument(symbol: string): MarketInstrument | undefined {
  return BY_SYMBOL.get(symbol.toUpperCase());
}

export function isTradable(symbol: string): boolean {
  const inst = instrument(symbol);
  return Boolean(inst && inst.symbol !== "USDC");
}

const TICKER_TTL_MS = Number(process.env.MARKET_CACHE_MS ?? 8000);
const CANDLE_TTL_MS = 45_000;
const FETCH_TIMEOUT_MS = 7000;

type CacheEntry = { data: unknown; expires: number };
const memory = new Map<string, CacheEntry>();

function memGet<T>(key: string): T | null {
  const hit = memory.get(key);
  if (hit && hit.expires > Date.now()) return hit.data as T;
  if (hit) memory.delete(key);
  return null;
}

function memSet(key: string, data: unknown, ttlMs: number) {
  memory.set(key, { data, expires: Date.now() + ttlMs });
}

async function fetchJson<T>(url: string): Promise<T | null> {
  try {
    const res = await fetch(url, {
      cache: "no-store",
      signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
      headers: { accept: "application/json", "user-agent": "tidemark/1.0" },
    });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

async function readDbCache<T>(key: string, maxAgeMs: number): Promise<T | null> {
  try {
    const rows = await db.execute<{ payload: T; updated_at: Date }>(
      sql`select payload, updated_at from market_cache where key = ${key} and updated_at > now() - ${`${Math.round(maxAgeMs / 1000)} seconds`}::interval limit 1`,
    );
    const row = rows.rows[0];
    return row ? (row.payload as T) : null;
  } catch {
    return null;
  }
}

async function writeDbCache(key: string, payload: unknown, source: string) {
  try {
    await db
      .insert(marketCache)
      .values({ key, payload: payload as never, source })
      .onConflictDoUpdate({
        target: marketCache.key,
        set: { payload: payload as never, source, updatedAt: new Date() },
      });
  } catch {
    /* cache write failures must never break a request */
  }
}

/* ------------------------------- providers ------------------------------- */

type CbTicker = { trade_id: number; price: string; size: string; bid: string; ask: string; time: string; volume: string };
type CbStats = { open: string; high: string; low: string; volume: string; last: string; volume_30day: string };

async function coinbaseTicker(symbol: string): Promise<Ticker | null> {
  const inst = instrument(symbol);
  if (!inst) return null;
  const [tick, stats] = await Promise.all([
    fetchJson<CbTicker>(`https://api.exchange.coinbase.com/products/${inst.coinbaseId}/ticker`),
    fetchJson<CbStats>(`https://api.exchange.coinbase.com/products/${inst.coinbaseId}/stats`),
  ]);
  if (!tick) return null;
  const price = Number(tick.price);
  if (!Number.isFinite(price) || price <= 0) return null;
  const open = stats ? Number(stats.open) : NaN;
  return {
    symbol: inst.symbol,
    name: inst.name,
    price,
    bid: Number(tick.bid) || null,
    ask: Number(tick.ask) || null,
    change24h: Number.isFinite(open) && open > 0 ? ((price - open) / open) * 100 : null,
    high24h: stats && Number(stats.high) ? Number(stats.high) : null,
    low24h: stats && Number(stats.low) ? Number(stats.low) : null,
    volume24hUsd: stats && Number(stats.volume) ? Number(stats.volume) * price : null,
    updatedAt: new Date().toISOString(),
    source: "coinbase",
  };
}

type KrakenResponse = { error: string[]; result: Record<string, { a: string[]; b: string[]; c: string[]; v: string[]; p: string[]; h: string[]; l: string[]; o: string }> };

async function krakenTicker(symbol: string): Promise<Ticker | null> {
  const inst = instrument(symbol);
  if (!inst?.krakenId) return null;
  const data = await fetchJson<KrakenResponse>(`https://api.kraken.com/0/public/Ticker?pair=${inst.krakenId}`);
  if (!data || data.error?.length) return null;
  const entry = Object.values(data.result)[0];
  if (!entry) return null;
  const price = Number(entry.c[0]);
  const open = Number(entry.o);
  if (!Number.isFinite(price) || price <= 0) return null;
  return {
    symbol: inst.symbol,
    name: inst.name,
    price,
    bid: Number(entry.b[0]) || null,
    ask: Number(entry.a[0]) || null,
    change24h: Number.isFinite(open) && open > 0 ? ((price - open) / open) * 100 : null,
    high24h: Number(entry.h[1]) || null,
    low24h: Number(entry.l[1]) || null,
    volume24hUsd: (Number(entry.v[1]) || 0) * price,
    updatedAt: new Date().toISOString(),
    source: "kraken",
  };
}

type CgMarket = {
  id: string;
  current_price: number;
  price_change_percentage_24h: number | null;
  high_24h: number | null;
  low_24h: number | null;
  total_volume: number | null;
};

async function coingeckoTickers(): Promise<Ticker[] | null> {
  const ids = INSTRUMENTS.map((i) => i.coingeckoId).join(",");
  const data = await fetchJson<CgMarket[]>(
    `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${ids}&per_page=250&sparkline=false&price_change_percentage=24h`,
  );
  if (!Array.isArray(data) || data.length === 0) return null;
  const byId = new Map(data.map((row) => [row.id, row]));
  const now = new Date().toISOString();
  const out: Ticker[] = [];
  for (const inst of INSTRUMENTS) {
    const row = byId.get(inst.coingeckoId);
    if (!row || !Number.isFinite(Number(row.current_price))) continue;
    out.push({
      symbol: inst.symbol,
      name: inst.name,
      price: Number(row.current_price),
      bid: null,
      ask: null,
      change24h: row.price_change_percentage_24h ?? null,
      high24h: row.high_24h ?? null,
      low24h: row.low_24h ?? null,
      volume24hUsd: row.total_volume ?? null,
      updatedAt: now,
      source: "coingecko",
    });
  }
  return out.length ? out : null;
}

/* --------------------------------- public -------------------------------- */

/** Live board for the market watch list. */
export async function getTickers(): Promise<{ tickers: Ticker[]; source: string; stale: boolean }> {
  const cached = memGet<{ tickers: Ticker[]; source: string; stale: boolean }>("tickers");
  if (cached) return cached;

  const coingecko = await coingeckoTickers();
  if (coingecko) {
    const payload = { tickers: coingecko, source: "coingecko", stale: false };
    memSet("tickers", payload, TICKER_TTL_MS);
    void writeDbCache("tickers", payload, "coingecko");
    return payload;
  }

  // Fallback: per-venue fan-out (only for the most liquid symbols to stay fast).
  const subset = ["BTC", "ETH", "SOL", "XRP", "DOGE", "ADA", "LINK", "AVAX", "LTC", "BCH"];
  const results = await Promise.all(subset.map((s) => coinbaseTicker(s).then((t) => t ?? krakenTicker(s))));
  const tickers = results.filter((t): t is Ticker => Boolean(t));
  if (tickers.length) {
    const payload = { tickers, source: "coinbase/kraken", stale: false };
    memSet("tickers", payload, TICKER_TTL_MS);
    void writeDbCache("tickers", payload, "coinbase/kraken");
    return payload;
  }

  const dbCached = await readDbCache<{ tickers: Ticker[]; source: string; stale: boolean }>("tickers", 6 * 60 * 60 * 1000);
  if (dbCached) {
    const payload = { ...dbCached, stale: true };
    memSet("tickers", payload, 5000);
    return payload;
  }
  return { tickers: [], source: "none", stale: true };
}

/** Best available quote for a single symbol, preferring the execution venue. */
export async function getTicker(symbol: string): Promise<Ticker> {
  const sym = symbol.toUpperCase();
  const board = await getTickers();
  const fromBoard = board.tickers.find((t) => t.symbol === sym);
  if (fromBoard && fromBoard.bid && fromBoard.ask) return fromBoard;

  const venue = await coinbaseTicker(sym);
  if (venue) return venue;
  if (fromBoard) return fromBoard;
  const kraken = await krakenTicker(sym);
  if (kraken) return kraken;

  if (fromBoard) return fromBoard;
  throw new Error(`NO_MARKET_DATA:${sym}`);
}

export type Quote = { price: number; bid: number; ask: number; source: string };

/** The price we actually transact at: ask for buys, bid for sells. */
export async function getQuote(symbol: string, side: "buy" | "sell"): Promise<Quote> {
  const ticker = await getTicker(symbol);
  const bid = ticker.bid ?? ticker.price;
  const ask = ticker.ask ?? ticker.price;
  const price = side === "buy" ? Math.max(ask, ticker.price) : Math.min(bid, ticker.price);
  return { price, bid, ask, source: ticker.source };
}

const GRANULARITY: Record<string, number> = { "5m": 300, "15m": 900, "1h": 3600, "6h": 21600, "1d": 86400 };

export async function getCandles(symbol: string, interval = "1h", limit = 120): Promise<{ candles: Candle[]; source: string }> {
  const sym = symbol.toUpperCase();
  const key = `candles:${sym}:${interval}:${limit}`;
  const cached = memGet<{ candles: Candle[]; source: string }>(key);
  if (cached) return cached;

  const inst = instrument(sym);
  const granularity = GRANULARITY[interval] ?? 3600;

  if (inst) {
    const rows = await fetchJson<number[][]>(
      `https://api.exchange.coinbase.com/products/${inst.coinbaseId}/candles?granularity=${granularity}`,
    );
    if (Array.isArray(rows) && rows.length) {
      const candles: Candle[] = rows
        .slice(0, limit)
        .map((r) => ({ time: r[0], low: r[1], high: r[2], open: r[3], close: r[4], volume: r[5] }))
        .sort((a, b) => a.time - b.time);
      const payload = { candles, source: "coinbase" };
      memSet(key, payload, CANDLE_TTL_MS);
      return payload;
    }
  }

  if (inst?.krakenId) {
    const data = await fetchJson<{ result: Record<string, unknown> }>(
      `https://api.kraken.com/0/public/OHLC?pair=${inst.krakenId}&interval=${Math.round(granularity / 60)}`,
    );
    const pair = data?.result ? Object.keys(data.result).find((k) => k !== "last") : undefined;
    const rows = pair ? (data!.result[pair] as number[][]) : undefined;
    if (Array.isArray(rows) && rows.length) {
      const candles: Candle[] = rows
        .slice(-limit)
        .map((r) => ({ time: r[0], open: Number(r[1]), high: Number(r[2]), low: Number(r[3]), close: Number(r[4]), volume: Number(r[6]) }));
      const payload = { candles, source: "kraken" };
      memSet(key, payload, CANDLE_TTL_MS);
      return payload;
    }
  }

  const dbCached = await readDbCache<{ candles: Candle[]; source: string }>(key, 6 * 60 * 60 * 1000);
  if (dbCached) return dbCached;
  return { candles: [], source: "none" };
}

export async function persistCandles(symbol: string, interval: string, candles: Candle[]) {
  if (!candles.length) return;
  await writeDbCache(`candles:${symbol.toUpperCase()}:${interval}:120`, { candles, source: "coinbase" }, "cache");
}
