import { randomBytes, randomUUID, scrypt as scryptCb, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { cookies } from "next/headers";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { balances, ledgerEntries, loginEvents, sessions, users, type User } from "@/db/schema";
import { config, isAdminEmail } from "@/lib/config";
import { toAsset, toUsd } from "@/lib/money";

const scrypt = promisify(scryptCb) as (password: string, salt: string, keylen: number) => Promise<Buffer>;

export const SESSION_COOKIE = "tm_session";

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const derived = await scrypt(password, salt, 64);
  return `scrypt:${salt}:${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [scheme, salt, digest] = stored.split(":");
  if (scheme !== "scrypt" || !salt || !digest) return false;
  const derived = await scrypt(password, salt, 64);
  const expected = Buffer.from(digest, "hex");
  if (expected.length !== derived.length) return false;
  return timingSafeEqual(derived, expected);
}

export async function createSession(userId: string, userAgent?: string | null) {
  const token = `${randomUUID()}.${randomBytes(32).toString("hex")}`;
  const expiresAt = new Date(Date.now() + config.sessionDays * 24 * 60 * 60 * 1000);
  await db.insert(sessions).values({ token, userId, expiresAt, userAgent: userAgent ?? null });
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  });
  await db.insert(loginEvents).values({ userId, userAgent: userAgent ?? null, success: true });
  return token;
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.token, token));
    jar.delete(SESSION_COOKIE);
  }
}

export async function getCurrentUser(): Promise<User | null> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const rows = await db
    .select({ user: users })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())))
    .limit(1);
  const user = rows[0]?.user ?? null;
  if (!user || user.status !== "active") return null;
  return user;
}

export class HttpError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export async function requireUser(): Promise<User> {
  const user = await getCurrentUser();
  if (!user) throw new HttpError(401, "Sign in required");
  return user;
}

export function errorResponse(error: unknown) {
  if (error instanceof HttpError) {
    return Response.json({ error: error.message }, { status: error.status });
  }
  const message = error instanceof Error ? error.message : "Unexpected error";
  return Response.json({ error: message }, { status: 400 });
}

/** Creates the USD cash account (plus any promo credit) for a brand new account. */
export async function openAccount(userId: string) {
  const credit = Math.max(0, toUsd(config.welcomeCreditUsd));
  await db.insert(balances).values({ userId, asset: "USD", available: 0, locked: 0 });
  if (credit > 0) {
    await db
      .update(balances)
      .set({ available: credit, updatedAt: new Date() })
      .where(and(eq(balances.userId, userId), eq(balances.asset, "USD")));
    await db.insert(ledgerEntries).values({
      userId,
      asset: "USD",
      amount: credit,
      balanceAfter: credit,
      kind: "promo",
      note: "Account opening credit",
    });
  }
}

export async function signup(input: { email: string; password: string; fullName: string; country?: string }) {
  const email = input.email.trim().toLowerCase();
  const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing.length) throw new HttpError(409, "An account already exists for that email");
  const passwordHash = await hashPassword(input.password);
  const role = isAdminEmail(email) ? "admin" : "user";
  const inserted = await db
    .insert(users)
    .values({
      email,
      passwordHash,
      fullName: input.fullName.trim(),
      country: (input.country ?? "US").toUpperCase(),
      role,
      onboardedAt: new Date(),
    })
    .returning();
  const user = inserted[0];
  await openAccount(user.id);
  return user;
}

export async function login(input: { email: string; password: string; userAgent?: string | null }) {
  const email = input.email.trim().toLowerCase();
  const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
  const user = rows[0];
  if (!user) throw new HttpError(401, "Email or password is incorrect");
  const ok = await verifyPassword(input.password, user.passwordHash);
  if (!ok) throw new HttpError(401, "Email or password is incorrect");
  if (user.status !== "active") throw new HttpError(403, "This account is suspended");
  await createSession(user.id, input.userAgent);
  return user;
}

/** Rounds helpers re-exported for convenience in routes. */
export const r2 = toUsd;
export const r8 = toAsset;
