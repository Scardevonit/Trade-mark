/** Platform configuration — every knob is environment driven so this can go live. */

function num(value: string | undefined, fallback: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function bool(value: string | undefined, fallback = false): boolean {
  if (value === undefined) return fallback;
  return ["1", "true", "yes", "on"].includes(value.toLowerCase());
}

export const config = {
  /** "live" = real market prices + real ledger execution. */
  mode: (process.env.TRADING_MODE ?? "live").toLowerCase(),
  takerFeeBps: num(process.env.TAKER_FEE_BPS, 45), // 0.45%
  makerFeeBps: num(process.env.MAKER_FEE_BPS, 15), // 0.15%
  minOrderUsd: num(process.env.MIN_ORDER_USD, 10),
  maxOrderUsd: num(process.env.MAX_ORDER_USD, 250_000),
  withdrawalFeeUsd: num(process.env.WITHDRAWAL_FEE_USD, 1.5),
  /** Automatically settle crypto deposits marked as confirmed by the rail webhook. */
  autoApproveDeposits: bool(process.env.AUTO_APPROVE_DEPOSITS, false),
  autoApproveWithdrawals: bool(process.env.AUTO_APPROVE_WITHDRAWALS, false),
  welcomeCreditUsd: num(process.env.WELCOME_CREDIT_USD, 250),
  adminEmails: (process.env.ADMIN_EMAILS ?? "")
    .split(",")
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean),
  sessionDays: num(process.env.SESSION_DAYS, 30),
  /** Funding rails: card/bank via Stripe, crypto via on-chain addresses. */
  stripeSecretKey: process.env.STRIPE_SECRET_KEY ?? "",
  deposits: {
    BTC: process.env.DEPOSIT_ADDRESS_BTC ?? "",
    ETH: process.env.DEPOSIT_ADDRESS_ETH ?? "",
    USDC: process.env.DEPOSIT_ADDRESS_USDC ?? "",
    SOL: process.env.DEPOSIT_ADDRESS_SOL ?? "",
  },
} as const;

export const FEE = {
  taker: config.takerFeeBps / 10_000,
  maker: config.makerFeeBps / 10_000,
};

export function isAdminEmail(email: string): boolean {
  return config.adminEmails.includes(email.toLowerCase());
}
