# tidemark. — live crypto brokerage

A complete, production-shaped crypto trading platform: **real market prices**, **real order execution**,
**locked balances**, an **append-only cash/coin ledger**, funding rails and an operations queue.
No simulation mode, no fake prices.

---

## 1. What is actually live

| Subsystem | Status | Detail |
|---|---|---|
| Market data | ✅ live | Coinbase Exchange (primary) → Kraken → CoinGecko failover, cached in memory + Postgres |
| Order execution | ✅ live | Market orders fill at the live bid/ask; limit orders rest and fill when the book crosses |
| Accounting | ✅ live | `balances` (available/locked/avgCost) + append-only `ledger_entries` for every mutation |
| Auth | ✅ live | scrypt password hashing, httpOnly session cookies, DB-backed sessions |
| Funding | ⚙️ wire-up | Crypto deposit addresses + card/ACH rail are env-driven (see step 3) |

Prices are never fabricated. If every provider is unreachable the app serves the last known-good
price from the `market_cache` table and flags the board as stale.

---

## 2. Run it

```bash
npm install
cp .env.example .env          # then edit values
npx drizzle-kit push          # create the schema
npm run build && npm start    # http://localhost:3000
```

Health probe: `GET /api/health`.

➡️ **Pushing to GitHub and deploying:** see [`DEPLOY.md`](./DEPLOY.md) — it covers `git init` /
push, the CI workflow, Vercel / Railway / Render / Fly / Docker, and why GitHub **Pages** cannot
host this app.

---

## 3. Environment variables

```ini
DATABASE_URL=postgresql://user:pass@host:5432/db

# --- trading controls ---
TRADING_MODE=live
TAKER_FEE_BPS=45          # 0.45 %
MAKER_FEE_BPS=15          # 0.15 %
MIN_ORDER_USD=10
MAX_ORDER_USD=250000
WITHDRAWAL_FEE_USD=1.5
SESSION_DAYS=30

# --- onboarding ---
ADMIN_EMAILS=you@yourdomain.com     # these accounts get /app/admin operations access
WELCOME_CREDIT_USD=0                # set 0 for real money. >0 is a promo credit entry.
AUTO_APPROVE_DEPOSITS=false
AUTO_APPROVE_WITHDRAWALS=false

# --- funding rails (custody / payments) ---
DEPOSIT_ADDRESS_BTC=
DEPOSIT_ADDRESS_ETH=
DEPOSIT_ADDRESS_USDC=
DEPOSIT_ADDRESS_SOL=
STRIPE_SECRET_KEY=            # enables instant card/ACH deposits
```

> **Set `WELCOME_CREDIT_USD=0` before you take real customer money.** Any non-zero value books a
> `promo` ledger entry that is real, spendable balance.

---

## 4. Going live, end to end

1. **Deploy** (Vercel, Fly, Railway, a VPS — anything that runs Next.js 16 + Postgres).
   Set `DATABASE_URL` and every variable above in the host's secret store.
2. **Custody**: create deposit addresses with your custody provider (Fireblocks, Coinbase Prime,
   BitGo, Anchorage…). Paste them into `DEPOSIT_ADDRESS_*`. Clients send funds on-chain.
3. **Fiat rail**: add `STRIPE_SECRET_KEY`. Card/ACH deposits then settle synchronously in
   `POST /api/wallet/deposit`; without a key they land in the operations queue instead.
4. **Operations**: sign in with an email in `ADMIN_EMAILS`, open `/app/admin`, approve or reject
   pending transfers. Approving a deposit credits the client balance; rejecting a withdrawal
   releases the locked funds back to the client.
5. **Automation (optional but recommended)**: `settleOpenOrders()` matches resting limit orders
   against the live book. It already runs on every client poll (`/api/account`, `/api/orders`).
   To also settle while nobody is watching, hit the endpoint from a scheduler:

   ```
   # crontab, every 15 seconds
   * * * * * for i in 1 2 3 4; do curl -s https://your-domain/api/account > /dev/null & sleep 15; done
   ```
6. **Compliance**: KYC/AML, travel-rule, licensing and terms of service are jurisdiction-specific.
   Plug your KYC vendor into `signup` and add the required disclosures before onboarding the public.

---

## 5. Architecture

```
src/
  db/schema.ts           users, sessions, balances, orders, trades, ledger_entries,
                         transfers, market_cache, login_events, rate_limits
  lib/
    market.ts            multi-venue price/candle engine + durable cache
    trading.ts           order placement, locked funds, limit matching, ledger, funding
    auth.ts              scrypt hashing, sessions, account opening
    config.ts            every business knob, env driven
    money.ts             decimal-safe rounding + formatters
  app/
    page.tsx             marketing site with a live market board
    login/ signup/       auth
    app/                 dashboard, trade/[symbol], portfolio, orders, wallet, admin
    api/                 auth, market, orders, account, wallet, admin, health
  components/            live-polling provider, chart, market list, trade ticket, views
```

### Order lifecycle

```
POST /api/orders
  ├─ market  buy  → fills at live ask, debits USD (notional + taker fee), credits coin, avg cost updated
  ├─ market  sell → fills at live bid, debits coin, credits USD (proceeds − fee), realised P/L journalled
  ├─ limit   buy  → reserves USD (qty × limit × (1 + maker fee)) into `locked`
  └─ limit   sell → reserves coin quantity into `locked`

settleOpenOrders()  → for every open order, if ask ≤ limit (buy) or bid ≥ limit (sell),
                      fills it at the better of market/limit and releases the reservation.
POST /api/orders/:id/cancel → releases the reservation, marks the order canceled.
```

Every leg writes an immutable `ledger_entries` row (`trade`, `fee`, `deposit`, `withdrawal`, `promo`).

### API surface

| Method | Route | Purpose |
|---|---|---|
| POST | `/api/auth/signup` | open account (+ session) |
| POST | `/api/auth/login` / `/api/auth/logout` | session |
| GET | `/api/auth/session` | current user |
| GET | `/api/market/tickers` | live board (all instruments) |
| GET | `/api/market/candles?symbol=&interval=` | OHLCV for the chart |
| GET/POST | `/api/orders` | list / place orders |
| POST | `/api/orders/:id/cancel` | cancel + release funds |
| GET | `/api/account` | portfolio, open orders, fills, ledger, fees |
| GET | `/api/wallet` | balances, transfers, ledger, deposit addresses |
| POST | `/api/wallet/deposit` · `/api/wallet/withdraw` | funding |
| GET/POST | `/api/admin/transfers` | operations queue |
| GET | `/api/health` | liveness + DB probe |

---

## 6. Risk disclosure

Digital assets are volatile. This software executes against third-party market data and keeps client
funds in an internal ledger. You are responsible for custody, licensing, KYC/AML and consumer
disclosures in every jurisdiction you serve.
