# Push to GitHub & deploy tidemark.

This app is a **Next.js server application with a PostgreSQL database**. That matters for one
big reason:

> ⚠️ **GitHub Pages will not run it.** Pages only serves static files (HTML/CSS/JS) — there is no
> Node server and no database. Your old `scardevonit.github.io/Trade-master` page was a static demo,
> so it worked there. This app must be hosted somewhere that runs Node + Postgres.
>
> GitHub is still the right home for the **code**. Deploy from the repo to a host (free tiers work).

---

## 1. Push the code to GitHub

```bash
cd tidemark

# initialise the repo
git init
git branch -M main

# stage everything EXCEPT secrets (see .gitignore)
git add .

# confirm .env is NOT in the list before committing
git status

git commit -m "tidemark: live crypto brokerage"

# create the empty repo on GitHub first, then:
git remote add origin https://github.com/<your-name>/<repo-name>.git
git push -u origin main
```

**Check `.gitignore` worked.** Run `git ls-files | grep -c .env` — it must print `1` (only
`.env.example`) and never `.env`. Your `DATABASE_URL` password lives in `.env`.

Already committed `.env` by mistake? Rotate the database password, then:

```bash
git rm --cached .env
git commit -m "remove secrets"
git push
```

### Repo settings worth switching on

- **Branch protection** on `main`: require the `CI` check to pass before merging.
- **Secrets** → *Settings → Secrets and variables → Actions* for anything the workflow needs.
- Add the repo URL and description; the MIT `LICENSE` is already included.

---

## 2. CI (already wired)

`.github/workflows/ci.yml` runs on every push and pull request:

1. spins up a PostgreSQL 16 service container
2. `npm ci`
3. `npx drizzle-kit push --force` (creates the schema in CI's database)
4. `npx next typegen` → `tsc --noEmit` → `npm run lint` → `npm run build`
5. boots `npm run start` and asserts `GET /api/health` returns `{"ok":true}`

If any step fails, the commit gets a red ❌ before it can reach production.

---

## 3. Deploy the app

### Option A — Vercel (fastest)

1. Push to GitHub (above).
2. <https://vercel.com/new> → **Import** the repo.
3. Add a Postgres database: in the Vercel project go to **Storage → Create Database → Postgres**
   (Neon-backed free tier), or create a free database at <https://neon.tech> and copy its
   connection string.
4. Add every variable from `.env.example` in **Settings → Environment Variables**:

   | Key | Value |
   |---|---|
   | `DATABASE_URL` | your Postgres connection string (with `?sslmode=require`) |
   | `TRADING_MODE` | `live` |
   | `TAKER_FEE_BPS` | `45` |
   | `MAKER_FEE_BPS` | `15` |
   | `MIN_ORDER_USD` | `10` |
   | `MAX_ORDER_USD` | `250000` |
   | `WITHDRAWAL_FEE_USD` | `1.5` |
   | `ADMIN_EMAILS` | your email |
   | `WELCOME_CREDIT_USD` | **`0`** for real money |
   | `DEPOSIT_ADDRESS_BTC/ETH/USDC/SOL` | your custody addresses |
   | `STRIPE_SECRET_KEY` | optional, enables instant card/ACH funding |

5. **Deploy.** Every future `git push` to `main` redeploys automatically.

Then create the tables in that production database once, from your machine:

```bash
DATABASE_URL="postgres://...prod..." npx drizzle-kit push --force
```

### Option B — Railway / Render / Fly.io

All three run Next.js + Postgres natively:

| Host | Setup |
|---|---|
| **Railway** | New Project → Deploy from GitHub → add the **Postgres** plugin → set env vars. `npm run build` / `npm start` are auto-detected. |
| **Render** | New → Web Service → build `npm install && npm run build`, start `npm run start`, add a Render Postgres instance. |
| **Fly.io** | `fly launch` (adds a `Dockerfile`) → `fly postgres create` → `fly postgres attach` → `fly secrets set DATABASE_URL=...` → `fly deploy`. |

### Option C — your own VPS

```bash
git clone https://github.com/<your-name>/<repo-name>.git && cd <repo-name>
cp .env.example .env && nano .env          # set DATABASE_URL + every knob
npm ci && npx drizzle-kit push --force && npm run build
pm2 start "npm run start" --name tidemark  # then point nginx/caddy at :3000
```

---

## 4. Keep a static page on GitHub Pages (optional)

If you want `your-name.github.io` to keep working as a front door, commit the single file in
[`github-pages/index.html`](./github-pages/index.html) to a separate `gh-pages` branch (or another
repo) and set `LAUNCH_URL` inside it to your deployed app. It is a one-page brand site that links
through to the real broker — no demo prices, no fake trading.

```bash
git checkout --orphan gh-pages
git rm -rf .
cp github-pages/index.html index.html
git add index.html && git commit -m "landing page"
git push origin gh-pages
# then: repo Settings → Pages → Branch: gh-pages
```

---

## 5. Post-deploy go-live checklist

- [ ] `GET /api/health` returns `{"ok":true}` on your production domain
- [ ] `WELCOME_CREDIT_USD=0` — no free spendable balance for strangers
- [ ] `ADMIN_EMAILS` contains your address → `/app/admin` shows the funding queue
- [ ] Deposit addresses set from your custody provider (Fireblocks / Prime / BitGo)
- [ ] Withdrawals either auto-approve (`AUTO_APPROVE_WITHDRAWALS=true`) or are manually reviewed
- [ ] Test a full loop in production: signup → deposit → market buy → limit order → cancel → withdraw
- [ ] KYC/AML provider wired into `signup` and jurisdiction licences confirmed
- [ ] Backups + point-in-time recovery enabled on the database (it holds the money ledger)
- [ ] Risk disclosure and terms of service published
