(function(){
const assets=[{s:"BTC",n:"Bitcoin",p:67420,icon:"₿",c:2.14},{s:"ETH",n:"Ethereum",p:3528.6,icon:"◆",c:1.28},{s:"SOL",n:"Solana",p:148.72,icon:"◎",c:4.36},{s:"XRP",n:"XRP",p:.6248,icon:"✕",c:-.82},{s:"ADA",n:"Cardano",p:.4512,icon:"₳",c:1.06}];
let selected=assets[0],side="buy";
const fmt=(n,d=n<1?4:2)=>"$"+n.toLocaleString("en-US",{minimumFractionDigits:d,maximumFractionDigits:d});
function render(){
document.getElementById("market-list").innerHTML=assets.map(a=>'<button class="asset '+(a===selected?'active':'')+'" data-s="'+a.s+'"><span class="coin"><span class="coin-icon">'+a.icon+'</span><span>'+a.s+'<span class="sub">'+a.n+'</span></span></span><span class="price">'+fmt(a.p)+'</span><span class="change '+(a.c<0?'neg':'')+'">'+(a.c>0?'+':'')+a.c.toFixed(2)+'%</span></button>').join("");
document.querySelectorAll(".asset").forEach(b=>b.addEventListener("click",()=>{selected=assets.find(a=>a.s===b.dataset.s);render();calc()}));
document.getElementById("selected-name").textContent=selected.n+" · "+selected.s;
document.getElementById("selected-price").textContent=fmt(selected.p);
}
function calc(){
let amount=Math.max(0,Number(document.getElementById("amount").value)||0),fee=amount*.0025,qty=amount/selected.p;
document.getElementById("quantity").textContent=qty.toFixed(selected.p<1?4:8)+" "+selected.s;
document.getElementById("fee").textContent=fmt(fee);
document.getElementById("total").textContent=fmt(side==="buy"?amount+fee:Math.max(0,amount-fee));
document.getElementById("total-label").textContent=side==="buy"?"Estimated total":"Estimated proceeds";
document.getElementById("place").textContent="Preview "+side+" order";
}
document.getElementById("amount").addEventListener("input",calc);
["buy","sell"].forEach(s=>document.getElementById(s).addEventListener("click",()=>{
side=s;document.getElementById("buy").setAttribute("aria-pressed",s==="buy");document.getElementById("sell").setAttribute("aria-pressed",s==="sell");calc()
}));
document.getElementById("place").addEventListener("click",()=>{
let amount=Number(document.getElementById("amount").value);
document.getElementById("status").textContent=amount>0?"Demo "+side+" preview ready for "+selected.s+". No real order was placed.":"Enter an amount greater than zero.";
});
render();calc();
})();