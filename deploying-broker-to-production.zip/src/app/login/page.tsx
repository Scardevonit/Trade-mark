"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setBusy(true);
    try {
      const r = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password: pw }),
      });
      const j = await r.json();
      if (!r.ok) setErr(j.error || "Login failed");
      else router.push("/app");
    } catch {
      setErr("Network error.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="grid min-h-screen place-items-center px-4 py-10">
      <div className="w-full max-w-md">
        <Link href="/" className="mb-6 block text-center text-3xl font-extrabold">tidemark<span className="text-[#7aa8ff]">.</span></Link>
        <div className="card p-6 sm:p-8">
          <h1 className="text-3xl font-extrabold">Welcome back</h1>
          <p className="mt-1 text-sm text-slate-400">Log in to your live ledger.</p>
          <form onSubmit={submit} className="mt-5 space-y-3">
            <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" type="email" required className="input px-4 py-3.5" />
            <input value={pw} onChange={(e) => setPw(e.target.value)} placeholder="Password" type="password" required className="input px-4 py-3.5" />
            {err && <p className="rounded-xl bg-rose-500/10 px-3 py-2.5 text-sm text-rose-200">{err}</p>}
            <button disabled={busy} className="btn-primary w-full py-4 text-[16px]">{busy ? "Logging in…" : "Log in"}</button>
          </form>
          <p className="mt-4 text-center text-sm text-slate-400">New here? <Link href="/signup" className="font-bold text-[#7aa8ff]">Create live account</Link></p>
        </div>
      </div>
    </main>
  );
}
