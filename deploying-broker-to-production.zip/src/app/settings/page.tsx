"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { TopNav } from "@/components/chrome";

type KeyRow = { id: string; provider: string; label: string; isPaper: boolean; keyPreview: string; createdAt: string };

export default function Settings() {
  const router = useRouter();
  const [mode, setMode] = useState("live_paper");
  const [provider, setProvider] = useState<string | null>(null);
  const [keys, setKeys] = useState<KeyRow[]>([]);
  const [form, setForm] = useState({ provider: "alpaca", apiKey: "", apiSecret: "", isPaper: true });
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  async function load() {
    const me = await fetch("/api/auth/me").then((r) => r.json());
    if (!me.user) return router.push("/signup?next=/settings");
    setMode(me.user.tradingMode);
    setProvider(me.user.brokerProvider);
    const k = await fetch("/api/broker-keys").then((r) => r.json());
    setKeys(k.keys ?? []);
  }
  useEffect(() => { load(); // eslint-disable-next-line
  }, []);

  async function saveKeys(e: React.FormEvent) {
    e.preventDefault();
    setErr(null); setMsg(null);
    const r = await fetch("/api/broker-keys", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const j = await r.json();
    if (!r.ok) setErr(j.error);
    else { setMsg(`${form.provider.toUpperCase()} keys saved — orders now route to your ${form.isPaper ? "paper" : "LIVE"} broker account.`); setForm({ ...form, apiKey: "", apiSecret: "" }); load(); }
  }

  async function setModeApi(m: string) {
    await fetch("/api/account", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ tradingMode: m }) });
    setMode(m);
    if (m === "live_paper") setProvider(null);
  }

  async function remove(id: string) {
    await fetch(`/api/broker-keys?id=${id}`, { method: "DELETE" });
    load();
  }

  return (
    <main className="min-h-screen pb-16">
      <TopNav />
      <div className="mx-auto max-w-3xl px-4 pt-6">
        <p className="eyebrow text-xs text-[#2ee6a8]">LIVE BROKER · REGULATED SETTLEMENT</p>
        <h1 className="mt-1 text-4xl font-extrabold">Go live for real</h1>
        <p className="mt-2 text-[15px] leading-relaxed text-slate-300">
          Tidemark cannot legally custody your funds alone. The compliant way to go live is to route
          settlement through a licensed broker <b>you own</b>. Paste API keys below and every order
          executes in your external account while Tidemark mirrors the ledger.
        </p>

        <div className="card mt-4 p-5">
          <p className="font-extrabold">Execution mode</p>
          <div className="mt-2 grid gap-2 sm:grid-cols-2">
            <button onClick={() => setModeApi("live_paper")} className={`rounded-2xl border p-4 text-left ${mode === "live_paper" ? "border-[#2ee6a8]/60 bg-[#2ee6a8]/10" : "border-white/10 bg-black/20"}`}>
              <p className="font-extrabold">Tidemark Live {mode === "live_paper" && "●"}</p>
              <p className="mt-1 text-[13px] text-slate-400">Internal real ledger at live market prices. Instant. Best for starting.</p>
            </button>
            <button onClick={() => setModeApi("live_broker")} className={`rounded-2xl border p-4 text-left ${mode === "live_broker" ? "border-[#7aa8ff]/60 bg-[#7aa8ff]/10" : "border-white/10 bg-black/20"}`}>
              <p className="font-extrabold">External broker {mode === "live_broker" && "●"}</p>
              <p className="mt-1 text-[13px] text-slate-400">Route to Alpaca / Coinbase / Kraken. Settlement in your account ({provider ?? "no provider yet"}).</p>
            </button>
          </div>
        </div>

        <form onSubmit={saveKeys} className="card mt-4 space-y-3 p-5">
          <p className="font-extrabold">Connect broker keys</p>
          <div className="grid gap-2 sm:grid-cols-2">
            <select value={form.provider} onChange={(e) => setForm({ ...form, provider: e.target.value })} className="input px-4 py-3">
              <option value="alpaca">Alpaca (stocks + crypto · recommended)</option>
              <option value="coinbase">Coinbase Advanced</option>
              <option value="kraken">Kraken</option>
              <option value="stripe">Stripe (funding)</option>
            </select>
            <label className="flex items-center gap-2 rounded-xl bg-white/5 px-3 py-3 text-sm font-bold">
              <input type="checkbox" checked={form.isPaper} onChange={(e) => setForm({ ...form, isPaper: e.target.checked })} />
              Paper / sandbox mode
            </label>
          </div>
          <input value={form.apiKey} onChange={(e) => setForm({ ...form, apiKey: e.target.value })} placeholder="API key" className="input px-4 py-3" required />
          <input value={form.apiSecret} onChange={(e) => setForm({ ...form, apiSecret: e.target.value })} placeholder="API secret" type="password" className="input px-4 py-3" />
          {err && <p className="rounded-xl bg-rose-500/10 px-3 py-2.5 text-sm text-rose-200">{err}</p>}
          {msg && <p className="rounded-xl bg-emerald-400/10 px-3 py-2.5 text-sm text-emerald-100">{msg}</p>}
          <button className="btn-primary w-full py-3.5">Save & enable live routing</button>
          <div className="rounded-2xl bg-black/25 p-4 text-[13px] leading-relaxed text-slate-400">
            <b className="text-slate-200">Where to get keys:</b>
            <br />• Alpaca: <span className="text-[#7aa8ff]">app.alpaca.markets → Your API keys</span> (start with Paper, uncheck paper for real money)
            <br />• Coinbase: <span className="text-[#7aa8ff]">Advanced → API → Create (trade permission only)</span>
            <br />• Kraken: <span className="text-[#7aa8ff]">Settings → API → Query + Trade only, no withdraw</span>
            <br />Never enable withdraw permission on trade keys.
          </div>
        </form>

        <div className="card mt-4 p-5">
          <p className="font-extrabold">Saved connections</p>
          <div className="mt-2 space-y-2">
            {keys.length === 0 && <p className="text-sm text-slate-500">No broker connected yet.</p>}
            {keys.map((k) => (
              <div key={k.id} className="flex items-center justify-between rounded-xl bg-black/25 px-3 py-2.5 text-sm">
                <span><b className="uppercase">{k.provider}</b> · {k.keyPreview} · {k.isPaper ? "paper" : "LIVE"}</span>
                <button onClick={() => remove(k.id)} className="rounded-lg bg-white/10 px-2.5 py-1 text-xs font-bold">Remove</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}
