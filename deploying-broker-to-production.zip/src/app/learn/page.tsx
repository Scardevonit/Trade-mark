import Link from "next/link";
import { TopNav } from "@/components/chrome";

const LESSONS = [
  ["What moves price?", "Supply, demand, liquidity and news. The chart in /app shows live Coinbase candles — green stretches mean buyers outnumber sellers at that moment.", "2 min"],
  ["Fees eat returns", "Tidemark shows the 0.25% fee before you confirm. On $100 that's $0.25. Frequent small trades compound fees — size accordingly.", "2 min"],
  ["Market vs limit", "Market fills now at live price. Limit only fills at your price or better — use it to avoid chasing spikes. Working limits live under Activity.", "3 min"],
  ["Never invest rent money", "Volatility cuts both ways. A 10% daily swing is normal in crypto. Fund only what you can leave untouched for years.", "2 min"],
  ["Broker vs ledger", "Tidemark Live keeps your ledger; Alpaca/Coinbase settles externally with SIPC/regulated custody. Connecting a broker is how you go from app to real brokerage.", "3 min"],
];

export default function Learn() {
  return (
    <main className="min-h-screen pb-16">
      <TopNav />
      <div className="mx-auto max-w-3xl px-4 pt-6">
        <p className="eyebrow text-xs text-[#2ee6a8]">LEARN · 10 MINUTES</p>
        <h1 className="mt-1 text-4xl font-extrabold">Understand before you order</h1>
        <div className="mt-4 space-y-3">
          {LESSONS.map(([t, d, m]) => (
            <div key={t} className="card p-5">
              <div className="flex items-center justify-between gap-2">
                <p className="text-lg font-extrabold">{t}</p>
                <span className="rounded-full bg-white/10 px-2.5 py-1 text-xs font-bold">{m}</span>
              </div>
              <p className="mt-1 text-[15px] leading-relaxed text-slate-300">{d}</p>
            </div>
          ))}
        </div>
        <Link href="/app" className="btn-primary mt-5 block py-4 text-center text-[16px]">Practice live with $1 →</Link>
      </div>
    </main>
  );
}
