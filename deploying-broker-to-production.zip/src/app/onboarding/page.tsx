"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { TopNav } from "@/components/chrome";

export default function Onboarding() {
  const router = useRouter();
  const [kyc, setKyc] = useState("none");
  const [form, setForm] = useState({ fullName: "", dob: "", country: "United States", address: "", idType: "drivers_license", idLast4: "" });
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetch("/api/auth/me").then(async (r) => {
      const j = await r.json();
      if (!j.user) return router.push("/signup?next=/onboarding");
      setKyc(j.user.kycStatus);
    });
  }, [router]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null); setMsg(null); setBusy(true);
    try {
      const r = await fetch("/api/kyc", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      const j = await r.json();
      if (!r.ok) setErr(j.error);
      else { setMsg(j.message); setKyc(j.status); }
    } catch { setErr("Network error."); }
    finally { setBusy(false); }
  }

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <main className="min-h-screen pb-16">
      <TopNav />
      <div className="mx-auto max-w-2xl px-4 pt-6">
        <p className="eyebrow text-xs text-[#2ee6a8]">IDENTITY · REQUIRED TO GO LIVE</p>
        <h1 className="mt-1 text-4xl font-extrabold">Verify your identity</h1>
        <p className="mt-1 text-sm text-slate-400">
          Status: <b className={kyc === "verified" ? "text-[#2ee6a8]" : "text-amber-200"}>{kyc.toUpperCase()}</b> · Starter limit $1k/day · Verified $25k/day
        </p>
        <form onSubmit={submit} className="card mt-4 space-y-3 p-6">
          <div className="grid gap-3 sm:grid-cols-2">
            <div><p className="mb-1 text-sm text-slate-400">Full legal name</p><input value={form.fullName} onChange={(e) => set("fullName", e.target.value)} required className="input px-4 py-3" placeholder="Ada Lovelace" /></div>
            <div><p className="mb-1 text-sm text-slate-400">Date of birth</p><input value={form.dob} onChange={(e) => set("dob", e.target.value)} required type="date" className="input px-4 py-3" /></div>
          </div>
          <div><p className="mb-1 text-sm text-slate-400">Country</p><input value={form.country} onChange={(e) => set("country", e.target.value)} required className="input px-4 py-3" /></div>
          <div><p className="mb-1 text-sm text-slate-400">Residential address</p><input value={form.address} onChange={(e) => set("address", e.target.value)} required className="input px-4 py-3" placeholder="Street, city, state, ZIP" /></div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div><p className="mb-1 text-sm text-slate-400">ID type</p>
              <select value={form.idType} onChange={(e) => set("idType", e.target.value)} className="input px-4 py-3">
                <option value="drivers_license">Driver's license</option>
                <option value="passport">Passport</option>
                <option value="national_id">National ID</option>
              </select>
            </div>
            <div><p className="mb-1 text-sm text-slate-400">ID last 4</p><input value={form.idLast4} onChange={(e) => set("idLast4", e.target.value)} required minLength={4} maxLength={4} className="input px-4 py-3" placeholder="1234" /></div>
          </div>
          {err && <p className="rounded-xl bg-rose-500/10 px-3 py-2.5 text-sm text-rose-200">{err}</p>}
          {msg && <p className="rounded-xl bg-emerald-400/10 px-3 py-2.5 text-sm text-emerald-100">{msg}</p>}
          <button disabled={busy} className="btn-primary w-full py-4">{busy ? "Submitting…" : "Submit verification"}</button>
          <p className="text-xs leading-relaxed text-slate-500">
            Production KYC plugs in here: set <code className="rounded bg-white/10 px-1">KYC_PROVIDER</code> (Persona / Alloy / Sumsub) and point its webhook at <code className="rounded bg-white/10 px-1">/api/kyc</code>.
            Full wiring guide is on the <a href="/go-live" className="underline text-[#7aa8ff]">Go-live page</a>.
          </p>
        </form>
      </div>
    </main>
  );
}
