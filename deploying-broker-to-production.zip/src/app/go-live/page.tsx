import Link from "next/link";
import { TopNav } from "@/components/chrome";

export const dynamic = "force-dynamic";

export default function GoLive() {
  const envLive = {
    alpaca: Boolean(process.env.ALPACA_API_KEY),
    stripe: Boolean(process.env.STRIPE_SECRET_KEY),
    kyc: Boolean(process.env.KYC_PROVIDER),
  };
  return (
    <main className="min-h-screen pb-16">
      <TopNav />
      <div className="mx-auto max-w-4xl px-4 pt-6">
        <p className="eyebrow text-xs text-[#2ee6a8]">FROM YOUR SCREENSHOT → PRODUCTION</p>
        <h1 className="mt-1 text-4xl font-extrabold sm:text-5xl">Make Tidemark go live <span className="text-[#7aa8ff]">— not a demo</span></h1>
        <p className="mt-3 text-[16px] leading-relaxed text-slate-300">
          Your screenshots showed a <b>demo market</b>. This build is already live: prices stream from
          Coinbase Exchange, accounts + cash + holdings persist in Postgres, and every order is a real
          ledger entry with explicit fees. Below are the <b>necessary files & keys</b> to handle real money.
        </p>

        <div className="card mt-5 p-6">
          <p className="font-extrabold">✅ Already live in this app (no key needed)</p>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-[15px] text-slate-300">
            <li>Live prices: <code className="rounded bg-white/10 px-1">src/lib/prices.ts</code> → <code className="rounded bg-white/10 px-1">/api/prices</code> + <code className="rounded bg-white/10 px-1">/api/candles</code> (Coinbase public, Kraken fallback)</li>
            <li>Real accounts: <code className="rounded bg-white/10 px-1">src/db/schema.ts</code> (users, sessions, holdings, orders, transactions, broker_keys)</li>
            <li>Order engine: <code className="rounded bg-white/10 px-1">src/app/api/orders/route.ts</code> + <code className="rounded bg-white/10 px-1">src/lib/broker.ts</code></li>
            <li>Funding ledger: <code className="rounded bg-white/10 px-1">src/app/api/funding/route.ts</code></li>
            <li>KYC capture: <code className="rounded bg-white/10 px-1">src/app/api/kyc/route.ts</code></li>
          </ul>
        </div>

        <div className="mt-4 grid gap-4 md:grid-cols-3">
          <div className="card p-5">
            <p className="font-extrabold">1 · Broker for real settlement</p>
            <p className="mt-1 text-sm text-slate-400">Status: {envLive.alpaca ? "✅ server keys present" : "⚠️ connect in Settings"}</p>
            <ol className="mt-2 list-decimal space-y-1 pl-5 text-sm text-slate-300">
              <li>Create <a className="underline text-[#7aa8ff]" href="https://alpaca.markets" target="_blank">Alpaca</a> account (free, US-regulated)</li>
              <li>Paper keys first → <Link href="/settings" className="underline">Settings → paste keys</Link></li>
              <li>Place order with venue “Alpaca” — see externalOrderId in Activity</li>
              <li>Uncheck “paper” only with real funds + completed KYC</li>
            </ol>
            <p className="mt-2 text-xs text-slate-500">Code: <code>ALPACA_API_KEY / ALPACA_API_SECRET / ALPACA_PAPER</code> in .env — see .env.example</p>
          </div>
          <div className="card p-5">
            <p className="font-extrabold">2 · Real deposits (Stripe)</p>
            <p className="mt-1 text-sm text-slate-400">Status: {envLive.stripe ? "✅ Stripe configured" : "⚠️ ledger-only mode"}</p>
            <ol className="mt-2 list-decimal space-y-1 pl-5 text-sm text-slate-300">
              <li>Create <a className="underline text-[#7aa8ff]" href="https://stripe.com" target="_blank">Stripe</a> account, get secret key</li>
              <li>Add <code className="rounded bg-white/10 px-1">STRIPE_SECRET_KEY</code> + webhook secret to .env</li>
              <li>Replace funding stub with PaymentIntents (snippet in GO-LIVE.md)</li>
              <li>Enable KYC-gated withdrawals</li>
            </ol>
          </div>
          <div className="card p-5">
            <p className="font-extrabold">3 · Identity (KYC/AML)</p>
            <p className="mt-1 text-sm text-slate-400">Status: {envLive.kyc ? "✅ provider set" : "⚠️ starter self-verify"}</p>
            <ol className="mt-2 list-decimal space-y-1 pl-5 text-sm text-slate-300">
              <li>Pick Persona / Alloy / Sumsub</li>
              <li>Set <code className="rounded bg-white/10 px-1">KYC_PROVIDER</code>, wire webhook → <code className="rounded bg-white/10 px-1">/api/kyc</code></li>
              <li>Require “verified” before withdrawals &gt; $1k</li>
              <li>Keep audit logs (orders + kyc_submissions tables already do)</li>
            </ol>
          </div>
        </div>

        <div className="card mt-4 p-6">
          <p className="font-extrabold">Necessary files included in this repo</p>
          <div className="mt-2 grid gap-2 text-sm sm:grid-cols-2">
            {[
              [".env.example", "Every secret you need for production"],
              ["GO-LIVE.md", "Step-by-step launch + legal checklist"],
              ["src/lib/broker.ts", "Alpaca live execution router"],
              ["src/lib/prices.ts", "Live Coinbase/Kraken feed"],
              ["src/db/schema.ts", "Ledger + KYC + broker-key tables"],
              ["src/app/api/orders/route.ts", "Market/limit engine with fees"],
              ["src/app/api/funding/route.ts", "Deposit/withdraw ledger + Stripe hook"],
              ["src/app/compliance/page.tsx", "Risk, Terms, Privacy pages"],
            ].map(([f, d]) => (
              <div key={f} className="rounded-xl bg-black/25 px-3 py-2.5">
                <p className="font-bold text-[#7aa8ff]">{f}</p>
                <p className="text-slate-400">{d}</p>
              </div>
            ))}
          </div>
          <div className="mt-4 flex flex-col gap-2 sm:flex-row">
            <Link href="/settings" className="btn-primary px-6 py-3.5 text-center">Connect broker now</Link>
            <Link href="/onboarding" className="btn-ghost px-6 py-3.5 text-center font-bold">Verify identity</Link>
            <Link href="/funding" className="btn-ghost px-6 py-3.5 text-center font-bold">Fund account</Link>
          </div>
        </div>

        <div className="mt-4 rounded-2xl border border-rose-300/20 bg-rose-500/[0.07] p-5 text-sm leading-relaxed text-rose-100/90">
          <b>Legal reality check (read before taking real money):</b> running your own crypto broker
          generally requires money-transmitter licenses (US state-by-state), FinCEN MSB registration,
          BSA/AML + sanctions screening, custody with a qualified custodian, and securities analysis
          (Howey). The compliant shortcut used by most startups is exactly what this app implements:
          <b> you are the interface, Alpaca/Coinbase is the regulated broker</b>. Talk to a fintech
          attorney before advertising “live trading” to the public.
        </div>
      </div>
    </main>
  );
}
