"use client";

import { Suspense, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";

function Form() {
  const router = useRouter();
  const sp = useSearchParams();
  const next = sp.get("next") || "/app";
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [pw, setPw] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setBusy(true);
    try {
      const r = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password: pw, displayName: name || "Trader" }),
      });
      const j = await r.json();
      if (!r.ok) setErr(j.error || "Signup failed");
      else router.push(next);
    } catch {
      setErr("Network error.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="card mx-auto w-full max-w-md p-6 sm:p-8">
      <p className="eyebrow text-xs text-[#2ee6a8]">LIVE ACCOUNT · REAL LEDGER</p>
      <h1 className="mt-2 text-3xl font-extrabold">Create your live account</h1>
      <p className="mt-1 text-sm text-slate-400">Starts with a $1,000.00 ledger balance you can top up. No demo reset.</p>
      <form onSubmit={submit} className="mt-5 space-y-3">
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Display name" className="input px-4 py-3.5" />
        <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" type="email" required className="input px-4 py-3.5" />
        <input value={pw} onChange={(e) => setPw(e.target.value)} placeholder="Password (8+ chars)" type="password" required minLength={8} className="input px-4 py-3.5" />
        {err && <p className="rounded-xl bg-rose-500/10 px-3 py-2.5 text-sm text-rose-200">{err}</p>}
        <button disabled={busy} className="btn-primary w-full py-4 text-[16px]">{busy ? "Creating…" : "Create live account"}</button>
      </form>
      <p className="mt-4 text-center text-sm text-slate-400">Have an account? <Link href="/login" className="font-bold text-[#7aa8ff]">Log in</Link></p>
      <p className="mt-3 text-xs leading-relaxed text-slate-500">By continuing you accept the <Link href="/compliance" className="underline">Risk Disclosure, Terms & Privacy</Link>. Crypto is volatile.</p>
    </div>
  );
}

export default function Signup() {
  return (
    <main className="grid min-h-screen place-items-center px-4 py-10">
      <div className="w-full max-w-md">
        <Link href="/" className="mb-6 block text-center text-3xl font-extrabold">tidemark<span className="text-[#7aa8ff]">.</span></Link>
        <Suspense><Form /></Suspense>
      </div>
    </main>
  );
}
