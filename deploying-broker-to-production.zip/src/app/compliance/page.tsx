import { TopNav } from "@/components/chrome";

export default function Compliance() {
  return (
    <main className="min-h-screen pb-16">
      <TopNav />
      <div className="mx-auto max-w-3xl px-4 pt-6">
        <h1 className="text-4xl font-extrabold">Risk, Terms & Privacy</h1>
        <p className="mt-1 text-sm text-slate-400">Last updated Nov 2026 · Required files to operate live</p>

        <div className="card mt-4 space-y-4 p-6 text-[15px] leading-relaxed text-slate-300">
          <section>
            <h2 className="text-xl font-extrabold text-white">Risk disclosure</h2>
            <p className="mt-1">Cryptoassets are highly volatile and can lose some or all value quickly. Past performance does not predict future results. Fees (0.25% shown pre-trade), spreads, and network conditions affect execution. Only trade money you can afford to lose. Tidemark provides market data and order tooling, not investment, tax, or legal advice.</p>
          </section>
          <section>
            <h2 className="text-xl font-extrabold text-white">How execution works</h2>
            <p className="mt-1"><b>Tidemark Live (default):</b> orders fill against live Coinbase reference prices and update your internal ledger (cash, holdings, fees) stored in Postgres. <b>External broker mode:</b> when you connect Alpaca/Coinbase/Kraken keys, orders are routed to that venue; settlement, custody, and 1099 reporting happen there. Working limit orders rest until the market touches or you cancel.</p>
          </section>
          <section>
            <h2 className="text-xl font-extrabold text-white">Terms (summary)</h2>
            <ul className="mt-1 list-disc pl-5">
              <li>You must be 18+ and legally allowed to trade crypto in your jurisdiction.</li>
              <li>You are responsible for your broker credentials, 2FA, and tax reporting.</li>
              <li>Deposits via bank/card are subject to provider approval, holds, and reversals.</li>
              <li>We may freeze accounts for suspected fraud, sanctions, or AML flags.</li>
              <li>Service is provided “as is”; market data may be delayed or interrupted.</li>
            </ul>
          </section>
          <section>
            <h2 className="text-xl font-extrabold text-white">Privacy (summary)</h2>
            <p className="mt-1">We store your email, password hash (bcrypt), ledger, orders, and KYC fields you submit. Broker secrets you paste are stored for routing and never displayed in full. We never sell personal data. For production you must add a DPA with your KYC, hosting, and payments sub-processors, plus data-retention and deletion procedures.</p>
          </section>
          <section>
            <h2 className="text-xl font-extrabold text-white">Licensing note</h2>
            <p className="mt-1">Tidemark software is not itself a broker-dealer, exchange, bank, or money transmitter. Operating a public live broker requires appropriate registrations and legal counsel in each jurisdiction you serve. Self-custody / interface-plus-licensed-broker (Alpaca, Coinbase) is the intended production pattern.</p>
          </section>
        </div>
      </div>
    </main>
  );
}
