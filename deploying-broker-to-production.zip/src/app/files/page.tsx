import Link from "next/link";
import { TopNav } from "@/components/chrome";

const GROUP_A = [
  "src/app/page.tsx — landing (your screenshot, now LIVE)",
  "src/app/app/page.tsx — trading terminal (market watch + ticket + chart)",
  "src/app/login/page.tsx — login",
  "src/app/signup/page.tsx — create live account",
  "src/app/funding/page.tsx — deposits / withdrawals",
  "src/app/activity/page.tsx — orders + cash history",
  "src/app/onboarding/page.tsx — KYC verify",
  "src/app/settings/page.tsx — connect Alpaca/Coinbase/Kraken",
  "src/app/go-live/page.tsx — go-live checklist (in app)",
  "src/app/compliance/page.tsx — Risk, Terms, Privacy",
  "src/app/learn/page.tsx — education",
  "src/app/files/page.tsx — this page",
  "src/app/layout.tsx — site shell + title",
  "src/app/globals.css — Tidemark theme",
  "src/components/chrome.tsx — nav + session hook",
];

const GROUP_B = [
  ".env.example — EVERY secret for production (Alpaca, Stripe, KYC, DB)",
  "GO-LIVE.md — step-by-step launch + legal checklist",
  "README.md — GitHub front page + deploy guide",
  ".gitignore — keeps .env + node_modules off GitHub",
  "package.json — deps (bcryptjs, drizzle, next, pg)",
  "drizzle.config.json + src/db/schema.ts — users, holdings, orders, transactions, broker_keys, kyc",
  "src/db/index.ts — Postgres connection",
  "src/lib/prices.ts — LIVE Coinbase/Kraken feed",
  "src/lib/broker.ts — Alpaca LIVE execution router",
  "src/lib/auth.ts — sessions",
  "src/lib/format.ts — money, fees, assets",
  "src/app/api/prices/route.ts — GET live quotes",
  "src/app/api/candles/route.ts — GET chart candles",
  "src/app/api/auth/signup/route.ts — POST create account",
  "src/app/api/auth/login/route.ts — POST login",
  "src/app/api/auth/logout/route.ts — POST logout",
  "src/app/api/auth/me/route.ts — GET session",
  "src/app/api/portfolio/route.ts — GET cash + holdings + P&L",
  "src/app/api/orders/route.ts — GET + POST + DELETE orders (the engine)",
  "src/app/api/funding/route.ts — POST deposit/withdraw",
  "src/app/api/kyc/route.ts — POST identity",
  "src/app/api/broker-keys/route.ts — save Alpaca/Coinbase keys",
  "src/app/api/account/route.ts — switch live_paper / live_broker",
  "src/app/api/health/route.ts — healthcheck",
];

export default function FilesPage() {
  return (
    <main className="min-h-screen pb-16">
      <TopNav />
      <div className="mx-auto max-w-3xl px-4 pt-6">
        <p className="eyebrow text-xs text-[#2ee6a8]">GITHUB UPLOAD · ALL FILES</p>
        <h1 className="mt-1 text-4xl font-extrabold">Take Tidemark to GitHub</h1>
        <p className="mt-2 text-[15px] leading-relaxed text-slate-300">
          Everything below is inside <b>one zip</b>. Download it on your phone or computer,
          upload to GitHub, and your live broker (not the old demo) is backed up + deployable.
        </p>

        <a
          href="/tidemark-live.zip"
          download
          className="btn-primary mt-4 block py-4 text-center text-lg"
        >
          ⬇ Download ALL files (.zip, ~60KB)
        </a>
        <p className="mt-2 text-center text-xs text-slate-500">
          Contains all of Group A + Group B. Unzip → upload. No secrets inside (.env is excluded).
        </p>

        <div className="card mt-4 p-5">
          <p className="font-extrabold">Group B — backend + live-broker files (the “necessary files”)</p>
          <ul className="mt-2 space-y-1 text-[13px] leading-snug text-slate-300">
            {GROUP_B.map((f) => (
              <li key={f} className="rounded-lg bg-black/25 px-2.5 py-1.5 font-mono">{f}</li>
            ))}
          </ul>
        </div>

        <div className="card mt-3 p-5">
          <p className="font-extrabold">Group A — app pages (frontend)</p>
          <ul className="mt-2 space-y-1 text-[13px] leading-snug text-slate-300">
            {GROUP_A.map((f) => (
              <li key={f} className="rounded-lg bg-black/25 px-2.5 py-1.5 font-mono">{f}</li>
            ))}
          </ul>
        </div>

        <div className="card mt-4 space-y-3 p-5 text-[15px] leading-relaxed">
          <p className="text-xl font-extrabold">Upload from your phone (no computer needed)</p>
          <ol className="list-decimal space-y-2 pl-5 text-slate-300">
            <li>Tap the <b>download button</b> above → unzip the file (Android: Files app → tap zip → Extract; iPhone: Files app → tap zip).</li>
            <li>Go to <b>github.com → + → New repository</b> → name it <code className="rounded bg-white/10 px-1">tidemark-live</code> → Public → Create.</li>
            <li>On the new repo page tap <b>“uploading an existing file”</b> → drag/select <b>all unzipped files & folders</b> → Commit. Do it in 2 batches if your phone struggles (first: root files + <code className="rounded bg-white/10 px-1">src</code> folder).</li>
            <li>Check the repo shows <code className="rounded bg-white/10 px-1">README.md</code>, <code className="rounded bg-white/10 px-1">GO-LIVE.md</code>, <code className="rounded bg-white/10 px-1">.env.example</code>, <code className="rounded bg-white/10 px-1">src/…</code> — done.</li>
          </ol>
          <div className="rounded-2xl bg-black/25 p-4 text-sm text-slate-400">
            <b className="text-slate-200">From a computer (recommended):</b>
            <pre className="mt-2 overflow-x-auto rounded-xl bg-black/50 p-3 font-mono text-[12px] leading-relaxed text-emerald-200">{`# unzip, then:
cd tidemark-live
git init -b main
git add .
git commit -m "Tidemark live broker"
git remote add origin https://github.com/YOU/tidemark-live.git
git push -u origin main

# run it anywhere:
npm install
cp .env.example .env   # fill DATABASE_URL
npx drizzle-kit push
npm run dev`}</pre>
          </div>
          <p className="text-sm text-slate-400">
            Your old demo (<code className="rounded bg-white/10 px-1">scarddevonit.github.io/Trade-m…</code>) is GitHub Pages (static only — it can never hold logins or real orders).
            This app needs <b>Vercel + Postgres</b> (free tiers work). After pushing here, Import the repo at{" "}
            <b>vercel.com → add <code className="rounded bg-white/10 px-1">DATABASE_URL</code></b> → Deploy. Full steps in README + GO-LIVE.md.
          </p>
          <div className="flex flex-col gap-2 sm:flex-row">
            <Link href="/go-live" className="btn-ghost flex-1 py-3 text-center font-bold">Go-live checklist</Link>
            <Link href="/app" className="btn-ghost flex-1 py-3 text-center font-bold">Back to terminal</Link>
          </div>
        </div>
      </div>
    </main>
  );
}
