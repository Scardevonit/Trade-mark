"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { TopNav } from "@/components/chrome";
import { SUPPORTED_ASSETS, feeFor, usd } from "@/lib/format";

type Quote = {
  symbol: string;
  name: string;
  priceUsd: number;
  change24hPct: number;
  high24h: number;
  low24h: number;
  source: string;
};

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };

export default function TradeApp() {
  const router = useRouter();
  const [me, setMe] = useState<{ displayName: string; cashCents: number } | null>(null);
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [symbol, setSymbol] = useState("BTC");
  const [side, setSide] = useState<"buy" | "sell">("buy");
  const [orderType, setOrderType] = useState<"market" | "limit">("market");
  const [amount, setAmount] = useState("100");
  const [limitPx, setLimitPx] = useState("");
  const [venue, setVenue] = useState("auto");
  const [candles, setCandles] = useState<Candle[]>([]);
  const [tf, setTf] = useState("1H");
  const [portfolio, setPortfolio] = useState<{
    cashUsd: number;
    holdingsValueUsd: number;
    totalEquityUsd: number;
    holdings: { symbol: string; qtyNum: number; livePriceUsd: number; marketValueUsd: number; pnlUsd: number; pnlPct: number }[];
    orders: { id: string; symbol: string; side: string; qty: string; status: string; executedPriceUsd: string | null; totalUsd: string | null; venue: string; createdAt: string }[];
  } | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [placing, setPlacing] = useState(false);
  const [live, setLive] = useState(true);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  const loadMe = useCallback(async () => {
    const r = await fetch("/api/auth/me");
    const j = await r.json();
    if (!j.user) {
      router.push("/signup?next=/app");
      return;
    }
    setMe(j.user);
  }, [router]);

  const loadPrices = useCallback(async () => {
    try {
      const r = await fetch("/api/prices", { cache: "no-store" });
      const j = await r.json();
      if (j.quotes) {
        setQuotes(j.quotes);
        setLive(j.live !== false);
      }
    } catch { /* keep stale */ }
  }, []);

  const loadPortfolio = useCallback(async () => {
    try {
      const r = await fetch("/api/portfolio", { cache: "no-store" });
      if (r.status === 401) {
        router.push("/signup?next=/app");
        return;
      }
      const j = await r.json();
      setPortfolio(j);
      if (j.cashCents !== undefined && me) setMe((m) => (m ? { ...m, cashCents: j.cashCents } : m));
    } catch { /* ignore */ }
  }, [router, me]);

  const loadCandles = useCallback(async (s: string, t: string) => {
    try {
      const r = await fetch(`/api/candles?symbol=${s}&tf=${t}`, { cache: "no-store" });
      const j = await r.json();
      if (j.candles) setCandles(j.candles.slice(-60));
    } catch { /* ignore */ }
  }, []);

  useEffect(() => {
    loadMe();
    loadPrices();
    loadPortfolio();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    loadCandles(symbol, tf);
  }, [symbol, tf, loadCandles]);

  useEffect(() => {
    timer.current = setInterval(() => {
      loadPrices();
    }, 8000);
    const t2 = setInterval(() => loadPortfolio(), 15000);
    return () => {
      if (timer.current) clearInterval(timer.current);
      clearInterval(t2);
    };
  }, [loadPrices, loadPortfolio]);

  const active = useMemo(() => quotes.find((q) => q.symbol === symbol), [quotes, symbol]);
  const price = active?.priceUsd ?? 0;
  const amtNum = Number(amount) || 0;
  const effPrice = orderType === "limit" && Number(limitPx) > 0 ? Number(limitPx) : price;
  const estQty = effPrice > 0 ? amtNum / effPrice : 0;
  const estFee = feeFor(amtNum);
  const estTotal = side === "buy" ? amtNum + estFee : amtNum - estFee;

  async function place() {
    setErr(null);
    setMsg(null);
    if (!amtNum || amtNum < 1) {
      setErr("Enter at least $1.00.");
      return;
    }
    setPlacing(true);
    try {
      const r = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symbol,
          side,
          orderType,
          usdAmount: amtNum,
          limitPrice: orderType === "limit" ? Number(limitPx) : null,
          venue,
        }),
      });
      const j = await r.json();
      if (!r.ok) {
        setErr(j.error || "Order failed.");
      } else if (j.working) {
        setMsg(`Limit order working: ${side.toUpperCase()} ${symbol} @ $${Number(limitPx).toLocaleString()}. We'll hold it until the market touches.`);
        await loadPortfolio();
      } else {
        setMsg(
          `${side.toUpperCase()} filled: ${(amtNum / j.executedPrice).toFixed(6)} ${symbol} @ ${usd(j.executedPrice)} (fee ${usd(j.fee)}) via ${j.order.venue}.`
        );
        await loadPortfolio();
        await loadMe();
      }
    } catch {
      setErr("Network error placing order.");
    } finally {
      setPlacing(false);
    }
  }

  const myHolding = portfolio?.holdings.find((h) => h.symbol === symbol);

  // Simple SVG chart
  const chart = useMemo(() => {
    if (candles.length < 2) return null;
    const W = 640, H = 220, P = 12;
    const closes = candles.map((c) => c.close);
    const mn = Math.min(...closes), mx = Math.max(...closes);
    const span = mx - mn || 1;
    const pts = closes.map((c, i) => {
      const x = P + (i / (closes.length - 1)) * (W - P * 2);
      const y = H - P - ((c - mn) / span) * (H - P * 2);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    });
    const up = closes[closes.length - 1] >= closes[0];
    return { W, H, line: `M${pts.join(" L")}`, up, mn, mx };
  }, [candles]);

  return (
    <main className="min-h-screen pb-16">
      <TopNav user={me} />
      <div className="mx-auto max-w-6xl px-4 pt-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="eyebrow flex items-center gap-2 text-[12px] text-[#2ee6a8]">
            <span className="live-dot inline-block h-2 w-2 rounded-full bg-[#2ee6a8]" />
            {live ? "LIVE MARKET · COINBASE FEED" : "RECONNECTING FEED…"}
          </p>
          <div className="flex gap-2 text-[13px]">
            <Link href="/funding" className="btn-ghost px-3 py-1.5 font-bold">Deposit</Link>
            <Link href="/settings" className="btn-ghost px-3 py-1.5 font-bold">Connect broker</Link>
          </div>
        </div>

        {/* Portfolio strip */}
        <div className="card mt-3 grid grid-cols-3 gap-2 p-4 sm:p-5">
          <div>
            <p className="text-xs text-slate-400">Total equity</p>
            <p className="num text-xl font-extrabold sm:text-2xl">{usd(portfolio?.totalEquityUsd ?? (me ? me.cashCents / 100 : 0))}</p>
          </div>
          <div>
            <p className="text-xs text-slate-400">Cash</p>
            <p className="num text-xl font-extrabold sm:text-2xl">{usd(portfolio?.cashUsd ?? (me ? me.cashCents / 100 : 0))}</p>
          </div>
          <div>
            <p className="text-xs text-slate-400">Invested</p>
            <p className="num text-xl font-extrabold sm:text-2xl">{usd(portfolio?.holdingsValueUsd ?? 0)}</p>
          </div>
        </div>

        <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_380px]">
          <div className="space-y-4">
            {/* Asset selector */}
            <div className="card p-3">
              <div className="scroll-thin flex gap-2 overflow-x-auto pb-1">
                {SUPPORTED_ASSETS.map((a) => {
                  const q = quotes.find((x) => x.symbol === a.symbol);
                  const sel = symbol === a.symbol;
                  return (
                    <button
                      key={a.symbol}
                      onClick={() => setSymbol(a.symbol)}
                      className={`min-w-[132px] flex-1 rounded-2xl border px-3 py-2.5 text-left transition ${
                        sel ? "border-[#7aa8ff]/60 bg-[#7aa8ff]/10" : "border-white/10 bg-black/20 hover:bg-white/5"
                      }`}
                    >
                      <p className="text-sm font-extrabold">{a.symbol}</p>
                      <p className="num text-[15px] font-bold">{q ? usd(q.priceUsd) : "…"}</p>
                      <p className={`num text-xs font-bold ${ (q?.change24hPct ?? 0) >= 0 ? "text-[#2ee6a8]" : "text-rose-300"}`}>
                        {q ? `${q.change24hPct >= 0 ? "+" : ""}${q.change24hPct.toFixed(2)}%` : ""}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Chart */}
            <div className="card p-4 sm:p-6">
              <div className="flex flex-wrap items-end justify-between gap-2">
                <div>
                  <h2 className="text-2xl font-extrabold">{active?.name ?? symbol} · {symbol}</h2>
                  <p className="num text-3xl font-extrabold">{price ? usd(price) : "…"}</p>
                  <p className="text-sm text-slate-400">
                    24h H {active ? usd(active.high24h) : "—"} · L {active ? usd(active.low24h) : "—"} ·{" "}
                    <span className={(active?.change24hPct ?? 0) >= 0 ? "text-[#2ee6a8]" : "text-rose-300"}>
                      {(active?.change24hPct ?? 0).toFixed(2)}%
                    </span>
                  </p>
                </div>
                <div className="flex gap-1.5">
                  {["15M", "1H", "4H", "1D"].map((t) => (
                    <button
                      key={t}
                      onClick={() => setTf(t)}
                      className={`rounded-full px-3 py-1.5 text-xs font-extrabold ${tf === t ? "bg-[#7aa8ff] text-[#0a1430]" : "bg-white/5 text-slate-300"}`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
              <div className="mt-3 overflow-hidden rounded-2xl border border-white/10 bg-black/30 p-2">
                {chart ? (
                  <svg viewBox={`0 0 ${chart.W} ${chart.H}`} className="h-[190px] w-full sm:h-[220px]">
                    <defs>
                      <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={chart.up ? "#2ee6a8" : "#fb7185"} stopOpacity="0.45" />
                        <stop offset="100%" stopColor={chart.up ? "#2ee6a8" : "#fb7185"} stopOpacity="0" />
                      </linearGradient>
                    </defs>
                    <path d={`${chart.line} L${chart.W - 12},${chart.H - 12} L12,${chart.H - 12} Z`} fill="url(#g)" />
                    <path d={chart.line} fill="none" stroke={chart.up ? "#2ee6a8" : "#fb7185"} strokeWidth="2.5" strokeLinejoin="round" />
                  </svg>
                ) : (
                  <p className="py-14 text-center text-sm text-slate-500">Loading live chart…</p>
                )}
              </div>
              <p className="mt-2 text-xs text-slate-500">Live candles · Coinbase Exchange · {tf} · last {candles.length} periods</p>
              {myHolding && (
                <div className="mt-3 rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm">
                  Holding: <b className="num">{myHolding.qtyNum} {symbol}</b> · worth <b className="num">{usd(myHolding.marketValueUsd)}</b> ·{" "}
                  <span className={myHolding.pnlUsd >= 0 ? "text-[#2ee6a8]" : "text-rose-300"}>
                    {myHolding.pnlUsd >= 0 ? "+" : ""}{usd(myHolding.pnlUsd)} ({myHolding.pnlPct.toFixed(2)}%)
                  </span>
                </div>
              )}
            </div>

            {/* Holdings + orders */}
            <div className="grid gap-4 md:grid-cols-2">
              <div className="card p-4">
                <p className="font-extrabold">Your positions</p>
                <div className="mt-2 space-y-2">
                  {(portfolio?.holdings ?? []).length === 0 && (
                    <p className="text-sm text-slate-500">No positions yet — place your first live order.</p>
                  )}
                  {(portfolio?.holdings ?? []).map((h) => (
                    <button key={h.symbol} onClick={() => setSymbol(h.symbol)} className="flex w-full items-center justify-between rounded-xl bg-black/25 px-3 py-2.5 text-sm hover:bg-white/5">
                      <span className="font-extrabold">{h.symbol} <span className="num font-normal text-slate-400">{h.qtyNum}</span></span>
                      <span className="num font-bold">{usd(h.marketValueUsd)}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div className="card p-4">
                <div className="flex items-center justify-between">
                  <p className="font-extrabold">Recent orders</p>
                  <Link href="/activity" className="text-xs font-bold text-[#7aa8ff]">View all →</Link>
                </div>
                <div className="mt-2 space-y-2">
                  {(portfolio?.orders ?? []).slice(0, 5).length === 0 && (
                    <p className="text-sm text-slate-500">No orders yet.</p>
                  )}
                  {(portfolio?.orders ?? []).slice(0, 5).map((o) => (
                    <div key={o.id} className="flex items-center justify-between rounded-xl bg-black/25 px-3 py-2.5 text-[13px]">
                      <span>
                        <b className={o.side === "buy" ? "text-[#2ee6a8]" : "text-rose-300"}>{o.side.toUpperCase()}</b>{" "}
                        <b>{o.symbol}</b> <span className="text-slate-500">· {o.status} · {o.venue}</span>
                      </span>
                      <span className="num font-bold">{o.totalUsd ? usd(Number(o.totalUsd)) : "—"}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Ticket — matches screenshot layout */}
          <div className="card h-fit overflow-hidden lg:sticky lg:top-20">
            <div className="px-5 pt-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-lg font-extrabold">{active?.name ?? symbol} · {symbol}</p>
                  <p className="num text-xl font-extrabold">{price ? usd(price) : "…"}</p>
                </div>
                <span className="eyebrow pt-1 text-[11px] text-[#2ee6a8]">● LIVE</span>
              </div>

              <div className="mt-3 grid grid-cols-2 gap-2 rounded-2xl border border-white/10 bg-black/30 p-1.5">
                {(["buy", "sell"] as const).map((s) => (
                  <button
                    key={s}
                    onClick={() => setSide(s)}
                    className={`py-3 text-center text-[17px] font-extrabold capitalize rounded-xl ${
                      side === s ? (s === "buy" ? "btn-mint" : "bg-rose-400 text-[#2a0a12]") : "text-slate-400"
                    }`}
                  >
                    {s === "buy" ? "Buy" : "Sell"}
                  </button>
                ))}
              </div>

              <div className="mt-3 grid grid-cols-3 gap-2 text-[13px] font-bold">
                <button onClick={() => setOrderType("market")} className={`rounded-xl px-2 py-2 ${orderType === "market" ? "bg-white/15" : "bg-white/5 text-slate-400"}`}>Market</button>
                <button onClick={() => setOrderType("limit")} className={`rounded-xl px-2 py-2 ${orderType === "limit" ? "bg-white/15" : "bg-white/5 text-slate-400"}`}>Limit</button>
                <select value={venue} onChange={(e) => setVenue(e.target.value)} className="rounded-xl bg-white/5 px-2 py-2 text-slate-200 outline-none">
                  <option value="auto" className="text-black">Auto venue</option>
                  <option value="alpaca" className="text-black">Alpaca</option>
                  <option value="coinbase" className="text-black">Coinbase</option>
                  <option value="kraken" className="text-black">Kraken</option>
                </select>
              </div>

              <p className="mb-2 mt-4 text-slate-400">Amount in USD</p>
              <input value={amount} onChange={(e) => setAmount(e.target.value)} inputMode="decimal" className="input px-4 py-4 text-lg num" placeholder="100" />
              <div className="mt-2 flex gap-2">
                {["25", "100", "500", "1000"].map((v) => (
                  <button key={v} onClick={() => setAmount(v)} className="flex-1 rounded-xl bg-white/5 py-2 text-sm font-bold text-slate-300 hover:bg-white/10">${v}</button>
                ))}
              </div>

              {orderType === "limit" && (
                <div className="mt-3">
                  <p className="mb-2 text-slate-400">Limit price (USD)</p>
                  <input value={limitPx} onChange={(e) => setLimitPx(e.target.value)} inputMode="decimal" placeholder={price ? String(Math.round(price)) : ""} className="input px-4 py-3.5 num" />
                </div>
              )}

              <div className="mt-4 space-y-2 text-[15px]">
                <div className="flex justify-between"><span className="text-slate-400">Estimated quantity</span><b className="num">{estQty.toFixed(6)} {symbol}</b></div>
                <div className="flex justify-between"><span className="text-slate-400">Live fee (0.25%)</span><b className="num">{usd(estFee)}</b></div>
                <div className="flex justify-between"><span className="text-slate-400">Estimated total</span><b className="num">{usd(estTotal)}</b></div>
                {side === "sell" && myHolding && <div className="flex justify-between text-[13px]"><span className="text-slate-500">Available</span><span className="num">{myHolding.qtyNum} {symbol}</span></div>}
              </div>

              {err && <p className="mt-3 rounded-xl border border-rose-400/30 bg-rose-500/10 px-3 py-2.5 text-sm text-rose-200">{err}</p>}
              {msg && <p className="mt-3 rounded-xl border border-emerald-300/30 bg-emerald-400/10 px-3 py-2.5 text-sm text-emerald-100">{msg}</p>}

              <button onClick={place} disabled={placing} className={`mt-4 w-full py-4 text-lg ${side === "buy" ? "btn-mint" : "rounded-xl bg-rose-400 font-extrabold text-[#2a0a12]"} disabled:opacity-60`}>
                {placing ? "Placing…" : `${side === "buy" ? "Buy" : "Sell"} ${symbol} · ${usd(estTotal)}`}
              </button>
              <p className="py-3 text-center text-xs leading-relaxed text-slate-500">
                Executed at live market {price ? usd(price) : ""} · {venue === "auto" ? "auto venue" : venue} ·
                real ledger update. <Link href="/go-live" className="underline">How settlement works</Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
