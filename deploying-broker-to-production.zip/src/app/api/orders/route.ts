import { NextResponse } from "next/server";
import { db } from "@/db";
import { brokerKeys, holdings, orders, transactions, users } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { getPrice } from "@/lib/prices";
import { feeFor, SUPPORTED_ASSETS } from "@/lib/format";
import { routeOrder, type Venue } from "@/lib/broker";

export const dynamic = "force-dynamic";

export async function GET() {
  const u = await getCurrentUser();
  if (!u) return NextResponse.json({ error: "Login required" }, { status: 401 });
  const rows = await db
    .select()
    .from(orders)
    .where(eq(orders.userId, u.id))
    .orderBy(desc(orders.createdAt))
    .limit(100);
  return NextResponse.json({ orders: rows });
}

export async function POST(req: Request) {
  const u = await getCurrentUser();
  if (!u) return NextResponse.json({ error: "Login required" }, { status: 401 });
  try {
    const body = await req.json();
    const symbol = String(body.symbol ?? "").toUpperCase();
    const side = String(body.side ?? "").toLowerCase() as "buy" | "sell";
    const orderType = String(body.orderType ?? "market").toLowerCase();
    const usdAmount = Number(body.usdAmount ?? 0);
    const qtyInput = Number(body.qty ?? 0);
    const limitPrice = body.limitPrice ? Number(body.limitPrice) : null;
    const requestedVenue = String(body.venue ?? "auto").toLowerCase();

    const asset = SUPPORTED_ASSETS.find((a) => a.symbol === symbol);
    if (!asset) return NextResponse.json({ error: "Unsupported asset." }, { status: 400 });
    if (side !== "buy" && side !== "sell")
      return NextResponse.json({ error: "Side must be buy or sell." }, { status: 400 });

    // Fresh user row (cash ledger)
    const [fresh] = await db.select().from(users).where(eq(users.id, u.id)).limit(1);
    if (!fresh) return NextResponse.json({ error: "Account not found." }, { status: 404 });

    const livePrice = await getPrice(symbol);

    // Determine execution price
    let execPrice = livePrice;
    if (orderType === "limit") {
      if (!limitPrice || limitPrice <= 0)
        return NextResponse.json({ error: "Limit price required for limit orders." }, { status: 400 });
      // For live simplicity: marketable limits fill immediately, others rest as working
      const marketable =
        (side === "buy" && limitPrice >= livePrice) || (side === "sell" && limitPrice <= livePrice);
      if (!marketable) {
        // Rest working order — no funds moved yet
        const estQty = usdAmount > 0 ? usdAmount / limitPrice : qtyInput;
        if (!estQty || estQty <= 0)
          return NextResponse.json({ error: "Enter an amount." }, { status: 400 });
        const inserted = await db
          .insert(orders)
          .values({
            userId: u.id,
            symbol,
            side,
            orderType: "limit",
            qty: String(estQty),
            limitPriceUsd: String(limitPrice),
            status: "working",
            venue: "tidemark_live",
            note: `Working limit ${side} ${estQty} ${symbol} @ $${limitPrice}. Fills when market touches.`,
          })
          .returning();
        return NextResponse.json({ ok: true, order: inserted[0], working: true });
      }
      execPrice = limitPrice;
    }

    // Resolve qty + totals
    let qty = qtyInput;
    if (usdAmount > 0) qty = usdAmount / execPrice;
    if (!qty || qty <= 0 || !isFinite(qty))
      return NextResponse.json({ error: "Enter a valid amount (min $1)." }, { status: 400 });
    qty = Math.floor(qty * 1e8) / 1e8;
    const gross = qty * execPrice;
    if (gross < 1) return NextResponse.json({ error: "Minimum order is $1.00." }, { status: 400 });
    const fee = feeFor(gross);

    // Resolve venue
    let venue: Venue = "tidemark_live";
    if (requestedVenue === "alpaca" || fresh.brokerProvider === "alpaca" || fresh.tradingMode === "live_broker") {
      // check if user has alpaca keys, else fall back unless explicitly requested
      const keys = await db
        .select()
        .from(brokerKeys)
        .where(and(eq(brokerKeys.userId, u.id), eq(brokerKeys.provider, "alpaca")))
        .limit(1);
      if (keys.length > 0) venue = "alpaca";
      else if (requestedVenue === "alpaca")
        return NextResponse.json(
          { error: "No Alpaca keys found. Add them in Settings → Live broker first." },
          { status: 400 }
        );
      else if (fresh.brokerProvider === "alpaca")
        return NextResponse.json(
          { error: "Broker mode is Alpaca but no keys are saved. Add keys or switch to Tidemark Live." },
          { status: 400 }
        );
    } else if (requestedVenue === "coinbase" || requestedVenue === "kraken") {
      venue = requestedVenue as Venue;
    }

    // Balance checks (internal ledger)
    const cashUsd = fresh.cashCents / 100;
    if (side === "buy") {
      const total = gross + fee;
      if (total > cashUsd + 1e-9)
        return NextResponse.json(
          { error: `Insufficient cash. Need $${total.toFixed(2)} (incl. $${fee.toFixed(2)} fee), have $${cashUsd.toFixed(2)}. Deposit to continue.` },
          { status: 400 }
        );
    } else {
      const [h] = await db
        .select()
        .from(holdings)
        .where(and(eq(holdings.userId, u.id), eq(holdings.symbol, symbol)))
        .limit(1);
      const have = h ? Number(h.qty) : 0;
      if (qty > have + 1e-12)
        return NextResponse.json(
          { error: `Insufficient ${symbol}. You hold ${have}, tried to sell ${qty}.` },
          { status: 400 }
        );
    }

    // Route to venue (Alpaca live call happens here)
    let alpacaKey: string | undefined;
    let alpacaSecret: string | undefined;
    let alpacaPaper = true;
    if (venue === "alpaca") {
      const keys = await db
        .select()
        .from(brokerKeys)
        .where(and(eq(brokerKeys.userId, u.id), eq(brokerKeys.provider, "alpaca")))
        .limit(1);
      alpacaKey = keys[0]?.apiKey;
      alpacaSecret = keys[0]?.apiSecret;
      alpacaPaper = keys[0]?.isPaper ?? true;
    }
    const routed = await routeOrder({
      symbol,
      side,
      qty,
      livePriceUsd: execPrice,
      venue,
      alpacaKey,
      alpacaSecret,
      alpacaPaper,
    });

    const finalPrice = routed.executedPriceUsd;
    const finalGross = qty * finalPrice;
    const finalFee = feeFor(finalGross);
    const total = side === "buy" ? finalGross + finalFee : finalGross - finalFee;

    // Update ledger atomically-ish (single user flow)
    if (side === "buy") {
      const newCash = Math.round((cashUsd - total) * 100);
      await db.update(users).set({ cashCents: newCash, updatedAt: new Date() }).where(eq(users.id, u.id));
      const [h] = await db
        .select()
        .from(holdings)
        .where(and(eq(holdings.userId, u.id), eq(holdings.symbol, symbol)))
        .limit(1);
      if (!h) {
        await db.insert(holdings).values({ userId: u.id, symbol, qty: String(qty), avgCostUsd: String(finalPrice) });
      } else {
        const oldQty = Number(h.qty);
        const oldAvg = Number(h.avgCostUsd);
        const newQty = oldQty + qty;
        const newAvg = (oldQty * oldAvg + qty * finalPrice) / newQty;
        await db
          .update(holdings)
          .set({ qty: String(newQty), avgCostUsd: String(newAvg), updatedAt: new Date() })
          .where(eq(holdings.id, h.id));
      }
      await db.insert(transactions).values({
        userId: u.id,
        kind: "buy",
        amountCents: -Math.round(total * 100),
        status: routed.status === "filled" ? "completed" : "pending",
        method: venue === "tidemark_live" ? "cash" : "broker_sync",
        reference: `${side.toUpperCase()} ${qty} ${symbol} @ $${finalPrice.toFixed(2)} fee $${finalFee.toFixed(2)}`,
      });
    } else {
      const proceeds = finalGross - finalFee;
      const newCash = Math.round((cashUsd + proceeds) * 100);
      await db.update(users).set({ cashCents: newCash, updatedAt: new Date() }).where(eq(users.id, u.id));
      const [h] = await db
        .select()
        .from(holdings)
        .where(and(eq(holdings.userId, u.id), eq(holdings.symbol, symbol)))
        .limit(1);
      if (h) {
        const newQty = Number(h.qty) - qty;
        if (newQty <= 1e-12) await db.delete(holdings).where(eq(holdings.id, h.id));
        else
          await db
            .update(holdings)
            .set({ qty: String(newQty), updatedAt: new Date() })
            .where(eq(holdings.id, h.id));
      }
      await db.insert(transactions).values({
        userId: u.id,
        kind: "sell",
        amountCents: Math.round(proceeds * 100),
        status: routed.status === "filled" ? "completed" : "pending",
        method: venue === "tidemark_live" ? "cash" : "broker_sync",
        reference: `${side.toUpperCase()} ${qty} ${symbol} @ $${finalPrice.toFixed(2)} fee $${finalFee.toFixed(2)}`,
      });
    }

    const inserted = await db
      .insert(orders)
      .values({
        userId: u.id,
        symbol,
        side,
        orderType,
        qty: String(qty),
        limitPriceUsd: limitPrice ? String(limitPrice) : null,
        status: routed.status,
        venue: routed.venue,
        executedPriceUsd: String(finalPrice),
        feeUsd: String(finalFee),
        totalUsd: String(Math.round(total * 100) / 100),
        externalOrderId: routed.externalOrderId,
        note: routed.note,
      })
      .returning();

    return NextResponse.json({ ok: true, order: inserted[0], executedPrice: finalPrice, fee: finalFee });
  } catch (e) {
    console.error("order error", e);
    const msg = e instanceof Error ? e.message : "Order failed.";
    return NextResponse.json({ error: msg.slice(0, 400) }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  const u = await getCurrentUser();
  if (!u) return NextResponse.json({ error: "Login required" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
  await db
    .update(orders)
    .set({ status: "cancelled" })
    .where(and(eq(orders.id, id), eq(orders.userId, u.id)));
  return NextResponse.json({ ok: true });
}
