import { NextResponse } from "next/server";
import { db } from "@/db";
import { holdings, orders, transactions, users } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { getLiveQuotes } from "@/lib/prices";

export const dynamic = "force-dynamic";

export async function GET() {
  const u = await getCurrentUser();
  if (!u) return NextResponse.json({ error: "Login required" }, { status: 401 });

  const [fresh] = await db.select().from(users).where(eq(users.id, u.id)).limit(1);
  const holdRows = await db.select().from(holdings).where(eq(holdings.userId, u.id));
  const orderRows = await db
    .select()
    .from(orders)
    .where(eq(orders.userId, u.id))
    .orderBy(desc(orders.createdAt))
    .limit(50);
  const txRows = await db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, u.id))
    .orderBy(desc(transactions.createdAt))
    .limit(50);

  const quotes = await getLiveQuotes().catch(() => []);
  const priceMap = new Map(quotes.map((q) => [q.symbol, q.priceUsd]));

  let holdingsValue = 0;
  const enriched = holdRows.map((h) => {
    const px = priceMap.get(h.symbol) ?? Number(h.avgCostUsd) ?? 0;
    const qty = Number(h.qty);
    const val = qty * px;
    holdingsValue += val;
    const avg = Number(h.avgCostUsd);
    const pnl = (px - avg) * qty;
    const pnlPct = avg > 0 ? ((px - avg) / avg) * 100 : 0;
    return {
      symbol: h.symbol,
      qty: h.qty,
      qtyNum: qty,
      avgCostUsd: h.avgCostUsd,
      livePriceUsd: px,
      marketValueUsd: Math.round(val * 100) / 100,
      pnlUsd: Math.round(pnl * 100) / 100,
      pnlPct: Math.round(pnlPct * 100) / 100,
    };
  });

  const cashUsd = (fresh?.cashCents ?? 0) / 100;
  const totalEquity = Math.round((cashUsd + holdingsValue) * 100) / 100;

  return NextResponse.json({
    cashUsd,
    cashCents: fresh?.cashCents ?? 0,
    holdingsValueUsd: Math.round(holdingsValue * 100) / 100,
    totalEquityUsd: totalEquity,
    holdings: enriched,
    orders: orderRows,
    transactions: txRows,
    quotes,
    user: {
      displayName: fresh?.displayName,
      kycStatus: fresh?.kycStatus,
      tradingMode: fresh?.tradingMode,
      brokerProvider: fresh?.brokerProvider,
    },
  });
}
