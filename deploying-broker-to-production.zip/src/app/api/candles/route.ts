import { NextResponse } from "next/server";
import { getCandles } from "@/lib/prices";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const symbol = (searchParams.get("symbol") || "BTC").toUpperCase();
  const tf = searchParams.get("tf") || "1H";
  const gran = tf === "15M" ? 900 : tf === "4H" ? 14400 : tf === "1D" ? 86400 : 3600;
  try {
    const candles = await getCandles(symbol, gran);
    return NextResponse.json({ symbol, tf, candles });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Chart feed unavailable" }, { status: 502 });
  }
}
