import { NextResponse } from "next/server";
import { db } from "@/db";
import { kycSubmissions, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export async function POST(req: Request) {
  const u = await getCurrentUser();
  if (!u) return NextResponse.json({ error: "Login required" }, { status: 401 });
  try {
    const b = await req.json();
    const fullName = String(b.fullName ?? "").trim();
    const dob = String(b.dob ?? "").trim();
    const country = String(b.country ?? "").trim();
    const address = String(b.address ?? "").trim();
    const idType = String(b.idType ?? "drivers_license").trim();
    const idLast4 = String(b.idLast4 ?? "").trim();
    if (!fullName || !dob || !country || !address || idLast4.length < 4)
      return NextResponse.json({ error: "Complete all identity fields." }, { status: 400 });

    await db.insert(kycSubmissions).values({
      userId: u.id,
      fullName,
      dob,
      country,
      address,
      idType,
      idLast4: idLast4.slice(-4),
      status: "pending",
    });
    // Auto-verify starter tier instantly (production: webhook from Persona/Alloy/Sumsub here)
    // Standard tier with real IDV provider = set KYC_PROVIDER env + verify webhook.
    const useStrict = Boolean(process.env.KYC_PROVIDER);
    await db
      .update(users)
      .set({
        kycStatus: useStrict ? "pending" : "verified",
        kycTier: useStrict ? "starter" : "standard",
        updatedAt: new Date(),
      })
      .where(eq(users.id, u.id));

    return NextResponse.json({
      ok: true,
      status: useStrict ? "pending" : "verified",
      message: useStrict
        ? "Submitted for verification. Provider webhook will update your status."
        : "Verified instantly (starter compliance mode). Connect a KYC provider for production IDV.",
    });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "KYC failed." }, { status: 500 });
  }
}
