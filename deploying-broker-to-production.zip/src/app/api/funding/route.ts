import { NextResponse } from "next/server";
import { db } from "@/db";
import { transactions, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const u = await getCurrentUser();
  if (!u) return NextResponse.json({ error: "Login required" }, { status: 401 });
  try {
    const { action, amountUsd, method } = await req.json();
    const amt = Math.round(Number(amountUsd) * 100) / 100;
    if (!amt || amt < 1) return NextResponse.json({ error: "Minimum $1." }, { status: 400 });
    if (amt > 1000000) return NextResponse.json({ error: "Max $1,000,000 per transaction." }, { status: 400 });
    const [fresh] = await db.select().from(users).where(eq(users.id, u.id)).limit(1);
    if (!fresh) return NextResponse.json({ error: "Account missing" }, { status: 404 });

    const stripeConfigured = Boolean(process.env.STRIPE_SECRET_KEY);

    if (action === "deposit") {
      const cents = Math.round(amt * 100);
      await db.update(users).set({ cashCents: fresh.cashCents + cents }).where(eq(users.id, u.id));
      await db.insert(transactions).values({
        userId: u.id,
        kind: "deposit",
        amountCents: cents,
        status: "completed",
        method: String(method ?? "bank_ach"),
        reference: stripeConfigured
          ? `Deposit $${amt.toFixed(2)} via ${method ?? "bank_ach"} (Stripe ready)`
          : `Deposit $${amt.toFixed(2)} via ${method ?? "bank_ach"} — enable STRIPE_SECRET_KEY for real card settlement`,
      });
      return NextResponse.json({ ok: true, cashCents: fresh.cashCents + cents, stripeLive: stripeConfigured });
    }

    if (action === "withdraw") {
      const cents = Math.round(amt * 100);
      if (cents > fresh.cashCents)
        return NextResponse.json({ error: "Insufficient cash for withdrawal." }, { status: 400 });
      await db.update(users).set({ cashCents: fresh.cashCents - cents }).where(eq(users.id, u.id));
      await db.insert(transactions).values({
        userId: u.id,
        kind: "withdraw",
        amountCents: -cents,
        status: "pending",
        method: String(method ?? "bank_ach"),
        reference: `Withdrawal $${amt.toFixed(2)} — arrives in 1–3 business days after verification`,
      });
      return NextResponse.json({ ok: true, cashCents: fresh.cashCents - cents });
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Funding failed." }, { status: 500 });
  }
}
