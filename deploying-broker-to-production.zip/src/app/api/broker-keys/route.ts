import { NextResponse } from "next/server";
import { db } from "@/db";
import { brokerKeys, users } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const u = await getCurrentUser();
  if (!u) return NextResponse.json({ error: "Login required" }, { status: 401 });
  const rows = await db.select().from(brokerKeys).where(eq(brokerKeys.userId, u.id));
  const masked = rows.map((r) => ({
    id: r.id,
    provider: r.provider,
    label: r.label,
    isPaper: r.isPaper,
    keyPreview: r.apiKey ? `${r.apiKey.slice(0, 4)}••••${r.apiKey.slice(-3)}` : "",
    createdAt: r.createdAt,
  }));
  return NextResponse.json({ keys: masked });
}

export async function POST(req: Request) {
  const u = await getCurrentUser();
  if (!u) return NextResponse.json({ error: "Login required" }, { status: 401 });
  try {
    const { provider, apiKey, apiSecret, isPaper } = await req.json();
    const p = String(provider ?? "").toLowerCase();
    if (!["alpaca", "coinbase", "kraken", "stripe"].includes(p))
      return NextResponse.json({ error: "Unknown provider" }, { status: 400 });
    if (!String(apiKey ?? "").trim())
      return NextResponse.json({ error: "API key required" }, { status: 400 });

    // Upsert one row per provider
    const existing = await db
      .select()
      .from(brokerKeys)
      .where(and(eq(brokerKeys.userId, u.id), eq(brokerKeys.provider, p)))
      .limit(1);
    if (existing.length > 0) {
      await db
        .update(brokerKeys)
        .set({
          apiKey: String(apiKey).trim(),
          apiSecret: String(apiSecret ?? ""),
          isPaper: Boolean(isPaper ?? true),
        })
        .where(eq(brokerKeys.id, existing[0].id));
    } else {
      await db.insert(brokerKeys).values({
        userId: u.id,
        provider: p,
        apiKey: String(apiKey).trim(),
        apiSecret: String(apiSecret ?? ""),
        isPaper: Boolean(isPaper ?? true),
      });
    }
    if (p === "alpaca") {
      await db
        .update(users)
        .set({
          tradingMode: "live_broker",
          brokerProvider: "alpaca",
          updatedAt: new Date(),
        })
        .where(eq(users.id, u.id));
    }
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Could not save keys." }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  const u = await getCurrentUser();
  if (!u) return NextResponse.json({ error: "Login required" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
  await db.delete(brokerKeys).where(and(eq(brokerKeys.id, id), eq(brokerKeys.userId, u.id)));
  return NextResponse.json({ ok: true });
}
