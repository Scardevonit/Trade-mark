"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { TopNav } from "@/components/chrome";
import { usd } from "@/lib/format";

export default function Funding() {
  const router = useRouter();
  const [cash, setCash] = useState(0);
  const [amount, setAmount] = useState("500");
  const [method, setMethod] = useState("bank_ach");
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function load() {
    const r = await fetch("/api/portfolio");
    if (r.status === 401) return router.push("/signup?next=/funding");
    const j = await r.json();
    setCash(j.cashUsd ?? 0);
  }
  useEffect(() => { load(); // eslint-disable-next-line
  }, []);

  async function act(action: "deposit" | "withdraw") {
    setErr(null); setMsg(null); setBusy(true);
    try {
      const r = await fetch("/api/funding", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, amountUsd: Number(amount), method }),
      });
      const j = await r.json();
      if (!r.ok) setErr(j.error);
      else {
        setCash(j.cashCents / 100);
        setMsg(action === "deposit" ? `Deposited ${usd(Number(amount))} — available to trade now.` : `Withdrawal of ${usd(Number(amount))} queued (1–3 business days).`);
      }
    } catch { setErr("Network error."); }
    finally { setBusy(false); }
  }

  return (
    <main className="min-h-screen pb-16">
      <TopNav />
      <div className="mx-auto max-w-3xl px-4 pt-6">
        <p className="eyebrow text-xs text-[#2ee6a8]">FUNDING · REAL LEDGER</p>
        <h1 className="mt-1 text-4xl font-extrabold">Move money</h1>
        <div className="card mt-4 p-6">
          <p className="text-sm text-slate-400">Available cash</p>
          <p className="num text-4xl font-extrabold">{usd(cash)}</p>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            <div>
              <p className="mb-2 text-sm text-slate-400">Amount (USD)</p>
              <input value={amount} onChange={(e) => setAmount(e.target.value)} inputMode="decimal" className="input num px-4 py-3.5 text-lg" />
              <div className="mt-2 flex gap-2">
                {["100", "500", "1000", "5000"].map((v) => (
                  <button key={v} onClick={() => setAmount(v)} className="flex-1 rounded-xl bg-white/5 py-2 text-sm font-bold">${v}</button>
                ))}
              </div>
            </div>
            <div>
              <p className="mb-2 text-sm text-slate-400">Rail</p>
              <div className="grid gap-2">
                {[
                  ["bank_ach", "Bank · ACH (1–3 days, free)"],
                  ["card", "Debit card (instant, 1.5% via Stripe when live)"],
                  ["wire", "Wire (same-day, manual review)"],
                ].map(([v, l]) => (
                  <button key={v} onClick={() => setMethod(v)} className={`rounded-xl border px-3 py-2.5 text-left text-sm font-bold ${method === v ? "border-[#7aa8ff]/60 bg-[#7aa8ff]/10" : "border-white/10 bg-black/20"}`}>{l}</button>
                ))}
              </div>
            </div>
          </div>
          {err && <p className="mt-3 rounded-xl bg-rose-500/10 px-3 py-2.5 text-sm text-rose-200">{err}</p>}
          {msg && <p className="mt-3 rounded-xl bg-emerald-400/10 px-3 py-2.5 text-sm text-emerald-100">{msg}</p>}
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            <button onClick={() => act("deposit")} disabled={busy} className="btn-mint py-4 text-[16px] disabled:opacity-60">Deposit</button>
            <button onClick={() => act("withdraw")} disabled={busy} className="btn-ghost py-4 text-[16px] font-bold disabled:opacity-60">Withdraw</button>
          </div>
          <div className="mt-4 rounded-2xl border border-white/10 bg-black/25 p-4 text-[13px] leading-relaxed text-slate-400">
            <b className="text-slate-200">To settle real cards & bank transfers:</b> add <code className="rounded bg-white/10 px-1">STRIPE_SECRET_KEY</code>,{" "}
            <code className="rounded bg-white/10 px-1">STRIPE_WEBHOOK_SECRET</code> and a KYC provider key (see <a href="/go-live" className="underline text-[#7aa8ff]">Go-live files</a>).
            Until then deposits credit your live internal ledger instantly and are marked for later Stripe reconciliation — the correct pattern for going live without holding funds illegally.
          </div>
        </div>
      </div>
    </main>
  );
}
