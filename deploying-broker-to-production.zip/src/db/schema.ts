import {
  pgTable,
  text,
  timestamp,
  integer,
  numeric,
  uuid,
  boolean,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  displayName: text("display_name").notNull().default("Trader"),
  cashCents: integer("cash_cents").notNull().default(100000), // $1,000.00 starter, real ledger
  kycStatus: text("kyc_status").notNull().default("none"), // none | pending | verified | rejected
  kycTier: text("kyc_tier").notNull().default("starter"), // starter | standard | advanced
  tradingMode: text("trading_mode").notNull().default("live_paper"), // live_paper | live_broker
  brokerProvider: text("broker_provider"), // alpaca | coinbase | kraken | null
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const sessions = pgTable("sessions", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const holdings = pgTable("holdings", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  symbol: text("symbol").notNull(),
  qty: numeric("qty", { precision: 24, scale: 12 }).notNull().default("0"),
  avgCostUsd: numeric("avg_cost_usd", { precision: 24, scale: 8 })
    .notNull()
    .default("0"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const orders = pgTable("orders", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  symbol: text("symbol").notNull(),
  side: text("side").notNull(), // buy | sell
  orderType: text("order_type").notNull().default("market"), // market | limit
  qty: numeric("qty", { precision: 24, scale: 12 }).notNull(),
  limitPriceUsd: numeric("limit_price_usd", { precision: 24, scale: 8 }),
  status: text("status").notNull().default("filled"), // filled | working | cancelled | rejected | routed
  venue: text("venue").notNull().default("tidemark_live"), // tidemark_live | alpaca | coinbase | kraken
  executedPriceUsd: numeric("executed_price_usd", { precision: 24, scale: 8 }),
  feeUsd: numeric("fee_usd", { precision: 24, scale: 8 }).notNull().default("0"),
  totalUsd: numeric("total_usd", { precision: 24, scale: 8 }),
  externalOrderId: text("external_order_id"),
  note: text("note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const transactions = pgTable("transactions", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  kind: text("kind").notNull(), // deposit | withdraw | buy | sell | fee | adjustment
  amountCents: integer("amount_cents").notNull(),
  status: text("status").notNull().default("completed"), // pending | completed | failed
  method: text("method"), // bank_ach | card | crypto | broker_sync | cash
  reference: text("reference"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const brokerKeys = pgTable("broker_keys", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  provider: text("provider").notNull(), // alpaca | coinbase | kraken | stripe
  label: text("label").notNull().default("live"),
  apiKey: text("api_key").notNull(),
  apiSecret: text("api_secret").notNull().default(""),
  isPaper: boolean("is_paper").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const kycSubmissions = pgTable("kyc_submissions", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  fullName: text("full_name").notNull(),
  dob: text("dob").notNull(),
  country: text("country").notNull(),
  address: text("address").notNull(),
  idType: text("id_type").notNull(),
  idLast4: text("id_last4").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
