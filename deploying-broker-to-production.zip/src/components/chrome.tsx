"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export function TopNav({ user }: { user?: { displayName?: string; cashCents?: number } | null }) {
  const path = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  }

  const links = [
    { href: "/app", label: "Trade" },
    { href: "/funding", label: "Funding" },
    { href: "/activity", label: "Activity" },
    { href: "/onboarding", label: "Verify" },
    { href: "/settings", label: "Live broker" },
    { href: "/go-live", label: "Go-live" },
    { href: "/files", label: "GitHub files" },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-[#060d1d]/85 backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link href="/" className="text-[26px] font-extrabold tracking-tight">
          tidemark<span className="text-[#7aa8ff]">.</span>
        </Link>
        <nav className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={`rounded-full px-3 py-1.5 text-sm font-semibold ${
                path === l.href ? "bg-white/10 text-white" : "text-slate-300 hover:bg-white/5"
              }`}
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          {user ? (
            <>
              <span className="num hidden rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-sm font-bold sm:block">
                {(((user.cashCents ?? 0) / 100) as number).toLocaleString("en-US", {
                  style: "currency",
                  currency: "USD",
                })}
              </span>
              <button onClick={logout} className="btn-ghost px-3 py-1.5 text-sm font-bold">
                Log out
              </button>
              <button
                onClick={() => setOpen(!open)}
                className="rounded-full bg-white/10 px-3 py-1.5 text-sm font-bold md:hidden"
              >
                ☰
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className="btn-ghost hidden px-4 py-2 text-sm font-bold sm:block">
                Log in
              </Link>
              <Link href="/app" className="btn-primary px-4 py-2 text-sm">
                Launch app ↗
              </Link>
              <button
                onClick={() => setOpen(!open)}
                className="rounded-full bg-white/10 px-3 py-1.5 text-sm font-bold md:hidden"
              >
                ☰
              </button>
            </>
          )}
        </div>
      </div>
      {open && (
        <div className="grid gap-1 border-t border-white/10 px-4 py-3 md:hidden">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="rounded-xl bg-white/5 px-3 py-2.5 text-sm font-bold"
            >
              {l.label}
            </Link>
          ))}
          {!user && (
            <Link href="/login" className="rounded-xl bg-white/5 px-3 py-2.5 text-sm font-bold">
              Log in
            </Link>
          )}
        </div>
      )}
    </header>
  );
}

export function useMe() {
  const [me, setMe] = useState<null | {
    id: string;
    email: string;
    displayName: string;
    cashCents: number;
    kycStatus: string;
    tradingMode: string;
    brokerProvider: string | null;
  }>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((j) => setMe(j.user))
      .finally(() => setLoading(false));
  }, []);
  return { me, loading, refresh: () => fetch("/api/auth/me").then((r) => r.json()).then((j) => setMe(j.user)) };
}

export function RiskBanner() {
  return (
    <div className="mx-auto max-w-6xl px-4 pt-4">
      <div className="rounded-2xl border border-amber-300/20 bg-amber-300/[0.07] px-4 py-3 text-[13px] leading-relaxed text-amber-100/90">
        <b className="text-amber-200">Live market risk:</b> Crypto is volatile and you can lose money.
        Prices here are live reference prices. Orders in <b>Tidemark Live</b> update a real internal
        ledger; routing to <b>Alpaca / Coinbase / Kraken</b> settles in your regulated brokerage
        account. Not investment advice.
      </div>
    </div>
  );
}
