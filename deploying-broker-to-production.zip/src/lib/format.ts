export function usd(n: number | string): string {
  const v = typeof n === "string" ? Number(n) : n;
  if (!isFinite(v)) return "$0.00";
  return v.toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

export function qtyFmt(n: number | string, digits = 6): string {
  const v = typeof n === "string" ? Number(n) : n;
  if (!isFinite(v)) return "0";
  if (v === 0) return "0";
  if (v >= 1000) return v.toLocaleString("en-US", { maximumFractionDigits: 2 });
  return v.toLocaleString("en-US", { maximumFractionDigits: digits, minimumFractionDigits: 0 });
}

export function pct(n: number): string {
  const s = n >= 0 ? "+" : "";
  return `${s}${n.toFixed(2)}%`;
}

export function timeAgo(d: Date | string): string {
  const t = typeof d === "string" ? new Date(d) : d;
  const s = Math.floor((Date.now() - t.getTime()) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return t.toLocaleDateString();
}

export const SUPPORTED_ASSETS = [
  { symbol: "BTC", name: "Bitcoin", coinbase: "BTC-USD", decimals: 8, color: "#F7931A" },
  { symbol: "ETH", name: "Ethereum", coinbase: "ETH-USD", decimals: 8, color: "#8A9CFF" },
  { symbol: "SOL", name: "Solana", coinbase: "SOL-USD", decimals: 6, color: "#2EE6A8" },
  { symbol: "USDC", name: "USD Coin", coinbase: "USDC-USD", decimals: 2, color: "#2775CA" },
  { symbol: "DOGE", name: "Dogecoin", coinbase: "DOGE-USD", decimals: 2, color: "#D3B755" },
  { symbol: "AVAX", name: "Avalanche", coinbase: "AVAX-USD", decimals: 6, color: "#E84142" },
  { symbol: "LINK", name: "Chainlink", coinbase: "LINK-USD", decimals: 6, color: "#5A7DFF" },
  { symbol: "MATIC", name: "Polygon", coinbase: "MATIC-USD", decimals: 4, color: "#8247E5" },
] as const;

export type AssetSymbol = (typeof SUPPORTED_ASSETS)[number]["symbol"];

export const FEE_BPS = 25; // 0.25% explicit, shown pre-trade like your demo

export function feeFor(usdAmount: number): number {
  return Math.round(((usdAmount * FEE_BPS) / 10000) * 100) / 100;
}
