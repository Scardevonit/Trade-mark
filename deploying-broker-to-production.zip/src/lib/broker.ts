// Order router: paper/internal live ledger + external regulated venues.
// To go fully live with custody + real settlement you MUST route through a
// licensed broker. This file implements that routing for Alpaca (US, FINRA/SIPC
// for securities; crypto via Bakkt/Alpaca Crypto) and pass-through stubs for
// Coinbase Advanced + Kraken. Keys are per-user (Settings page) or global env.

export type Venue = "tidemark_live" | "alpaca" | "coinbase" | "kraken";

export type RouteResult = {
  venue: Venue;
  executedPriceUsd: number;
  externalOrderId: string | null;
  status: "filled" | "routed";
  note: string;
};

const ALPACA_CRYPTO_MAP: Record<string, string> = {
  BTC: "BTC/USD",
  ETH: "ETH/USD",
  SOL: "SOL/USD",
  DOGE: "DOGE/USD",
  AVAX: "AVAX/USD",
  LINK: "LINK/USD",
  USDC: "USDC/USD",
  MATIC: "MATIC/USD",
};

export async function routeOrder(opts: {
  symbol: string;
  side: "buy" | "sell";
  qty: number;
  livePriceUsd: number;
  venue: Venue;
  alpacaKey?: string;
  alpacaSecret?: string;
  alpacaPaper?: boolean;
}): Promise<RouteResult> {
  const { symbol, side, qty, livePriceUsd, venue } = opts;

  if (venue === "alpaca") {
    const key = opts.alpacaKey || process.env.ALPACA_API_KEY || "";
    const secret = opts.alpacaSecret || process.env.ALPACA_API_SECRET || "";
    const paperEnv = (process.env.ALPACA_PAPER ?? "true").toLowerCase() !== "false";
    const usePaper = opts.alpacaPaper ?? paperEnv;
    if (!key || !secret) {
      throw new Error(
        "Missing Alpaca keys. Add them in Settings → Live broker or set ALPACA_API_KEY / ALPACA_API_SECRET."
      );
    }
    const base = usePaper
      ? "https://paper-api.alpaca.markets"
      : "https://api.alpaca.markets";
    const alpacaSymbol = ALPACA_CRYPTO_MAP[symbol.toUpperCase()]?.replace("/", "") ?? `${symbol.toUpperCase()}USD`;

    // Alpaca crypto orders: use notional for buys, qty for sells
    const body =
      side === "buy"
        ? {
            symbol: alpacaSymbol,
            notional: String(Math.round(qty * livePriceUsd * 100) / 100),
            side: "buy",
            type: "market",
            time_in_force: "gtc",
          }
        : {
            symbol: alpacaSymbol,
            qty: String(qty),
            side: "sell",
            type: "market",
            time_in_force: "gtc",
          };

    const res = await fetch(`${base}/v2/orders`, {
      method: "POST",
      headers: {
        "APCA-API-KEY-ID": key,
        "APCA-API-SECRET-KEY": secret,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(
        `Alpaca rejected order (${res.status}): ${(json as { message?: string }).message || JSON.stringify(json).slice(0, 300)}`
      );
    }
    const j = json as { id?: string; filled_avg_price?: string; status?: string };
    const filledPx = j.filled_avg_price ? Number(j.filled_avg_price) : livePriceUsd;
    const isFilled = j.status === "filled";
    return {
      venue: "alpaca",
      executedPriceUsd: isFilled && filledPx > 0 ? filledPx : livePriceUsd,
      externalOrderId: j.id ?? null,
      status: isFilled ? "filled" : "routed",
      note: `Routed to Alpaca ${usePaper ? "paper" : "LIVE"} (${alpacaSymbol}). Status: ${j.status ?? "accepted"}. Settlement happens in your Alpaca account.`,
    };
  }

  if (venue === "coinbase" || venue === "kraken") {
    // Pass-through: we record intent + live price, user settles in their exchange account.
    // Full OAuth/API-trading wiring is in docs/GO-LIVE.md — enable by adding keys in Settings.
    return {
      venue,
      executedPriceUsd: livePriceUsd,
      externalOrderId: null,
      status: "routed",
      note: `Recorded for ${venue}. Connect API keys in Settings to enable automatic execution; otherwise execute in your ${venue} account at ~$${livePriceUsd.toLocaleString()}. Ledger updated to mirror it.`,
    };
  }

  // Default: internal live ledger executed at live Coinbase market price.
  return {
    venue: "tidemark_live",
    executedPriceUsd: livePriceUsd,
    externalOrderId: null,
    status: "filled",
    note: `Filled internally at live market $${livePriceUsd.toLocaleString()} (Coinbase reference).`,
  };
}

export function venueLabel(v: string): string {
  if (v === "alpaca") return "Alpaca";
  if (v === "coinbase") return "Coinbase";
  if (v === "kraken") return "Kraken";
  return "Tidemark Live";
}
