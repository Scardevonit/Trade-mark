// Live price layer. Primary: Coinbase Exchange public API (no key).
// Fallback: Coinbase retail + Kraken. Cached 8s in-memory to avoid rate limits.
import { SUPPORTED_ASSETS } from "./format";

export type LiveQuote = {
  symbol: string;
  name: string;
  priceUsd: number;
  open24h: number;
  high24h: number;
  low24h: number;
  change24hPct: number;
  volume24h: number;
  source: string;
  asOf: string;
};

const cache = new Map<string, { at: number; data: LiveQuote[] }>();
const CACHE_MS = 8000;

async function coinbaseTicker(product: string) {
  const [tickerRes, statsRes] = await Promise.all([
    fetch(`https://api.exchange.coinbase.com/products/${product}/ticker`, {
      headers: { "User-Agent": "tidemark-live/1.0" },
      cache: "no-store",
    }),
    fetch(`https://api.exchange.coinbase.com/products/${product}/stats`, {
      headers: { "User-Agent": "tidemark-live/1.0" },
      cache: "no-store",
    }),
  ]);
  if (!tickerRes.ok) throw new Error(`ticker ${product} ${tickerRes.status}`);
  const t = (await tickerRes.json()) as { price: string; volume: string };
  let open = Number(t.price);
  let high = Number(t.price);
  let low = Number(t.price);
  let volume = Number(t.volume ?? 0);
  if (statsRes.ok) {
    const s = (await statsRes.json()) as {
      open: string;
      high: string;
      low: string;
      volume: string;
    };
    open = Number(s.open || t.price);
    high = Number(s.high || t.price);
    low = Number(s.low || t.price);
    volume = Number(s.volume || t.volume || 0);
  }
  return { price: Number(t.price), open, high, low, volume };
}

// Kraken fallback map
const KRAKEN_MAP: Record<string, string> = {
  BTC: "XXBTZUSD",
  ETH: "XETHZUSD",
  SOL: "SOLUSD",
  USDC: "USDCZUSD",
  DOGE: "DOGEUSD",
  AVAX: "AVAXUSD",
  LINK: "LINKUSD",
  MATIC: "MATICUSD",
};

async function krakenFallback(): Promise<Map<string, number>> {
  const pairs = Object.values(KRAKEN_MAP).join(",");
  const res = await fetch(`https://api.kraken.com/0/public/Ticker?pair=${pairs}`, {
    cache: "no-store",
  });
  if (!res.ok) throw new Error("kraken failed");
  const j = (await res.json()) as { result: Record<string, { c: string[]; o: string; h: string[]; l: string[]; v: string[] }> };
  const out = new Map<string, number>();
  for (const [sym, pair] of Object.entries(KRAKEN_MAP)) {
    const r = j.result?.[pair];
    if (r?.c?.[0]) out.set(sym, Number(r.c[0]));
  }
  return out;
}

export async function getLiveQuotes(): Promise<LiveQuote[]> {
  const hit = cache.get("all");
  if (hit && Date.now() - hit.at < CACHE_MS) return hit.data;

  const results: LiveQuote[] = [];
  let fallback: Map<string, number> | null = null;

  await Promise.all(
    SUPPORTED_ASSETS.map(async (a) => {
      try {
        const q = await coinbaseTicker(a.coinbase);
        const chg = q.open > 0 ? ((q.price - q.open) / q.open) * 100 : 0;
        results.push({
          symbol: a.symbol,
          name: a.name,
          priceUsd: q.price,
          open24h: q.open,
          high24h: q.high,
          low24h: q.low,
          change24hPct: Math.round(chg * 100) / 100,
          volume24h: q.volume,
          source: "coinbase-exchange",
          asOf: new Date().toISOString(),
        });
      } catch {
        try {
          if (!fallback) fallback = await krakenFallback().catch(() => null);
          const p = fallback?.get(a.symbol);
          if (p) {
            results.push({
              symbol: a.symbol,
              name: a.name,
              priceUsd: p,
              open24h: p,
              high24h: p,
              low24h: p,
              change24hPct: 0,
              volume24h: 0,
              source: "kraken-fallback",
              asOf: new Date().toISOString(),
            });
          }
        } catch {
          /* ignore */
        }
      }
    })
  );

  // Last-resort static guard so UI never blanks (marked clearly)
  if (results.length === 0) {
    const stale: LiveQuote[] = SUPPORTED_ASSETS.map((a) => ({
      symbol: a.symbol,
      name: a.name,
      priceUsd: a.symbol === "BTC" ? 67420 : a.symbol === "ETH" ? 3520 : 100,
      open24h: 0,
      high24h: 0,
      low24h: 0,
      change24hPct: 0,
      volume24h: 0,
      source: "offline-guard",
      asOf: new Date().toISOString(),
    }));
    return stale;
  }

  results.sort(
    (x, y) =>
      SUPPORTED_ASSETS.findIndex((a) => a.symbol === x.symbol) -
      SUPPORTED_ASSETS.findIndex((a) => a.symbol === y.symbol)
  );
  cache.set("all", { at: Date.now(), data: results });
  return results;
}

export async function getPrice(symbol: string): Promise<number> {
  const all = await getLiveQuotes();
  const q = all.find((r) => r.symbol === symbol.toUpperCase());
  if (!q) throw new Error(`Unsupported symbol ${symbol}`);
  return q.priceUsd;
}

export type Candle = { time: number; low: number; high: number; open: number; close: number; volume: number };

export async function getCandles(symbol: string, granularity = 3600): Promise<Candle[]> {
  const asset = SUPPORTED_ASSETS.find((a) => a.symbol === symbol.toUpperCase());
  if (!asset) throw new Error("unsupported");
  const url = `https://api.exchange.coinbase.com/products/${asset.coinbase}/candles?granularity=${granularity}`;
  const res = await fetch(url, {
    headers: { "User-Agent": "tidemark-live/1.0" },
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`candles ${res.status}`);
  const raw = (await res.json()) as number[][];
  return raw
    .map((c) => ({ time: c[0], low: c[1], high: c[2], open: c[3], close: c[4], volume: c[5] }))
    .sort((a, b) => a.time - b.time);
}
