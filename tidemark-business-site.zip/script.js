const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');
if (menuToggle && nav) {
  menuToggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(open));
  });
  nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    nav.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
  }));
}
document.getElementById('year').textContent = new Date().getFullYear();

// This interest form is intentionally not connected to a database or email service.
// Connect a privacy-compliant form handler before collecting real personal data.
const form = document.getElementById('interestForm');
const note = document.getElementById('formNote');
if (form && note) {
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    note.textContent = 'Thanks for your interest. This form is a front-end preview and has not submitted or stored your information.';
    note.classList.add('notice');
  });
}
