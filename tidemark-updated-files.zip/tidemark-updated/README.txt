TIDEMARK UPDATED FRONTEND PREVIEW

Files: index.html, style.css, script.js

Included:
- Responsive Tidemark landing page and illustrative market watch
- Login / create-account interface (frontend only; no real authentication)
- Account snapshot with clearly labeled illustrative balance
- Gift card redemption request area for promotional rewards only
- Investment funding section kept disabled

Important:
This is a static frontend preview and is not a functioning broker or payment system.
Do not enter real passwords, gift card codes, or payment details.
GitHub Pages can host the static interface, but real authentication, account records,
redemption processing, payments, and investment funding require a secure backend,
provider approval, and applicable legal/compliance setup.
